import {
  EsConnectionConfig,
  EsClusterInfo,
  EsQueryItem,
  EsQueryResult,
  EsEvidencePackage,
} from '../types/elasticsearch';
import { safeJsonParse } from './jsonHelper';
import { saveToFileSystem, loadFromFileSystem } from './storage';

const ES_CONFIG_KEY = 'couch_es_connection_settings';
const ES_QUERIES_KEY = 'couch_es_saved_queries';
const ES_EVIDENCE_KEY = 'couch_es_saved_evidence_packages';

export const DEFAULT_ES_CONFIG: EsConnectionConfig = {
  url: 'http://localhost:9200',
  authType: 'none',
  username: '',
  password: '',
  apiKey: '',
  bearerToken: '',
  cookie: '',
  cookieLoginUrl: '/api/v1/auth/login',
  cookieLoginUsername: '',
  cookieLoginPassword: '',
  defaultIndex: 'customers-*',
  customHeaders: '',
};

export const DEFAULT_SAMPLE_QUERIES: EsQueryItem[] = [
  {
    id: 'es-q1',
    title: '1. Verify Customer Sync in ES (By ID)',
    index: 'customers-*',
    method: 'POST',
    endpointPath: '/customers-*/_search',
    queryBody: JSON.stringify(
      {
        query: {
          term: {
            "_id": "cust_99281"
          }
        },
        size: 5
      },
      null,
      2
    ),
    enabled: true,
    notes: 'Verify migrated customer document exists in Elasticsearch index',
    linkedTestCase: 'cust_99281',
  },
  {
    id: 'es-q2',
    title: '2. Check Migration Audit Trail Events',
    index: 'migration-audit-*',
    method: 'POST',
    endpointPath: '/migration-audit-*/_search',
    queryBody: JSON.stringify(
      {
        query: {
          bool: {
            must: [
              { term: { "action.keyword": "MIGRATION_SYNC" } },
              { term: { "status.keyword": "SUCCESS" } }
            ]
          }
        },
        sort: [
          { "timestamp": { "order": "desc" } }
        ],
        size: 10
      },
      null,
      2
    ),
    enabled: true,
    notes: 'Confirm audit event was generated and stored during payload migration',
    linkedTestCase: 'cust_99281',
  },
  {
    id: 'es-q3',
    title: '3. Query Migration Error & Failure Logs',
    index: 'migration-logs-*',
    method: 'POST',
    endpointPath: '/migration-logs-*/_search',
    queryBody: JSON.stringify(
      {
        query: {
          bool: {
            filter: [
              { term: { "log_level.keyword": "ERROR" } }
            ]
          }
        },
        sort: [
          { "timestamp": { "order": "desc" } }
        ],
        size: 5
      },
      null,
      2
    ),
    enabled: true,
    notes: 'Verify zero errors or check unhandled exception logs for test case',
    linkedTestCase: 'cust_99281',
  },
];

// LocalStorage helpers
export function loadEsConnectionConfig(): EsConnectionConfig {
  const raw = localStorage.getItem(ES_CONFIG_KEY);
  if (!raw) return DEFAULT_ES_CONFIG;
  return { ...DEFAULT_ES_CONFIG, ...safeJsonParse<Partial<EsConnectionConfig>>(raw, {}) };
}

export function saveEsConnectionConfig(config: EsConnectionConfig): void {
  localStorage.setItem(ES_CONFIG_KEY, JSON.stringify(config));
}

export function loadSavedEsQueries(): EsQueryItem[] {
  const raw = localStorage.getItem(ES_QUERIES_KEY);
  if (!raw) {
    localStorage.setItem(ES_QUERIES_KEY, JSON.stringify(DEFAULT_SAMPLE_QUERIES));
    return DEFAULT_SAMPLE_QUERIES;
  }
  const parsed = safeJsonParse<EsQueryItem[]>(raw, []);
  return parsed.length > 0 ? parsed : DEFAULT_SAMPLE_QUERIES;
}

export function saveSavedEsQueries(queries: EsQueryItem[]): void {
  localStorage.setItem(ES_QUERIES_KEY, JSON.stringify(queries));
}

export function loadSavedEvidencePackages(): EsEvidencePackage[] {
  const raw = localStorage.getItem(ES_EVIDENCE_KEY);
  return safeJsonParse<EsEvidencePackage[]>(raw || '', []);
}

export function saveEvidencePackage(pkg: EsEvidencePackage): EsEvidencePackage[] {
  const current = loadSavedEvidencePackages();
  const index = current.findIndex((p) => p.id === pkg.id);
  const updated = index >= 0 ? current.map((p, i) => (i === index ? pkg : p)) : [pkg, ...current];
  localStorage.setItem(ES_EVIDENCE_KEY, JSON.stringify(updated));
  return updated;
}

export function deleteEvidencePackage(id: string): EsEvidencePackage[] {
  const current = loadSavedEvidencePackages();
  const updated = current.filter((p) => p.id !== id);
  localStorage.setItem(ES_EVIDENCE_KEY, JSON.stringify(updated));
  return updated;
}

// Network Calls via backend proxy
export async function fetchLoginCookie(params: {
  url: string;
  loginPath?: string;
  username?: string;
  password?: string;
  customPayload?: any;
}): Promise<{ success: boolean; cookie?: string; rawCookies?: string[]; status?: number; error?: string }> {
  try {
    const res = await fetch('/api/elasticsearch/login-cookie', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(params),
    });
    return await res.json();
  } catch (err: any) {
    return {
      success: false,
      error: `Failed to request login endpoint: ${err.message}`,
    };
  }
}

export async function testElasticsearchConnection(
  config: EsConnectionConfig
): Promise<{ success: boolean; status?: number; clusterInfo?: EsClusterInfo; health?: any; error?: string }> {
  try {
    const res = await fetch('/api/elasticsearch/test-connection', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(config),
    });

    const data = await res.json();
    return data;
  } catch (err: any) {
    return {
      success: false,
      error: `Proxy request failed: ${err.message}. Is server running?`,
    };
  }
}

export async function executeElasticsearchQuery(
  config: EsConnectionConfig,
  queryItem: EsQueryItem
): Promise<EsQueryResult> {
  const startTime = performance.now();
  const executedAt = new Date().toISOString().replace('T', ' ').substring(0, 19);

  let queryBodyObj: any;
  try {
    queryBodyObj = JSON.parse(queryItem.queryBody || '{}');
  } catch (e: any) {
    return {
      queryId: queryItem.id,
      queryTitle: queryItem.title,
      index: queryItem.index,
      executedAt,
      durationMs: 0,
      status: 'ERROR',
      statusCode: 400,
      totalHits: 0,
      hits: [],
      errorMessage: `Invalid JSON query syntax: ${e.message}`,
    };
  }

  try {
    const res = await fetch('/api/elasticsearch/query', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        url: config.url,
        authType: config.authType,
        username: config.username,
        password: config.password,
        apiKey: config.apiKey,
        bearerToken: config.bearerToken,
        cookie: config.cookie,
        customHeaders: config.customHeaders,
        index: queryItem.index || config.defaultIndex || '',
        path: queryItem.endpointPath,
        method: queryItem.method || 'POST',
        queryBody: queryBodyObj,
      }),
    });

    const durationMs = Math.round(performance.now() - startTime);
    const data = await res.json();

    if (!res.ok || !data.success) {
      return {
        queryId: queryItem.id,
        queryTitle: queryItem.title,
        index: queryItem.index,
        executedAt,
        durationMs,
        status: 'ERROR',
        statusCode: res.status,
        totalHits: 0,
        hits: [],
        rawResponse: data.details || data,
        errorMessage: data.error || `HTTP ${res.status}: Query execution error`,
      };
    }

    return {
      queryId: queryItem.id,
      queryTitle: queryItem.title,
      index: queryItem.index,
      executedAt,
      durationMs: data.took || durationMs,
      status: 'SUCCESS',
      statusCode: res.status,
      totalHits: data.totalHits ?? (data.hits?.length || 0),
      hits: data.hits || [],
      rawResponse: data.data,
    };
  } catch (err: any) {
    const durationMs = Math.round(performance.now() - startTime);
    return {
      queryId: queryItem.id,
      queryTitle: queryItem.title,
      index: queryItem.index,
      executedAt,
      durationMs,
      status: 'ERROR',
      totalHits: 0,
      hits: [],
      errorMessage: `Network error: ${err.message}`,
    };
  }
}

// Simulated Elasticsearch query runner for offline/demo testing
export function generateSimulatedEsResult(
  queryItem: EsQueryItem,
  testCaseId?: string
): EsQueryResult {
  const executedAt = new Date().toISOString().replace('T', ' ').substring(0, 19);
  const docId = testCaseId || 'cust_99281';

  let hits: any[] = [];
  let totalHits = 1;

  if (queryItem.index.includes('audit')) {
    hits = [
      {
        _index: 'migration-audit-2026.10',
        _id: `audit-${Math.random().toString(36).substring(2, 9)}`,
        _score: 1.0,
        _source: {
          timestamp: new Date().toISOString(),
          doc_id: docId,
          action: 'MIGRATION_SYNC',
          status: 'SUCCESS',
          source_type: 'couchdb',
          target_table: 'customers',
          migrated_fields: ['_id', 'profile.firstName', 'profile.lastName', 'profile.email', 'account.creditLimit'],
          checksum: 'sha256-4a89b2c3d4e5f6g7h8i9',
          node: 'es-cluster-node-01'
        }
      }
    ];
  } else if (queryItem.index.includes('logs')) {
    totalHits = 0;
    hits = []; // No error logs for clean run
  } else {
    hits = [
      {
        _index: 'customers-v2',
        _id: docId,
        _score: 2.87,
        _source: {
          id: docId,
          first_name: 'Eleanor',
          last_name: 'Vance',
          email: 'eleanor.vance@enterprise.io',
          phone: '+1-555-019-2831',
          credit_limit: 15000.00,
          is_active: true,
          synced_at: new Date().toISOString(),
          migration_status: 'VERIFIED'
        }
      }
    ];
  }

  return {
    queryId: queryItem.id,
    queryTitle: queryItem.title,
    index: queryItem.index,
    executedAt,
    durationMs: Math.floor(4 + Math.random() * 12),
    status: 'SUCCESS',
    statusCode: 200,
    totalHits,
    hits,
    rawResponse: {
      took: 8,
      timed_out: false,
      _shards: { total: 5, successful: 5, skipped: 0, failed: 0 },
      hits: {
        total: { value: totalHits, relation: 'eq' },
        max_score: 2.87,
        hits
      }
    }
  };
}

// ─── cURL helpers ────────────────────────────────────────────────────────────

export interface CurlExecResult {
  success: boolean;
  statusCode?: number;
  durationMs: number;
  curlCommand: string;
  responseHeaders?: string;
  responseBody?: string;
  parsedBody?: any;
  stderr?: string | null;
  error?: string | null;
  // Query result fields
  hits?: any[];
  totalHits?: number;
  took?: number;
  clusterInfo?: any;
}

/** Sends a request to the server's curl-exec proxy endpoint */
export async function executeCurl(params: {
  config: EsConnectionConfig;
  path: string;
  method?: string;
  body?: any;
  timeoutMs?: number;
}): Promise<CurlExecResult> {
  try {
    const res = await fetch('/api/elasticsearch/curl-exec', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        url: params.config.url,
        authType: params.config.authType,
        username: params.config.username,
        password: params.config.password,
        apiKey: params.config.apiKey,
        bearerToken: params.config.bearerToken,
        cookie: params.config.cookie,
        customHeaders: params.config.customHeaders,
        path: params.path,
        method: params.method || 'GET',
        body: params.body,
        timeoutMs: params.timeoutMs || 15000,
      }),
    });
    const resText = await res.text();
    let data: any;
    try {
      data = JSON.parse(resText);
    } catch {
      return {
        success: false,
        durationMs: 0,
        curlCommand: '',
        error: `Proxy server returned HTML instead of JSON (HTTP ${res.status}). Verify backend is running on http://localhost:3000.`,
      };
    }
    return data as CurlExecResult;
  } catch (err: any) {
    return {
      success: false,
      durationMs: 0,
      curlCommand: '',
      error: `Failed to reach curl-exec proxy: ${err.message}`,
    };
  }
}

/** Test ES connection via cURL */
export async function testElasticsearchConnectionCurl(
  config: EsConnectionConfig
): Promise<{ success: boolean; statusCode?: number; clusterInfo?: EsClusterInfo; health?: any; error?: string; curlCommand?: string; rawOutput?: string }> {
  const result = await executeCurl({ config, path: '/', method: 'GET' });
  if (result.success && result.parsedBody) {
    // Try health too
    let health: any = null;
    try {
      const healthResult = await executeCurl({ config, path: '/_cluster/health', method: 'GET', timeoutMs: 6000 });
      if (healthResult.success && healthResult.parsedBody) health = healthResult.parsedBody;
    } catch { /* optional */ }
    return {
      success: true,
      statusCode: result.statusCode,
      clusterInfo: result.parsedBody,
      health,
      curlCommand: result.curlCommand,
    };
  }
  return {
    success: false,
    statusCode: result.statusCode,
    error: result.error || 'No response body',
    curlCommand: result.curlCommand,
    rawOutput: result.responseBody,
  };
}

/** Execute an ES query via cURL */
export async function executeElasticsearchQueryCurl(
  config: EsConnectionConfig,
  queryItem: EsQueryItem
): Promise<EsQueryResult & { curlCommand?: string; rawOutput?: string; responseHeaders?: string }> {
  const executedAt = new Date().toISOString().replace('T', ' ').substring(0, 19);

  let queryBodyObj: any;
  try {
    queryBodyObj = JSON.parse(queryItem.queryBody || '{}');
  } catch (e: any) {
    return {
      queryId: queryItem.id,
      queryTitle: queryItem.title,
      index: queryItem.index,
      executedAt,
      durationMs: 0,
      status: 'ERROR',
      statusCode: 400,
      totalHits: 0,
      hits: [],
      errorMessage: `Invalid JSON query syntax: ${e.message}`,
    };
  }

  const targetPath = queryItem.endpointPath || `/${queryItem.index || config.defaultIndex || '_all'}/_search`;
  const result = await executeCurl({
    config,
    path: targetPath,
    method: queryItem.method || 'POST',
    body: queryItem.method === 'GET' ? undefined : queryBodyObj,
  });

  if (result.success) {
    return {
      queryId: queryItem.id,
      queryTitle: queryItem.title,
      index: queryItem.index,
      executedAt,
      durationMs: result.durationMs,
      status: 'SUCCESS',
      statusCode: result.statusCode,
      totalHits: result.totalHits ?? 0,
      hits: result.hits || [],
      rawResponse: result.parsedBody,
      curlCommand: result.curlCommand,
      rawOutput: result.responseBody,
      responseHeaders: result.responseHeaders,
    } as any;
  }

  return {
    queryId: queryItem.id,
    queryTitle: queryItem.title,
    index: queryItem.index,
    executedAt,
    durationMs: result.durationMs,
    status: 'ERROR',
    statusCode: result.statusCode,
    totalHits: 0,
    hits: [],
    rawResponse: result.parsedBody,
    errorMessage: result.error || 'curl execution failed',
    curlCommand: result.curlCommand,
    rawOutput: result.responseBody,
    responseHeaders: result.responseHeaders,
  } as any;
}

/** Build a human-readable curl command string for a given query (for display/copy) */
export function buildCurlCommandForQuery(config: EsConnectionConfig, queryItem: EsQueryItem): string {
  const cleanUrl = (config.url || '').replace(/\/+$/, '');
  const targetPath = queryItem.endpointPath || `/${queryItem.index}/_search`;
  const fullUrl = `${cleanUrl}${targetPath}`;
  const method = (queryItem.method || 'POST').toUpperCase();

  const parts: string[] = ['curl', '--silent', '--show-error', '-X', method];
  parts.push('-H', '"Content-Type: application/json"');
  parts.push('-H', '"Accept: application/json"');

  if (config.authType === 'basic' && config.username) {
    parts.push('-u', `"${config.username}:***"`);
  } else if (config.authType === 'apiKey') {
    parts.push('-H', '"Authorization: ApiKey ***"');
  } else if (config.authType === 'bearer') {
    parts.push('-H', '"Authorization: Bearer ***"');
  } else if (config.authType === 'cookie' && config.cookie) {
    const shortCookie = config.cookie.length > 50 ? config.cookie.substring(0, 50) + '...' : config.cookie;
    parts.push('-H', `"Cookie: ${shortCookie}"`);
    parts.push('-H', '"kbn-xsrf: true"');
  }

  if (method !== 'GET' && method !== 'HEAD') {
    try {
      const body = JSON.stringify(JSON.parse(queryItem.queryBody || '{}'));
      parts.push('-d', `'${body}'`);
    } catch {
      parts.push('-d', `'${queryItem.queryBody || '{}'}'`);
    }
  }

  parts.push(`"${fullUrl}"`);
  return parts.join(' \\\n  ');
}

