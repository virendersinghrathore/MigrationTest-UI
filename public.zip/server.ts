import express from 'express';
import { createServer as createViteServer } from 'vite';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { execFile } from 'child_process';
import { promisify } from 'util';

const execFileAsync = promisify(execFile);


const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const DATA_DIR = path.join(__dirname, 'data');
if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}

function getSafeFilePath(key: string): string | null {
  const safeKey = path.basename(key).replace(/[^a-zA-Z0-9_-]/g, '');
  if (!safeKey) return null;
  return path.join(DATA_DIR, `${safeKey}.json`);
}

async function createServer() {
  const app = express();
  app.use(express.json({ limit: '50mb' }));

  const vite = await createViteServer({
    server: {
      middlewareMode: true,
      watch: {
        ignored: [
          '**/data/**',
          '**/data/**/*',
          '**/data',
          (file: string) => {
            const normalized = file.replace(/\\/g, '/');
            return normalized.includes('/data/') || normalized.endsWith('/data');
          },
        ],
      },
    },
    appType: 'custom',
  });

  app.use(vite.middlewares);

  // File Storage API
  app.get('/api/storage/:key', (req, res) => {
    const filePath = getSafeFilePath(req.params.key);
    if (!filePath) {
      return res.status(400).json({ error: 'Invalid key' });
    }

    if (fs.existsSync(filePath)) {
      try {
        const data = fs.readFileSync(filePath, 'utf-8');
        res.json(JSON.parse(data));
      } catch (e: any) {
        console.error(`Failed to read file ${filePath}:`, e);
        res.status(500).json({ error: 'Failed to read data' });
      }
    } else {
      res.status(404).json({ error: 'Not found' });
    }
  });

  app.post('/api/storage/:key', (req, res) => {
    const filePath = getSafeFilePath(req.params.key);
    if (!filePath) {
      return res.status(400).json({ error: 'Invalid key' });
    }

    try {
      // Atomic write to avoid partial writes or read race conditions
      const tempPath = `${filePath}.${Date.now()}.${Math.random().toString(36).slice(2, 6)}.tmp`;
      fs.writeFileSync(tempPath, JSON.stringify(req.body, null, 2), 'utf-8');
      fs.renameSync(tempPath, filePath);
      res.json({ success: true });
    } catch (e: any) {
      console.error(`Failed to save file ${filePath}:`, e);
      res.status(500).json({ error: 'Failed to save data' });
    }
  });

  // Elasticsearch Proxy APIs
  function buildEsHeaders(body: any): Record<string, string> {
    const headers: Record<string, string> = {
      'Content-Type': 'application/json',
      'Accept': 'application/json',
    };
    if (body.authType === 'basic' && body.username) {
      const creds = `${body.username}:${body.password || ''}`;
      headers['Authorization'] = `Basic ${Buffer.from(creds).toString('base64')}`;
    } else if (body.authType === 'apiKey' && body.apiKey) {
      headers['Authorization'] = body.apiKey.startsWith('ApiKey ') ? body.apiKey : `ApiKey ${body.apiKey}`;
    } else if (body.authType === 'bearer' && body.bearerToken) {
      headers['Authorization'] = `Bearer ${body.bearerToken}`;
    } else if (body.authType === 'cookie' && body.cookie) {
      headers['Cookie'] = body.cookie;
      headers['kbn-xsrf'] = 'true';
    }
    if (body.customHeaders) {
      try {
        const parsed = typeof body.customHeaders === 'string' ? JSON.parse(body.customHeaders) : body.customHeaders;
        Object.assign(headers, parsed);
      } catch {
        // ignore malformed custom headers
      }
    }
    return headers;
  }

  app.post('/api/elasticsearch/login-cookie', async (req, res) => {
    const { url, loginPath, username, password, customPayload } = req.body;
    if (!url) {
      return res.status(400).json({ success: false, error: 'Cluster/Host URL is required' });
    }

    const cleanUrl = url.replace(/\/+$/, '');
    const path = (loginPath || '/login').startsWith('/') ? loginPath : `/${loginPath || 'login'}`;
    const targetUrl = `${cleanUrl}${path}`;

    try {
      let bodyData = customPayload;
      if (!bodyData && (username || password)) {
        bodyData = { username, password };
      }

      const response = await fetch(targetUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json',
          'kbn-xsrf': 'true',
        },
        body: bodyData ? (typeof bodyData === 'string' ? bodyData : JSON.stringify(bodyData)) : undefined,
        redirect: 'manual',
        signal: AbortSignal.timeout(10000),
      });

      let setCookies: string[] = [];
      if (typeof (response.headers as any).getSetCookie === 'function') {
        setCookies = (response.headers as any).getSetCookie();
      } else {
        const raw = response.headers.get('set-cookie');
        if (raw) setCookies = [raw];
      }

      const formattedCookie = setCookies
        .map((c) => c.split(';')[0].trim())
        .filter(Boolean)
        .join('; ');

      if (!formattedCookie && response.status >= 400) {
        return res.status(response.status).json({
          success: false,
          status: response.status,
          error: `Login failed with HTTP ${response.status}: ${response.statusText}`
        });
      }

      res.json({
        success: true,
        cookie: formattedCookie,
        rawCookies: setCookies,
        status: response.status
      });
    } catch (e: any) {
      res.status(502).json({
        success: false,
        error: `Failed to authenticate at ${targetUrl}: ${e.message}`
      });
    }
  });

  app.post('/api/elasticsearch/test-connection', async (req, res) => {
    // Allow self-signed SSL certificates commonly found in self-hosted ELK environments
    if (!process.env.NODE_TLS_REJECT_UNAUTHORIZED) {
      process.env.NODE_TLS_REJECT_UNAUTHORIZED = '0';
    }

    const { url } = req.body;
    if (!url) {
      return res.status(400).json({ success: false, error: 'Elasticsearch URL is required' });
    }

    const cleanUrl = url.replace(/\/+$/, '');
    const headers = buildEsHeaders(req.body);

    try {
      // 1. Try standard Elasticsearch root endpoint (GET /)
      let esResponse = await fetch(`${cleanUrl}/`, {
        method: 'GET',
        headers,
        signal: AbortSignal.timeout(8000),
      });

      const contentType = esResponse.headers.get('content-type') || '';
      const isHtmlResponse = contentType.includes('text/html');

      // If direct GET / succeeded and returned JSON, parse Elasticsearch cluster info
      if (esResponse.ok && !isHtmlResponse) {
        try {
          const clusterInfo = await esResponse.json();
          let health = null;
          try {
            const healthRes = await fetch(`${cleanUrl}/_cluster/health`, {
              method: 'GET',
              headers,
              signal: AbortSignal.timeout(4000),
            });
            if (healthRes.ok) health = await healthRes.json();
          } catch {
            // health check is optional
          }

          return res.json({
            success: true,
            status: esResponse.status,
            clusterInfo,
            health,
          });
        } catch {
          // JSON parsing failed, fall through to Kibana / proxy check
        }
      }

      // 2. If GET / returned HTML or redirected or failed, check if this is Kibana or an ELK console proxy
      // Self-hosted ELK behind cookie authentication is frequently Kibana (port 5601 or proxy)
      try {
        // Try Kibana Dev Tools Console Proxy (proxies directly to ES root)
        const kibanaProxyRes = await fetch(`${cleanUrl}/api/console/proxy?path=/&method=GET`, {
          method: 'POST',
          headers,
          signal: AbortSignal.timeout(6000),
        });

        if (kibanaProxyRes.ok) {
          const proxyInfo = await kibanaProxyRes.json();
          return res.json({
            success: true,
            status: kibanaProxyRes.status,
            clusterInfo: {
              ...proxyInfo,
              cluster_name: proxyInfo.cluster_name || 'ELK Cluster (via Kibana Proxy)',
              viaKibanaProxy: true,
            },
            notes: 'Connected successfully via Kibana Console Proxy using your session cookie.',
          });
        }
      } catch {
        // Kibana proxy check failed, continue
      }

      try {
        // Try Kibana status API (/api/status)
        const kibanaStatusRes = await fetch(`${cleanUrl}/api/status`, {
          method: 'GET',
          headers,
          signal: AbortSignal.timeout(6000),
        });

        if (kibanaStatusRes.ok) {
          const kbnData = await kibanaStatusRes.json();
          const kbnVersion = kbnData?.version?.number || 'Kibana';
          const kbnStatus = kbnData?.status?.overall?.level || 'available';
          return res.json({
            success: true,
            status: kibanaStatusRes.status,
            clusterInfo: {
              name: kbnData?.name || 'Kibana',
              cluster_name: `Kibana (${kbnData?.version?.build_hash?.substring(0, 7) || 'Self-Hosted'})`,
              version: { number: kbnVersion },
              tagline: 'Kibana Session Authenticated',
              health: { status: kbnStatus === 'available' ? 'green' : 'yellow' },
              viaKibana: true,
            },
            notes: 'Connected to Kibana successfully with valid session cookie.',
          });
        }
      } catch {
        // Kibana status check failed, continue
      }

      // If we got here, both standard ES and Kibana endpoints failed
      if (esResponse.status === 302 || esResponse.status === 301 || isHtmlResponse) {
        return res.status(401).json({
          success: false,
          status: esResponse.status,
          error: `Cookie authentication failed or expired: The server returned HTTP ${esResponse.status} (Login Redirect / HTML Page). Please copy an active session cookie from browser DevTools and paste it again.`,
        });
      }

      const errText = await esResponse.text().catch(() => '');
      return res.status(esResponse.status).json({
        success: false,
        status: esResponse.status,
        error: `Host returned HTTP ${esResponse.status}: ${errText.slice(0, 200) || esResponse.statusText}. Check URL and cookie validity.`,
      });
    } catch (e: any) {
      console.error('ES connection test failed:', e);
      res.status(502).json({
        success: false,
        error: `Could not connect to Elasticsearch at ${cleanUrl}: ${e.message}. If using self-signed HTTPS, verify the host is reachable.`
      });
    }
  });

  app.post('/api/elasticsearch/query', async (req, res) => {
    const { url, index, path: customPath, method = 'POST', queryBody } = req.body;
    if (!url) {
      return res.status(400).json({ success: false, error: 'Elasticsearch URL is required' });
    }

    const cleanUrl = url.replace(/\/+$/, '');
    const headers = buildEsHeaders(req.body);

    let targetPath = customPath || (index ? `/${index}/_search` : '/_search');
    if (!targetPath.startsWith('/')) targetPath = `/${targetPath}`;

    const fullUrl = `${cleanUrl}${targetPath}`;

    try {
      const fetchOptions: RequestInit = {
        method: (method || 'POST').toUpperCase(),
        headers,
        signal: AbortSignal.timeout(15000),
      };

      if (fetchOptions.method !== 'GET' && fetchOptions.method !== 'HEAD') {
        fetchOptions.body = typeof queryBody === 'object' ? JSON.stringify(queryBody) : (queryBody || '{}');
      }

      const response = await fetch(fullUrl, fetchOptions);
      const resText = await response.text();
      let resData: any;
      try {
        resData = JSON.parse(resText);
      } catch {
        resData = { raw: resText };
      }

      if (!response.ok) {
        return res.status(response.status).json({
          success: false,
          status: response.status,
          error: resData?.error?.reason || `Query failed with HTTP ${response.status}`,
          details: resData,
        });
      }

      res.json({
        success: true,
        status: response.status,
        data: resData,
        took: resData.took,
        timedOut: resData.timed_out,
        totalHits: typeof resData.hits?.total === 'object' ? resData.hits.total.value : (resData.hits?.total ?? (resData.hits?.hits?.length || 0)),
        hits: resData.hits?.hits || [],
      });
    } catch (e: any) {
      console.error('ES query execution failed:', e);
      res.status(502).json({
        success: false,
        error: `Failed to execute query against ${fullUrl}: ${e.message}`,
      });
    }
  });

  // ─── cURL Execution Proxy ─────────────────────────────────────────────────
  // Builds and runs a curl command server-side. The client sends structured
  // params; we never allow raw shell strings from the client (security).
  app.post('/api/elasticsearch/curl-exec', async (req, res) => {
    const {
      url, authType, username, password, apiKey, bearerToken, cookie,
      customHeaders, path: reqPath, method = 'GET', body: reqBody, timeoutMs = 15000,
    } = req.body;

    if (!url) {
      return res.status(400).json({ success: false, error: 'URL is required' });
    }

    const cleanUrl = url.replace(/\/+$/, '');
    const targetPath = reqPath ? (reqPath.startsWith('/') ? reqPath : `/${reqPath}`) : '/';
    const fullUrl = `${cleanUrl}${targetPath}`;

    // Build curl args as an array (safe — no shell injection)
    const args: string[] = [
      '--silent',
      '--show-error',
      '--include',          // include response headers in output
      '-k',                 // allow internal / self-signed TLS certs for self-hosted ELK
      '--max-time', String(Math.ceil(timeoutMs / 1000)),
      '-X', (method || 'GET').toUpperCase(),
      '-H', 'Content-Type: application/json',
      '-H', 'Accept: application/json',
    ];

    // Auth headers
    if (authType === 'basic' && username) {
      args.push('-u', `${username}:${password || ''}`);
    } else if (authType === 'apiKey' && apiKey) {
      const key = apiKey.startsWith('ApiKey ') ? apiKey : `ApiKey ${apiKey}`;
      args.push('-H', `Authorization: ${key}`);
    } else if (authType === 'bearer' && bearerToken) {
      args.push('-H', `Authorization: Bearer ${bearerToken}`);
    } else if (authType === 'cookie' && cookie) {
      args.push('-H', `Cookie: ${cookie}`);
      args.push('-H', 'kbn-xsrf: true');
    }

    // Custom headers
    if (customHeaders) {
      try {
        const parsed = typeof customHeaders === 'string' ? JSON.parse(customHeaders) : customHeaders;
        for (const [k, v] of Object.entries(parsed)) {
          args.push('-H', `${k}: ${v}`);
        }
      } catch { /* ignore */ }
    }

    // Request body
    if (reqBody && method.toUpperCase() !== 'GET' && method.toUpperCase() !== 'HEAD') {
      const bodyStr = typeof reqBody === 'object' ? JSON.stringify(reqBody) : String(reqBody);
      args.push('-d', bodyStr);
    }

    args.push(fullUrl);

    // Build the display curl string (for UI preview — mask secrets)
    const displayArgs: string[] = [
      'curl', '--silent', '--show-error', '--include',
      '-X', (method || 'GET').toUpperCase(),
      '-H', '"Content-Type: application/json"',
    ];
    if (authType === 'basic' && username) {
      displayArgs.push('-u', `"${username}:***"`);
    } else if (authType === 'apiKey') {
      displayArgs.push('-H', '"Authorization: ApiKey ***"');
    } else if (authType === 'bearer') {
      displayArgs.push('-H', '"Authorization: Bearer ***"');
    } else if (authType === 'cookie' && cookie) {
      const shortCookie = cookie.length > 40 ? cookie.substring(0, 40) + '...' : cookie;
      displayArgs.push('-H', `"Cookie: ${shortCookie}"`);
      displayArgs.push('-H', '"kbn-xsrf: true"');
    }
    if (reqBody && method.toUpperCase() !== 'GET') {
      const bodyStr = typeof reqBody === 'object' ? JSON.stringify(reqBody) : String(reqBody);
      displayArgs.push('-d', `'${bodyStr.replace(/'/g, `'"'"'`)}'`);
    }
    displayArgs.push(`"${fullUrl}"`);
    const curlCommand = displayArgs.join(' ');

    const startTime = Date.now();
    try {
      const { stdout, stderr } = await execFileAsync('curl', args, {
        timeout: timeoutMs + 2000,
        maxBuffer: 10 * 1024 * 1024, // 10MB
      });

      const durationMs = Date.now() - startTime;
      const output = stdout || '';

      // Parse HTTP status from response headers
      const statusMatch = output.match(/^HTTP\/[\d.]+\s+(\d+)/m);
      const statusCode = statusMatch ? parseInt(statusMatch[1], 10) : 0;

      // Split headers and body
      const headerBodySplit = output.indexOf('\r\n\r\n');
      const headerBodySplitAlt = output.indexOf('\n\n');
      const splitIdx = headerBodySplit >= 0 ? headerBodySplit + 4 : (headerBodySplitAlt >= 0 ? headerBodySplitAlt + 2 : -1);
      const responseHeaders = splitIdx > 0 ? output.substring(0, splitIdx).trim() : '';
      const responseBody = splitIdx > 0 ? output.substring(splitIdx).trim() : output;

      let parsedBody: any = null;
      try { parsedBody = JSON.parse(responseBody); } catch { parsedBody = null; }

      const success = statusCode >= 200 && statusCode < 300;

      res.json({
        success,
        statusCode,
        durationMs,
        curlCommand,
        responseHeaders,
        responseBody,
        parsedBody,
        stderr: stderr || null,
        hits: parsedBody?.hits?.hits || [],
        totalHits: typeof parsedBody?.hits?.total === 'object'
          ? parsedBody.hits.total.value
          : (parsedBody?.hits?.total ?? parsedBody?.hits?.hits?.length ?? 0),
        took: parsedBody?.took,
        clusterInfo: parsedBody, // for test-connection usage
        error: success ? null : (parsedBody?.error?.reason || parsedBody?.message || `HTTP ${statusCode}`),
      });
    } catch (e: any) {
      const durationMs = Date.now() - startTime;
      // execFile throws if curl is not found or times out
      const isCurlMissing = e.code === 'ENOENT' || (e.message || '').includes('ENOENT');
      res.status(502).json({
        success: false,
        durationMs,
        curlCommand,
        error: isCurlMissing
          ? 'curl is not installed or not found in PATH. Please install curl and ensure it is accessible.'
          : `curl execution failed: ${e.message}`,
        stderr: e.stderr || null,
        stdout: e.stdout || null,
      });
    }
  });

  // ─── Direct Raw cURL Execution Proxy ─────────────────────────────────────
  // Allows testing any raw cURL command entered directly by the user.
  // Parses shell string into argument array and executes via execFile ('curl').
  function parseRawCurlCommand(rawCmd: string): string[] {
    let cleaned = rawCmd.replace(/\\\r?\n/g, ' ').replace(/\^\r?\n/g, ' ').trim();
    if (cleaned.startsWith('curl.exe ')) {
      cleaned = cleaned.substring('curl.exe '.length).trim();
    } else if (cleaned.startsWith('curl ')) {
      cleaned = cleaned.substring('curl '.length).trim();
    } else if (cleaned === 'curl' || cleaned === 'curl.exe') {
      return [];
    }

    const args: string[] = [];
    let current = '';
    let inSingleQuote = false;
    let inDoubleQuote = false;
    let escape = false;

    for (let i = 0; i < cleaned.length; i++) {
      const char = cleaned[i];
      if (escape) {
        current += char;
        escape = false;
        continue;
      }
      if (char === '\\' && !inSingleQuote) {
        escape = true;
        continue;
      }
      if (char === "'" && !inDoubleQuote) {
        inSingleQuote = !inSingleQuote;
        continue;
      }
      if (char === '"' && !inSingleQuote) {
        inDoubleQuote = !inDoubleQuote;
        continue;
      }
      if ((char === ' ' || char === '\t' || char === '\r' || char === '\n') && !inSingleQuote && !inDoubleQuote) {
        if (current.length > 0) {
          args.push(current);
          current = '';
        }
        continue;
      }
      current += char;
    }
    if (current.length > 0) {
      args.push(current);
    }
    return args;
  }

  app.post('/api/curl-exec-raw', async (req, res) => {
    const { rawCommand, timeoutMs = 30000 } = req.body;

    if (!rawCommand || typeof rawCommand !== 'string' || !rawCommand.trim()) {
      return res.status(400).json({ success: false, error: 'Raw cURL command is required.' });
    }

    const trimmed = rawCommand.trim();
    let parsedArgs = parseRawCurlCommand(trimmed);

    if (parsedArgs.length === 0) {
      return res.status(400).json({ success: false, error: 'No arguments found in cURL command.' });
    }

    // Safety: ensure curl doesn't output to a file that overwrites system files via -o or -O if not intended
    // Ensure --include / -i is included so we get HTTP status code and response headers
    const hasInclude = parsedArgs.some(a => a === '-i' || a === '--include' || a === '-I' || a === '--head');
    const finalArgs = [...parsedArgs];
    if (!hasInclude) {
      finalArgs.unshift('-i');
    }
    // Ensure --show-error
    if (!finalArgs.some(a => a === '--show-error' || a === '-S')) {
      finalArgs.unshift('--show-error');
    }
    // Set max time if not provided
    if (!finalArgs.some(a => a === '-m' || a === '--max-time')) {
      finalArgs.unshift('--max-time', String(Math.ceil(timeoutMs / 1000)));
    }

    const startTime = Date.now();
    try {
      const { stdout, stderr } = await execFileAsync('curl', finalArgs, {
        timeout: timeoutMs + 3000,
        maxBuffer: 15 * 1024 * 1024, // 15MB
      });

      const durationMs = Date.now() - startTime;
      const output = stdout || '';

      // Find HTTP status code (handling potential multiple headers if redirects followed)
      const statusMatches = [...output.matchAll(/^HTTP\/[\d.]+\s+(\d+)(?:\s+(.*))?/gm)];
      let statusCode = 0;
      let statusText = '';
      if (statusMatches.length > 0) {
        const lastMatch = statusMatches[statusMatches.length - 1];
        statusCode = parseInt(lastMatch[1], 10);
        statusText = (lastMatch[2] || '').trim();
      }

      // Split headers and body from the last HTTP response block
      let responseHeaders = '';
      let responseBody = output;

      const doubleCrLf = '\r\n\r\n';
      const doubleLf = '\n\n';
      const lastSplitIndex = Math.max(output.lastIndexOf(doubleCrLf), output.lastIndexOf(doubleLf));

      if (lastSplitIndex >= 0) {
        const splitOffset = output.substr(lastSplitIndex, 4) === doubleCrLf ? 4 : 2;
        responseHeaders = output.substring(0, lastSplitIndex).trim();
        responseBody = output.substring(lastSplitIndex + splitOffset);
      }

      let parsedJson: any = null;
      try {
        parsedJson = JSON.parse(responseBody.trim());
      } catch {
        parsedJson = null;
      }

      const isSuccess = statusCode >= 200 && statusCode < 400;

      res.json({
        success: isSuccess || (statusCode > 0 && !stderr),
        statusCode: statusCode || 200,
        statusText,
        durationMs,
        rawCommand: trimmed,
        finalArgs,
        headers: responseHeaders,
        body: responseBody,
        parsedJson,
        stderr: stderr || null,
        error: isSuccess ? null : (parsedJson?.error?.reason || parsedJson?.message || (statusCode ? `HTTP ${statusCode} ${statusText}` : null)),
      });
    } catch (e: any) {
      const durationMs = Date.now() - startTime;
      const isCurlMissing = e.code === 'ENOENT' || (e.message || '').includes('ENOENT');
      res.status(502).json({
        success: false,
        statusCode: 0,
        durationMs,
        rawCommand: trimmed,
        finalArgs,
        headers: '',
        body: e.stdout || '',
        parsedJson: null,
        stderr: e.stderr || null,
        error: isCurlMissing
          ? 'curl command is not installed or not found in system PATH.'
          : `Execution failed: ${e.message}`,
      });
    }
  });

  // Catch-all for API routes to prevent returning HTML index.html for failed API requests
  app.all('/api/*', (req, res) => {
    res.status(404).json({
      success: false,
      error: `API route not found: ${req.method} ${req.originalUrl}. Check server routes.`,
    });
  });

  app.use('*', async (req, res, next) => {

    const url = req.originalUrl;
    try {
      let template = fs.readFileSync(path.resolve(__dirname, 'index.html'), 'utf-8');
      template = await vite.transformIndexHtml(url, template);
      res.status(200).set({ 'Content-Type': 'text/html' }).end(template);
    } catch (e) {
      vite.ssrFixStacktrace(e as Error);
      next(e);
    }
  });

  app.listen(3000, () => {
    console.log('Server running at http://localhost:3000');
  });
}

createServer();
