export interface RawCurlResponse {
  success: boolean;
  statusCode: number;
  statusText?: string;
  durationMs: number;
  rawCommand: string;
  finalArgs?: string[];
  headers?: string;
  body?: string;
  parsedJson?: any;
  stderr?: string | null;
  error?: string | null;
}

export interface CurlHistoryItem {
  id: string;
  timestamp: string;
  rawCommand: string;
  statusCode?: number;
  durationMs?: number;
  success: boolean;
  method?: string;
  url?: string;
}

const CURL_HISTORY_KEY = 'couch_curl_tester_history';

export const SAMPLE_CURL_COMMANDS = [
  {
    category: 'Elasticsearch',
    title: 'ES Cluster Health',
    command: 'curl -X GET "http://localhost:9200/_cluster/health?pretty"',
    desc: 'Check cluster status (green/yellow/red) and number of nodes/shards',
  },
  {
    category: 'Elasticsearch',
    title: 'ES Cat Indices',
    command: 'curl -X GET "http://localhost:9200/_cat/indices?v=true&s=index"',
    desc: 'List all indices with doc counts and storage sizes',
  },
  {
    category: 'Elasticsearch',
    title: 'ES Search Customers',
    command: `curl -X POST "http://localhost:9200/customers-*/_search?pretty" \\
  -H "Content-Type: application/json" \\
  -d '{"query": {"match_all": {}}, "size": 5}'`,
    desc: 'Match all query returning top 5 customer documents',
  },
  {
    category: 'Elasticsearch',
    title: 'ES Auth (Basic Auth)',
    command: `curl -u "elastic:changeme" -k -X GET "https://localhost:9200/_cluster/health?pretty"`,
    desc: 'HTTPS ES call with username:password and SSL bypass (-k)',
  },
  {
    category: 'Elasticsearch',
    title: 'ES Auth (API Key)',
    command: `curl -X GET "http://localhost:9200/_security/_authenticate?pretty" \\
  -H "Authorization: ApiKey YOUR_BASE64_API_KEY"`,
    desc: 'Verify authentication using Elasticsearch API Key',
  },
  {
    category: 'Elasticsearch',
    title: 'ES Kibana Cookie Login',
    command: `curl -X POST "http://localhost:5601/api/v1/auth/login" \\
  -H "Content-Type: application/json" \\
  -H "kbn-xsrf: true" \\
  -d '{"username":"elastic","password":"changeme"}'`,
    desc: 'Login to Kibana to obtain sid / cookie headers',
  },
  {
    category: 'CouchDB / General',
    title: 'CouchDB Server Ping',
    command: 'curl -X GET "http://localhost:5984/"',
    desc: 'Ping CouchDB server welcome message and version',
  },
  {
    category: 'General REST',
    title: 'JSONPlaceholder Test',
    command: 'curl -X GET "https://jsonplaceholder.typicode.com/posts/1"',
    desc: 'Quick public GET request to verify outbound connectivity',
  },
];

/**
 * Execute raw cURL command via backend proxy
 */
export async function executeRawCurl(rawCommand: string, timeoutMs: number = 30000): Promise<RawCurlResponse> {
  try {
    const res = await fetch('/api/curl-exec-raw', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ rawCommand, timeoutMs }),
    });
    const data = await res.json();
    return data as RawCurlResponse;
  } catch (err: any) {
    return {
      success: false,
      statusCode: 0,
      durationMs: 0,
      rawCommand,
      error: `Network error reaching cURL proxy: ${err.message}`,
    };
  }
}

/**
 * Extract quick method and url from curl command for summary pill display
 */
export function extractCurlSummary(cmd: string): { method: string; url: string } {
  let method = 'GET';
  const methodMatch = cmd.match(/-X\s+([A-Z]+)/i) || cmd.match(/--request\s+([A-Z]+)/i);
  if (methodMatch) {
    method = methodMatch[1].toUpperCase();
  } else if (cmd.includes(' -d ') || cmd.includes(' --data ') || cmd.includes(' --data-raw ')) {
    method = 'POST';
  }

  // Find URL (first token starting with http or https)
  const urlMatch = cmd.match(/["']?(https?:\/\/[^\s"']+)["']?/i);
  const url = urlMatch ? urlMatch[1] : '';

  return { method, url };
}

/**
 * Load curl history from localStorage
 */
export function loadCurlHistory(): CurlHistoryItem[] {
  try {
    const raw = localStorage.getItem(CURL_HISTORY_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

/**
 * Save item into history (max 30 items)
 */
export function saveCurlHistoryItem(item: Omit<CurlHistoryItem, 'id' | 'timestamp'>): CurlHistoryItem[] {
  try {
    const current = loadCurlHistory();
    const summary = extractCurlSummary(item.rawCommand);
    const newItem: CurlHistoryItem = {
      id: `curl-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`,
      timestamp: new Date().toISOString(),
      rawCommand: item.rawCommand,
      statusCode: item.statusCode,
      durationMs: item.durationMs,
      success: item.success,
      method: summary.method,
      url: summary.url,
    };
    // Dedup consecutive identical commands
    const filtered = current.filter(c => c.rawCommand.trim() !== item.rawCommand.trim());
    const updated = [newItem, ...filtered].slice(0, 30);
    localStorage.setItem(CURL_HISTORY_KEY, JSON.stringify(updated));
    return updated;
  } catch {
    return [];
  }
}

/**
 * Clear history
 */
export function clearCurlHistory(): void {
  try {
    localStorage.removeItem(CURL_HISTORY_KEY);
  } catch {
    // ignore
  }
}
