import React, { useState, useEffect, useMemo } from 'react';
import {
  Terminal, Play, Copy, Check, RotateCcw, Clock, Trash2,
  ExternalLink, AlertCircle, CheckCircle2, ChevronRight,
  Code, Sparkles, Filter, CornerDownLeft, Eye, ShieldAlert,
  ArrowRight
} from 'lucide-react';
import {
  executeRawCurl,
  RawCurlResponse,
  CurlHistoryItem,
  SAMPLE_CURL_COMMANDS,
  loadCurlHistory,
  saveCurlHistoryItem,
  clearCurlHistory,
  extractCurlSummary,
} from '../../../utils/curlTesterStorage';

interface CurlTesterViewProps {
  initialCommand?: string;
}

export const CurlTesterView: React.FC<CurlTesterViewProps> = ({ initialCommand }) => {
  const [command, setCommand] = useState<string>(
    initialCommand ||
      `curl -X GET "http://localhost:9200/_cluster/health?pretty"`
  );
  const [isRunning, setIsRunning] = useState<boolean>(false);
  const [result, setResult] = useState<RawCurlResponse | null>(null);
  const [activeTab, setActiveTab] = useState<'body' | 'headers' | 'raw' | 'details'>('body');
  const [copiedResponse, setCopiedResponse] = useState<boolean>(false);
  const [copiedCommand, setCopiedCommand] = useState<boolean>(false);
  const [history, setHistory] = useState<CurlHistoryItem[]>([]);
  const [searchHistory, setSearchHistory] = useState<string>('');
  const [showHistory, setShowHistory] = useState<boolean>(true);

  useEffect(() => {
    setHistory(loadCurlHistory());
  }, []);

  const handleRun = async () => {
    if (!command.trim() || isRunning) return;
    setIsRunning(true);
    setResult(null);

    const res = await executeRawCurl(command);
    setResult(res);
    setIsRunning(false);

    // Save to history
    const updatedHistory = saveCurlHistoryItem({
      rawCommand: command,
      statusCode: res.statusCode,
      durationMs: res.durationMs,
      success: res.success,
    });
    setHistory(updatedHistory);
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') {
      e.preventDefault();
      handleRun();
    }
  };

  const copyToClipboard = (text: string, setCopied: (v: boolean) => void) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleClearHistory = () => {
    if (confirm('Are you sure you want to clear your cURL execution history?')) {
      clearCurlHistory();
      setHistory([]);
    }
  };

  const filteredHistory = useMemo(() => {
    if (!searchHistory.trim()) return history;
    const q = searchHistory.toLowerCase();
    return history.filter(
      h =>
        h.rawCommand.toLowerCase().includes(q) ||
        (h.method && h.method.toLowerCase().includes(q)) ||
        (h.url && h.url.toLowerCase().includes(q))
    );
  }, [history, searchHistory]);

  const summary = useMemo(() => extractCurlSummary(command), [command]);

  // Parse headers into key-value pairs
  const parsedHeaders = useMemo(() => {
    if (!result?.headers) return [];
    const lines = result.headers.split(/\r?\n/);
    const list: { key: string; value: string }[] = [];
    for (const line of lines) {
      if (line.startsWith('HTTP/')) {
        list.push({ key: 'Status-Line', value: line });
        continue;
      }
      const colon = line.indexOf(':');
      if (colon > 0) {
        list.push({
          key: line.substring(0, colon).trim(),
          value: line.substring(colon + 1).trim(),
        });
      }
    }
    return list;
  }, [result?.headers]);

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 rounded-2xl p-6 text-white shadow-lg border border-indigo-900/40 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-96 h-96 bg-indigo-500/10 rounded-full blur-3xl pointer-events-none"></div>
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="flex items-center gap-2.5">
              <div className="p-2 rounded-xl bg-indigo-500/20 border border-indigo-400/30 text-indigo-300">
                <Terminal className="w-5 h-5" />
              </div>
              <h2 className="text-xl font-bold tracking-tight text-white flex items-center gap-2">
                cURL Direct Tester
                <span className="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded-full bg-indigo-500/30 text-indigo-200 border border-indigo-400/30">
                  Native CLI Proxy
                </span>
              </h2>
            </div>
            <p className="text-xs text-slate-300 max-w-2xl leading-relaxed">
              Paste any raw <code className="text-indigo-300 bg-indigo-950/60 px-1 py-0.5 rounded font-mono">curl</code> command to test directly without browser CORS restrictions or REST driver limitations. Supports flags like <code className="text-amber-300 bg-indigo-950/60 px-1 py-0.5 rounded font-mono">-u</code>, <code className="text-amber-300 bg-indigo-950/60 px-1 py-0.5 rounded font-mono">-H</code>, <code className="text-amber-300 bg-indigo-950/60 px-1 py-0.5 rounded font-mono">-d</code>, <code className="text-amber-300 bg-indigo-950/60 px-1 py-0.5 rounded font-mono">-k</code> (insecure), and cookie headers.
            </p>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <button
              onClick={() => setShowHistory(!showHistory)}
              className={`px-3 py-2 text-xs font-semibold rounded-xl border transition-all flex items-center gap-1.5 cursor-pointer ${
                showHistory
                  ? 'bg-indigo-600/30 text-indigo-200 border-indigo-400/40'
                  : 'bg-white/10 hover:bg-white/15 text-slate-200 border-white/10'
              }`}
            >
              <Clock className="w-3.5 h-3.5" />
              <span>History ({history.length})</span>
            </button>
          </div>
        </div>

        {/* Quick Sample Presets */}
        <div className="mt-5 pt-4 border-t border-slate-800/80 flex items-center gap-2 flex-wrap">
          <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1 mr-1">
            <Sparkles className="w-3 h-3 text-indigo-400" /> Presets:
          </span>
          {SAMPLE_CURL_COMMANDS.map((sample, idx) => (
            <button
              key={idx}
              onClick={() => {
                setCommand(sample.command);
                setResult(null);
              }}
              className="text-[11px] font-medium bg-slate-800/70 hover:bg-indigo-600/30 text-slate-300 hover:text-white px-2.5 py-1 rounded-lg border border-slate-700/60 hover:border-indigo-400/50 transition-all cursor-pointer flex items-center gap-1"
              title={sample.desc}
            >
              <span>{sample.title}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Main Workspace Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left / Main Column: Input Editor & Response (8 cols if history open, else 12) */}
        <div className={`${showHistory ? 'lg:col-span-8' : 'lg:col-span-12'} space-y-6 transition-all`}>
          {/* Command Editor Box */}
          <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
            <div className="px-4 py-3 bg-slate-50/80 border-b border-slate-100 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-rose-400"></span>
                <span className="w-2.5 h-2.5 rounded-full bg-amber-400"></span>
                <span className="w-2.5 h-2.5 rounded-full bg-emerald-400"></span>
                <span className="ml-2 text-xs font-bold text-slate-700 font-mono">cURL Command</span>
                {summary.method && (
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-indigo-100 text-indigo-700">
                    {summary.method}
                  </span>
                )}
                {summary.url && (
                  <span className="text-[11px] text-slate-400 truncate max-w-xs font-mono">
                    {summary.url}
                  </span>
                )}
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => copyToClipboard(command, setCopiedCommand)}
                  className="px-2.5 py-1 text-xs font-medium text-slate-600 hover:text-slate-900 bg-white hover:bg-slate-100 border border-slate-200 rounded-lg transition-all flex items-center gap-1 cursor-pointer"
                  title="Copy command"
                >
                  {copiedCommand ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copiedCommand ? 'Copied' : 'Copy'}</span>
                </button>
                <button
                  type="button"
                  onClick={() => setCommand('')}
                  className="px-2.5 py-1 text-xs font-medium text-slate-600 hover:text-rose-600 bg-white hover:bg-slate-100 border border-slate-200 rounded-lg transition-all flex items-center gap-1 cursor-pointer"
                  title="Clear command"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  <span>Clear</span>
                </button>
              </div>
            </div>

            {/* Textarea */}
            <div className="relative bg-slate-950 p-3">
              <textarea
                value={command}
                onChange={(e) => setCommand(e.target.value)}
                onKeyDown={handleKeyDown}
                placeholder="Enter or paste any curl command here... (e.g. curl -X GET 'http://localhost:9200/_cat/indices?v')"
                rows={6}
                className="w-full bg-transparent text-emerald-400 font-mono text-xs leading-relaxed focus:outline-none resize-y selection:bg-indigo-600 selection:text-white"
                spellCheck={false}
              />
            </div>

            {/* Bottom Actions Bar */}
            <div className="p-3.5 bg-slate-50 border-t border-slate-100 flex items-center justify-between">
              <div className="flex items-center gap-2 text-xs text-slate-500">
                <span className="hidden sm:inline">Press</span>
                <kbd className="px-2 py-0.5 text-[10px] font-mono bg-white border border-slate-300 rounded shadow-2xs font-bold text-slate-700">
                  Ctrl + Enter
                </kbd>
                <span className="hidden sm:inline">to execute directly</span>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={handleRun}
                  disabled={isRunning || !command.trim()}
                  className={`px-5 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 cursor-pointer shadow-sm ${
                    isRunning
                      ? 'bg-slate-200 text-slate-400 cursor-not-allowed'
                      : 'bg-indigo-600 hover:bg-indigo-700 active:scale-95 text-white shadow-indigo-600/20'
                  }`}
                >
                  {isRunning ? (
                    <>
                      <div className="w-3.5 h-3.5 border-2 border-slate-400 border-t-transparent rounded-full animate-spin"></div>
                      <span>Executing cURL...</span>
                    </>
                  ) : (
                    <>
                      <Play className="w-3.5 h-3.5 fill-current" />
                      <span>Run cURL</span>
                    </>
                  )}
                </button>
              </div>
            </div>
          </div>

          {/* Response Inspector */}
          {result && (
            <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
              {/* Response Header Strip */}
              <div className="px-5 py-3.5 border-b border-slate-100 flex flex-wrap items-center justify-between gap-3 bg-slate-50/70">
                <div className="flex items-center gap-3">
                  <span className="text-xs font-extrabold text-slate-800 uppercase tracking-wider">
                    Response
                  </span>

                  {/* Status Badge */}
                  {result.statusCode > 0 && (
                    <span
                      className={`text-xs font-black px-2.5 py-0.5 rounded-lg flex items-center gap-1 ${
                        result.statusCode >= 200 && result.statusCode < 300
                          ? 'bg-emerald-100 text-emerald-800 border border-emerald-200'
                          : result.statusCode >= 300 && result.statusCode < 400
                          ? 'bg-sky-100 text-sky-800 border border-sky-200'
                          : result.statusCode >= 400 && result.statusCode < 500
                          ? 'bg-amber-100 text-amber-800 border border-amber-200'
                          : 'bg-rose-100 text-rose-800 border border-rose-200'
                      }`}
                    >
                      {result.statusCode >= 200 && result.statusCode < 300 ? (
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                      ) : (
                        <AlertCircle className="w-3.5 h-3.5 text-rose-600" />
                      )}
                      <span>
                        {result.statusCode} {result.statusText || ''}
                      </span>
                    </span>
                  )}

                  {/* Duration Pill */}
                  <span className="text-[11px] font-semibold text-slate-500 bg-white border border-slate-200 px-2 py-0.5 rounded-md flex items-center gap-1">
                    <Clock className="w-3 h-3 text-slate-400" />
                    <span>{result.durationMs} ms</span>
                  </span>

                  {/* Size Pill */}
                  {result.body && (
                    <span className="text-[11px] font-semibold text-slate-500 bg-white border border-slate-200 px-2 py-0.5 rounded-md">
                      {(new Blob([result.body]).size / 1024).toFixed(2)} KB
                    </span>
                  )}
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => copyToClipboard(result.body || '', setCopiedResponse)}
                    className="px-2.5 py-1 text-xs font-semibold text-slate-600 hover:text-slate-900 bg-white border border-slate-200 rounded-lg transition-all flex items-center gap-1 cursor-pointer"
                  >
                    {copiedResponse ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{copiedResponse ? 'Copied' : 'Copy Body'}</span>
                  </button>
                </div>
              </div>

              {/* Error Alert Box if any */}
              {result.error && (
                <div className="p-4 bg-rose-50 border-b border-rose-100 flex items-start gap-3">
                  <ShieldAlert className="w-5 h-5 text-rose-600 shrink-0 mt-0.5" />
                  <div className="space-y-1">
                    <div className="text-xs font-bold text-rose-900">Request Error or Failure</div>
                    <div className="text-xs text-rose-700 font-mono break-all">{result.error}</div>
                    {result.stderr && (
                      <div className="mt-2 text-[11px] text-rose-800 bg-rose-100/70 p-2 rounded-lg font-mono whitespace-pre-wrap">
                        {result.stderr}
                      </div>
                    )}
                  </div>
                </div>
              )}

              {/* Tabs */}
              <div className="px-4 border-b border-slate-200 flex items-center space-x-4 bg-white text-xs font-semibold">
                <button
                  onClick={() => setActiveTab('body')}
                  className={`py-2.5 border-b-2 transition-all cursor-pointer flex items-center gap-1.5 ${
                    activeTab === 'body'
                      ? 'border-indigo-600 text-indigo-600 font-bold'
                      : 'border-transparent text-slate-500 hover:text-slate-800'
                  }`}
                >
                  <Code className="w-3.5 h-3.5" />
                  <span>Formatted Body {result.parsedJson ? '(JSON)' : ''}</span>
                </button>

                <button
                  onClick={() => setActiveTab('headers')}
                  className={`py-2.5 border-b-2 transition-all cursor-pointer flex items-center gap-1.5 ${
                    activeTab === 'headers'
                      ? 'border-indigo-600 text-indigo-600 font-bold'
                      : 'border-transparent text-slate-500 hover:text-slate-800'
                  }`}
                >
                  <Filter className="w-3.5 h-3.5" />
                  <span>Headers ({parsedHeaders.length})</span>
                </button>

                <button
                  onClick={() => setActiveTab('raw')}
                  className={`py-2.5 border-b-2 transition-all cursor-pointer flex items-center gap-1.5 ${
                    activeTab === 'raw'
                      ? 'border-indigo-600 text-indigo-600 font-bold'
                      : 'border-transparent text-slate-500 hover:text-slate-800'
                  }`}
                >
                  <Eye className="w-3.5 h-3.5" />
                  <span>Raw Output</span>
                </button>

                <button
                  onClick={() => setActiveTab('details')}
                  className={`py-2.5 border-b-2 transition-all cursor-pointer flex items-center gap-1.5 ${
                    activeTab === 'details'
                      ? 'border-indigo-600 text-indigo-600 font-bold'
                      : 'border-transparent text-slate-500 hover:text-slate-800'
                  }`}
                >
                  <Terminal className="w-3.5 h-3.5" />
                  <span>CLI Debug Info</span>
                </button>
              </div>

              {/* Tab Contents */}
              <div className="p-4 bg-slate-950 min-h-[260px] max-h-[500px] overflow-y-auto">
                {activeTab === 'body' && (
                  <pre className="text-xs font-mono text-slate-100 whitespace-pre-wrap break-all leading-relaxed">
                    {result.parsedJson
                      ? JSON.stringify(result.parsedJson, null, 2)
                      : result.body || '(Empty response body)'}
                  </pre>
                )}

                {activeTab === 'headers' && (
                  <div className="space-y-2">
                    {parsedHeaders.length === 0 ? (
                      <div className="text-xs text-slate-400 font-mono">No response headers captured.</div>
                    ) : (
                      <div className="divide-y divide-slate-800 font-mono text-xs">
                        {parsedHeaders.map((h, i) => (
                          <div key={i} className="py-1.5 flex flex-col sm:flex-row sm:items-start gap-1 sm:gap-4">
                            <span className="text-indigo-400 font-semibold shrink-0 sm:w-48">{h.key}:</span>
                            <span className="text-slate-200 break-all">{h.value}</span>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                )}

                {activeTab === 'raw' && (
                  <pre className="text-xs font-mono text-slate-300 whitespace-pre-wrap break-all leading-relaxed">
                    {result.headers ? `${result.headers}\n\n${result.body || ''}` : result.body || '(Empty)'}
                  </pre>
                )}

                {activeTab === 'details' && (
                  <div className="space-y-3 font-mono text-xs">
                    <div>
                      <div className="text-slate-400 font-semibold mb-1">Executed cURL Binary Arguments:</div>
                      <div className="bg-slate-900 p-2.5 rounded-lg text-amber-300 break-all leading-relaxed">
                        curl {result.finalArgs?.map(a => (a.includes(' ') ? `"${a}"` : a)).join(' ')}
                      </div>
                    </div>

                    {result.stderr && (
                      <div>
                        <div className="text-slate-400 font-semibold mb-1">cURL Standard Error (stderr):</div>
                        <pre className="bg-slate-900 p-2.5 rounded-lg text-rose-300 whitespace-pre-wrap">
                          {result.stderr}
                        </pre>
                      </div>
                    )}
                  </div>
                )}
              </div>
            </div>
          )}
        </div>

        {/* Right Column: Execution History Sidebar */}
        {showHistory && (
          <div className="lg:col-span-4 bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden flex flex-col sticky top-4">
            <div className="p-3.5 bg-slate-50 border-b border-slate-100 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Clock className="w-4 h-4 text-indigo-600" />
                <span className="text-xs font-bold text-slate-800">Recent Tests ({history.length})</span>
              </div>
              {history.length > 0 && (
                <button
                  onClick={handleClearHistory}
                  className="text-[11px] font-semibold text-slate-500 hover:text-rose-600 transition-colors flex items-center gap-1 cursor-pointer"
                  title="Clear history"
                >
                  <Trash2 className="w-3 h-3" />
                  <span>Clear</span>
                </button>
              )}
            </div>

            {/* Filter Search */}
            {history.length > 3 && (
              <div className="p-2.5 border-b border-slate-100">
                <div className="relative">
                  <Filter className="w-3 h-3 text-slate-400 absolute left-2.5 top-2.5" />
                  <input
                    type="text"
                    value={searchHistory}
                    onChange={(e) => setSearchHistory(e.target.value)}
                    placeholder="Search history..."
                    className="w-full pl-8 pr-2 py-1 text-xs bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:border-indigo-600 font-sans"
                  />
                </div>
              </div>
            )}

            {/* History List */}
            <div className="divide-y divide-slate-100 max-h-[550px] overflow-y-auto">
              {filteredHistory.length === 0 ? (
                <div className="p-6 text-center text-xs text-slate-400 space-y-2">
                  <Terminal className="w-6 h-6 text-slate-300 mx-auto" />
                  <p>No cURL executions recorded yet.</p>
                  <p className="text-[11px] text-slate-400">Run any command to keep history here.</p>
                </div>
              ) : (
                filteredHistory.map((item) => (
                  <div
                    key={item.id}
                    onClick={() => {
                      setCommand(item.rawCommand);
                    }}
                    className="p-3 hover:bg-slate-50 transition-colors cursor-pointer group space-y-1.5"
                  >
                    <div className="flex items-center justify-between text-[11px]">
                      <div className="flex items-center gap-1.5">
                        <span
                          className={`font-mono font-bold text-[10px] px-1.5 py-0.2 rounded ${
                            item.method === 'GET'
                              ? 'bg-sky-100 text-sky-700'
                              : item.method === 'POST'
                              ? 'bg-emerald-100 text-emerald-700'
                              : item.method === 'DELETE'
                              ? 'bg-rose-100 text-rose-700'
                              : 'bg-amber-100 text-amber-700'
                          }`}
                        >
                          {item.method || 'CURL'}
                        </span>
                        {item.statusCode !== undefined && (
                          <span
                            className={`font-bold font-mono text-[10px] px-1 rounded ${
                              item.success ? 'text-emerald-600 bg-emerald-50' : 'text-rose-600 bg-rose-50'
                            }`}
                          >
                            {item.statusCode}
                          </span>
                        )}
                      </div>

                      <span className="text-[10px] text-slate-400 font-medium">
                        {new Date(item.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                      </span>
                    </div>

                    <div className="font-mono text-xs text-slate-700 truncate group-hover:text-indigo-600 transition-colors">
                      {item.url || item.rawCommand}
                    </div>

                    <div className="flex items-center justify-between text-[10px] text-slate-400">
                      <span>{item.durationMs ? `${item.durationMs}ms` : ''}</span>
                      <span className="text-indigo-500 font-medium opacity-0 group-hover:opacity-100 transition-opacity flex items-center gap-0.5">
                        Load <ArrowRight className="w-2.5 h-2.5" />
                      </span>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
