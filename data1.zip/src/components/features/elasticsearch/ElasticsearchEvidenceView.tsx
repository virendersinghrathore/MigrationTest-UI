import React, { useState, useEffect, useMemo } from 'react';
import {
  Database,
  Activity,
  Play,
  Plus,
  RefreshCw,
  Sliders,
  CheckCircle2,
  AlertTriangle,
  FolderArchive,
  Download,
  Copy,
  Check,
  Search,
  Trash2,
  Edit3,
  Layers,
  Sparkles,
  ExternalLink,
  ShieldCheck,
  FileText,
  Clock,
  ArrowRight,
  Terminal,
  ChevronDown,
  ChevronRight,
  XCircle,
  Globe
} from 'lucide-react';
import {
  EsConnectionConfig,
  EsClusterInfo,
  EsQueryItem,
  EsQueryResult,
  EsEvidencePackage,
} from '../../../types/elasticsearch';
import {
  loadEsConnectionConfig,
  saveEsConnectionConfig,
  loadSavedEsQueries,
  saveSavedEsQueries,
  loadSavedEvidencePackages,
  saveEvidencePackage,
  deleteEvidencePackage,
  testElasticsearchConnection,
  testElasticsearchConnectionCurl,
  executeElasticsearchQuery,
  executeElasticsearchQueryCurl,
  generateSimulatedEsResult,
  buildCurlCommandForQuery,
} from '../../../utils/elasticsearchStorage';
import { exportToJsonFile } from '../../../utils/jsonHelper';
import { EsConnectionModal } from './EsConnectionModal';
import { EsQueryEditorModal } from './EsQueryEditorModal';
import { EsSavedPackagesDrawer } from './EsSavedPackagesDrawer';

export const ElasticsearchEvidenceView: React.FC = () => {
  // Connection Config state
  const [config, setConfig] = useState<EsConnectionConfig>(() => loadEsConnectionConfig());
  const [clusterInfo, setClusterInfo] = useState<EsClusterInfo | null>(null);
  const [connectionStatus, setConnectionStatus] = useState<'UNTESTED' | 'CONNECTED' | 'ERROR'>('UNTESTED');
  const [connectionError, setConnectionError] = useState<string | null>(null);
  const [connectionErrorDetail, setConnectionErrorDetail] = useState<{
    rawOutput?: string; curlCommand?: string; statusCode?: number; stderr?: string;
  } | null>(null);
  const [showConnErrorDetail, setShowConnErrorDetail] = useState(false);
  const [isTestingConn, setIsTestingConn] = useState(false);

  // cURL mode — use curl binary on the server instead of fetch-based proxy
  const [isCurlMode, setIsCurlMode] = useState(() =>
    localStorage.getItem('couch_es_curl_mode') === 'true'
  );

  // Simulation mode (useful when live ES is not running)
  const [isSimulatedMode, setIsSimulatedMode] = useState(false);

  // Queries list
  const [queries, setQueries] = useState<EsQueryItem[]>(() => loadSavedEsQueries());

  // Execution Results (extended with curl info)
  const [results, setResults] = useState<(EsQueryResult & { curlCommand?: string; rawOutput?: string; responseHeaders?: string })[]>([]);
  const [activeResultQueryId, setActiveResultQueryId] = useState<string | null>(null);
  const [isRunningAll, setIsRunningAll] = useState(false);
  const [runningQueryId, setRunningQueryId] = useState<string | null>(null);
  const [expandedErrorQueryId, setExpandedErrorQueryId] = useState<string | null>(null);
  const [expandedCurlQueryId, setExpandedCurlQueryId] = useState<string | null>(null);

  // Modals & Drawers
  const [isConnModalOpen, setIsConnModalOpen] = useState(false);
  const [isQueryModalOpen, setIsQueryModalOpen] = useState(false);
  const [editingQuery, setEditingQuery] = useState<EsQueryItem | null>(null);
  const [isSavedDrawerOpen, setIsSavedDrawerOpen] = useState(false);
  const [savedPackages, setSavedPackages] = useState<EsEvidencePackage[]>(() => loadSavedEvidencePackages());

  // Search/Filter in Results
  const [resultFilter, setResultFilter] = useState('');
  const [copiedDocId, setCopiedDocId] = useState<string | null>(null);
  const [copiedCurl, setCopiedCurl] = useState<string | null>(null);

  // Auto test connection on mount if URL is configured
  useEffect(() => {
    if (config.url && connectionStatus === 'UNTESTED' && !isSimulatedMode) {
      handleTestConnection();
    }
  }, []);

  const handleTestConnection = async (customConfig?: EsConnectionConfig) => {
    setIsTestingConn(true);
    setConnectionError(null);
    setConnectionErrorDetail(null);
    setShowConnErrorDetail(false);
    const targetConfig = customConfig || config;
    try {
      const res = isCurlMode
        ? await testElasticsearchConnectionCurl(targetConfig)
        : await testElasticsearchConnection(targetConfig);
      if (res.success && res.clusterInfo) {
        setClusterInfo({ ...res.clusterInfo, health: res.health });
        setConnectionStatus('CONNECTED');
      } else {
        setConnectionStatus('ERROR');
        setConnectionError(res.error || 'Failed to reach cluster');
        setConnectionErrorDetail({
          curlCommand: (res as any).curlCommand,
          rawOutput: (res as any).rawOutput,
          statusCode: (res as any).statusCode,
        });
      }
    } catch (e: any) {
      setConnectionStatus('ERROR');
      setConnectionError(e.message);
    } finally {
      setIsTestingConn(false);
    }
  };

  const toggleCurlMode = (val: boolean) => {
    setIsCurlMode(val);
    localStorage.setItem('couch_es_curl_mode', String(val));
    // Reset connection status so user can re-test with new mode
    setConnectionStatus('UNTESTED');
    setConnectionError(null);
    setConnectionErrorDetail(null);
  };

  const handleSaveConfig = (newConfig: EsConnectionConfig) => {
    setConfig(newConfig);
    saveEsConnectionConfig(newConfig);
    handleTestConnection(newConfig);
  };

  // Query Management
  const handleSaveQuery = (queryItem: EsQueryItem) => {
    let updated: EsQueryItem[];
    const idx = queries.findIndex((q) => q.id === queryItem.id);
    if (idx >= 0) {
      updated = queries.map((q, i) => (i === idx ? queryItem : q));
    } else {
      updated = [...queries, queryItem];
    }
    setQueries(updated);
    saveSavedEsQueries(updated);
  };

  const handleDeleteQuery = (id: string) => {
    if (!window.confirm('Are you sure you want to delete this query?')) return;
    const updated = queries.filter((q) => q.id !== id);
    setQueries(updated);
    saveSavedEsQueries(updated);
    setResults((prev) => prev.filter((r) => r.queryId !== id));
  };

  const handleToggleQueryEnabled = (id: string) => {
    const updated = queries.map((q) => (q.id === id ? { ...q, enabled: !q.enabled } : q));
    setQueries(updated);
    saveSavedEsQueries(updated);
  };

  // Run a single query
  const handleRunSingleQuery = async (queryItem: EsQueryItem) => {
    setRunningQueryId(queryItem.id);
    let res: EsQueryResult & { curlCommand?: string; rawOutput?: string; responseHeaders?: string };

    if (isSimulatedMode) {
      await new Promise((r) => setTimeout(r, 400));
      res = generateSimulatedEsResult(queryItem, queryItem.linkedTestCase);
    } else if (isCurlMode) {
      res = await executeElasticsearchQueryCurl(config, queryItem);
    } else {
      res = await executeElasticsearchQuery(config, queryItem);
    }

    setResults((prev) => {
      const filtered = prev.filter((r) => r.queryId !== queryItem.id);
      return [res, ...filtered];
    });
    setActiveResultQueryId(queryItem.id);
    setRunningQueryId(null);
  };

  // Run all enabled queries
  const handleRunAllQueries = async () => {
    const enabledQueries = queries.filter((q) => q.enabled);
    if (enabledQueries.length === 0) {
      alert('No queries are currently enabled. Check the checkbox next to the queries you want to run.');
      return;
    }

    setIsRunningAll(true);
    const newResults: (EsQueryResult & { curlCommand?: string; rawOutput?: string })[] = [];

    for (const q of enabledQueries) {
      if (isSimulatedMode) {
        await new Promise((r) => setTimeout(r, 200));
        newResults.push(generateSimulatedEsResult(q, q.linkedTestCase));
      } else if (isCurlMode) {
        const res = await executeElasticsearchQueryCurl(config, q);
        newResults.push(res);
      } else {
        const res = await executeElasticsearchQuery(config, q);
        newResults.push(res);
      }
    }

    setResults(newResults);
    if (newResults.length > 0) {
      setActiveResultQueryId(newResults[0].queryId);
    }
    setIsRunningAll(false);
  };

  // Save full evidence package
  const handleSaveEvidencePackage = () => {
    if (results.length === 0) {
      alert('Run at least one query before saving an evidence package.');
      return;
    }

    const title = window.prompt(
      'Enter a name for this Evidence Package:',
      `Migration Test Evidence - ${new Date().toLocaleDateString()}`
    );
    if (!title) return;

    const newPackage: EsEvidencePackage = {
      id: `es-pkg-${Date.now()}`,
      title,
      createdAt: new Date().toISOString().replace('T', ' ').substring(0, 19),
      clusterUrl: isSimulatedMode ? 'simulated://localhost:9200' : config.url,
      clusterName: clusterInfo?.cluster_name || 'elasticsearch-cluster',
      results,
    };

    const updated = saveEvidencePackage(newPackage);
    setSavedPackages(updated);
    alert(`Evidence package "${title}" saved successfully!`);
  };

  const handleExportAll = () => {
    if (results.length === 0) {
      alert('No evidence results to export.');
      return;
    }
    const exportBundle = {
      exportedAt: new Date().toISOString(),
      clusterUrl: config.url,
      clusterInfo,
      isSimulated: isSimulatedMode,
      totalQueriesExecuted: results.length,
      evidenceResults: results,
    };
    exportToJsonFile(`es_evidence_bundle_${Date.now()}.json`, exportBundle);
  };

  // Currently selected result in evidence screen
  const activeResult = useMemo(() => {
    if (results.length === 0) return null;
    if (activeResultQueryId) {
      const found = results.find((r) => r.queryId === activeResultQueryId);
      if (found) return found;
    }
    return results[0];
  }, [results, activeResultQueryId]);

  const activeQuery = useMemo(() => {
    return queries.find((q) => q.id === activeResult?.queryId);
  }, [queries, activeResult]);

  const copyToClipboard = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedDocId(id);
    setTimeout(() => setCopiedDocId(null), 2000);
  };

  return (
    <div className="space-y-6">
      {/* Top Banner & Elasticsearch Cluster Status */}
      <div className="bg-white border border-slate-200 rounded-3xl p-6 shadow-xs">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 pb-5 border-b border-slate-100">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="p-1.5 bg-gradient-to-br from-amber-500 to-amber-700 text-white rounded-xl shadow-xs">
                <Database className="h-4 w-4" />
              </span>
              <h1 className="text-lg font-extrabold text-slate-900 tracking-tight">
                Elasticsearch Evidence Gathering
              </h1>
              <span className="text-[10px] font-extrabold uppercase px-2 py-0.5 rounded-full bg-amber-50 text-amber-700 border border-amber-200">
                Audit & Compliance
              </span>
            </div>
            <p className="text-xs text-slate-500">
              Execute Elasticsearch queries to capture audit evidence, verify migrated document indexing, and inspect cluster records.
            </p>
          </div>

          <div className="flex items-center flex-wrap gap-2">
            {/* cURL Mode Toggle */}
            <button
              onClick={() => toggleCurlMode(!isCurlMode)}
              className={`px-3 py-2 text-xs font-bold rounded-xl border transition-all flex items-center gap-1.5 cursor-pointer ${
                isCurlMode
                  ? 'bg-slate-800 text-emerald-400 border-slate-700 shadow-sm'
                  : 'bg-slate-50 text-slate-600 hover:bg-slate-100 border-slate-200'
              }`}
              title={isCurlMode ? 'cURL mode active — using curl binary via server proxy' : 'Switch to cURL mode — use system curl instead of fetch'}
            >
              <Terminal className="w-3.5 h-3.5" />
              <span>{isCurlMode ? 'cURL Mode: ON' : 'Use cURL'}</span>
            </button>

            <button
              onClick={() => setIsSimulatedMode(!isSimulatedMode)}
              className={`px-3 py-2 text-xs font-bold rounded-xl border transition-all flex items-center gap-1.5 cursor-pointer ${
                isSimulatedMode
                  ? 'bg-amber-500 text-white border-amber-600 shadow-sm'
                  : 'bg-slate-50 text-slate-600 hover:bg-slate-100 border-slate-200'
              }`}
              title="Toggle simulated/mock Elasticsearch mode if you do not have a live cluster running"
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>{isSimulatedMode ? 'Simulated Mode: ON' : 'Simulate ES (Demo)'}</span>
            </button>

            <button
              onClick={() => setIsConnModalOpen(true)}
              className="px-3.5 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold rounded-xl transition-all flex items-center gap-1.5 cursor-pointer"
            >
              <Sliders className="w-3.5 h-3.5 text-indigo-600" />
              <span>Configure Connection</span>
            </button>

            <button
              onClick={() => setIsSavedDrawerOpen(true)}
              className="px-3.5 py-2 bg-slate-100 hover:bg-indigo-50 text-slate-700 hover:text-indigo-700 text-xs font-bold rounded-xl border border-slate-200 transition-all flex items-center gap-1.5 cursor-pointer"
            >
              <FolderArchive className="w-3.5 h-3.5 text-indigo-600" />
              <span>Saved Evidence</span>
              {savedPackages.length > 0 && (
                <span className="px-1.5 py-0.2 rounded-full text-[10px] font-extrabold bg-indigo-600 text-white">
                  {savedPackages.length}
                </span>
              )}
            </button>

            <button
              onClick={handleSaveEvidencePackage}
              disabled={results.length === 0}
              className="px-4 py-2 bg-white hover:bg-slate-50 border border-indigo-300 text-indigo-700 disabled:opacity-50 text-xs font-bold rounded-xl shadow-xs transition-all flex items-center gap-1.5 cursor-pointer"
            >
              <FolderArchive className="w-3.5 h-3.5" />
              <span>Save Evidence Package</span>
            </button>

            <button
              onClick={handleRunAllQueries}
              disabled={isRunningAll || queries.filter((q) => q.enabled).length === 0}
              className="px-5 py-2 bg-amber-600 hover:bg-amber-700 disabled:bg-slate-300 text-white text-xs font-bold rounded-xl shadow-md shadow-amber-600/25 transition-all flex items-center gap-2 cursor-pointer"
            >
              {isRunningAll ? (
                <>
                  <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                  <span>Executing Queries...</span>
                </>
              ) : (
                <>
                  <Play className="w-3.5 h-3.5 fill-current" />
                  <span>Run All Queries ({queries.filter((q) => q.enabled).length})</span>
                </>
              )}
            </button>
          </div>
        </div>

        {/* Live Cluster Connection Strip */}
        <div className="pt-4 flex flex-col md:flex-row md:items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-3">
            <div
              className={`p-2 rounded-xl flex items-center gap-2 font-mono font-bold text-xs ${
                isSimulatedMode
                  ? 'bg-amber-50 text-amber-800 border border-amber-200'
                  : connectionStatus === 'CONNECTED'
                  ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
                  : connectionStatus === 'ERROR'
                  ? 'bg-rose-50 text-rose-800 border border-rose-200'
                  : 'bg-slate-100 text-slate-700 border border-slate-200'
              }`}
            >
              <span
                className={`w-2 h-2 rounded-full ${
                  isSimulatedMode
                    ? 'bg-amber-500 animate-pulse'
                    : connectionStatus === 'CONNECTED'
                    ? 'bg-emerald-500'
                    : connectionStatus === 'ERROR'
                    ? 'bg-rose-500'
                    : 'bg-slate-400'
                }`}
              />
              <span>
                {isSimulatedMode
                  ? 'Simulated Cluster (Offline Mode)'
                  : connectionStatus === 'CONNECTED'
                  ? `Connected: ${clusterInfo?.cluster_name || 'Elasticsearch'} (v${clusterInfo?.version?.number || '8.x'})`
                  : connectionStatus === 'ERROR'
                  ? 'Cluster Disconnected'
                  : 'Connection Untested'}
              </span>
            </div>

            <span className="font-mono text-slate-500 text-[11px] truncate max-w-[260px]">
              {isSimulatedMode ? 'simulated://localhost:9200' : config.url}
            </span>

            {config.authType !== 'none' && (
              <span className="text-[10px] uppercase font-mono px-2 py-0.5 rounded bg-slate-100 text-slate-600 font-bold border border-slate-200">
                Auth: {config.authType}
              </span>
            )}
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => handleTestConnection()}
              disabled={isTestingConn || isSimulatedMode}
              className="px-3 py-1 bg-slate-100 hover:bg-slate-200 disabled:opacity-40 text-slate-700 text-[11px] font-bold rounded-lg transition-all flex items-center gap-1 cursor-pointer"
            >
              <Activity className={`w-3 h-3 ${isTestingConn ? 'animate-spin' : 'text-amber-600'}`} />
              <span>{isTestingConn ? 'Testing...' : 'Test Connection'}</span>
            </button>
          </div>
        </div>

        {/* ── Connection Error Detail Panel ── */}
        {connectionError && !isSimulatedMode && connectionStatus === 'ERROR' && (
          <div className="mt-3 p-3.5 bg-rose-50 border border-rose-200 rounded-2xl text-xs space-y-2">
            <div className="flex items-start justify-between gap-2">
              <div className="flex items-center gap-2">
                <XCircle className="w-4 h-4 text-rose-600 shrink-0" />
                <span className="font-bold text-rose-800">Connection Failed</span>
                {connectionErrorDetail?.statusCode && (
                  <span className="font-mono px-1.5 py-0.5 rounded bg-rose-200 text-rose-900 text-[10px] font-bold">
                    HTTP {connectionErrorDetail.statusCode}
                  </span>
                )}
                {isCurlMode && (
                  <span className="font-mono px-1.5 py-0.5 rounded bg-slate-800 text-emerald-400 text-[10px] font-bold">
                    via curl
                  </span>
                )}
              </div>
              <button
                onClick={() => setShowConnErrorDetail((s) => !s)}
                className="flex items-center gap-1 text-[11px] font-bold text-rose-700 hover:text-rose-900 cursor-pointer shrink-0"
              >
                {showConnErrorDetail ? <ChevronDown className="w-3.5 h-3.5" /> : <ChevronRight className="w-3.5 h-3.5" />}
                {showConnErrorDetail ? 'Hide Details' : 'View Full Error Log'}
              </button>
            </div>
            <p className="text-rose-700 text-[11px] break-all">{connectionError}</p>
            {showConnErrorDetail && (
              <div className="space-y-2.5 pt-1 border-t border-rose-200">
                {connectionErrorDetail?.curlCommand && (
                  <div>
                    <p className="text-[10px] font-bold text-slate-600 mb-1 flex items-center gap-1">
                      <Terminal className="w-3 h-3" /> cURL Command Used
                    </p>
                    <pre className="bg-slate-900 text-emerald-400 text-[10px] font-mono p-2.5 rounded-xl overflow-x-auto whitespace-pre-wrap">{connectionErrorDetail.curlCommand}</pre>
                  </div>
                )}
                {connectionErrorDetail?.rawOutput && (
                  <div>
                    <p className="text-[10px] font-bold text-slate-600 mb-1">Raw Response Output</p>
                    <pre className="bg-white border border-rose-200 text-rose-800 text-[10px] font-mono p-2.5 rounded-xl max-h-48 overflow-y-auto whitespace-pre-wrap break-all">{connectionErrorDetail.rawOutput}</pre>
                  </div>
                )}
                {!connectionErrorDetail?.curlCommand && (
                  <div className="text-[11px] text-slate-600 bg-white border border-slate-200 rounded-xl p-3">
                    <p className="font-bold mb-1">Troubleshooting Tips:</p>
                    <ul className="space-y-1 list-disc list-inside">
                      <li>Verify the cluster URL is reachable from this machine</li>
                      <li>Check auth credentials in Connection Settings</li>
                      <li>Enable <strong>cURL Mode</strong> to use system curl (bypasses Node.js fetch restrictions)</li>
                      <li>Try <code className="bg-slate-100 px-1 rounded">curl -v {config.url}/</code> in a terminal</li>
                    </ul>
                  </div>
                )}
              </div>
            )}
          </div>
        )}
      </div>

      {/* Main Grid: Left Column Queries List, Right Column Evidence Showcase */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left Column: Configurable Queries (4 cols) */}
        <div className="lg:col-span-5 bg-white border border-slate-200 rounded-3xl p-5 shadow-xs space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <div>
              <h3 className="text-sm font-bold text-slate-900">Configured Evidence Queries</h3>
              <p className="text-[11px] text-slate-500">
                {queries.length} query templates configured
              </p>
            </div>

            <button
              onClick={() => {
                setEditingQuery(null);
                setIsQueryModalOpen(true);
              }}
              className="px-3 py-1.5 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 text-xs font-bold rounded-xl transition-all flex items-center gap-1 cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Add Query</span>
            </button>
          </div>

          {/* Query Cards */}
          <div className="space-y-3">
            {queries.map((q) => {
              const queryResult = results.find((r) => r.queryId === q.id);
              const isRunningThis = runningQueryId === q.id;
              const isSelected = activeResult?.queryId === q.id;

              return (
                <div
                  key={q.id}
                  onClick={() => {
                    if (queryResult) setActiveResultQueryId(q.id);
                  }}
                  className={`p-4 rounded-2xl border transition-all cursor-pointer ${
                    isSelected
                      ? 'border-indigo-600 ring-2 ring-indigo-600/10 bg-indigo-50/20'
                      : 'border-slate-200 hover:border-slate-300 bg-white'
                  }`}
                >
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex items-start gap-2.5">
                      <input
                        type="checkbox"
                        checked={q.enabled}
                        onChange={(e) => {
                          e.stopPropagation();
                          handleToggleQueryEnabled(q.id);
                        }}
                        className="mt-1 rounded text-indigo-600 focus:ring-indigo-500 cursor-pointer"
                        title="Include in Run All Queries"
                      />
                      <div>
                        <h4 className="text-xs font-bold text-slate-900 leading-snug">{q.title}</h4>
                        <div className="flex items-center gap-1.5 mt-1">
                          <span className="text-[10px] font-mono font-bold px-1.5 py-0.2 rounded bg-slate-100 text-slate-700 border border-slate-200">
                            {q.method}
                          </span>
                          <span className="text-[11px] font-mono text-slate-500 truncate max-w-[170px]">
                            {q.index}
                          </span>
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-1 shrink-0">
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          setEditingQuery(q);
                          setIsQueryModalOpen(true);
                        }}
                        className="p-1 text-slate-400 hover:text-slate-700 rounded hover:bg-slate-100 cursor-pointer"
                        title="Edit Query"
                      >
                        <Edit3 className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          handleDeleteQuery(q.id);
                        }}
                        className="p-1 text-slate-400 hover:text-rose-600 rounded hover:bg-rose-50 cursor-pointer"
                        title="Delete Query"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          handleRunSingleQuery(q);
                        }}
                        disabled={isRunningThis}
                        className="px-2.5 py-1 bg-amber-50 hover:bg-amber-100 text-amber-700 rounded-lg text-xs font-bold flex items-center gap-1 cursor-pointer transition-colors"
                        title="Execute Query"
                      >
                        {isRunningThis ? (
                          <RefreshCw className="w-3 h-3 animate-spin" />
                        ) : (
                          <Play className="w-3 h-3 fill-current" />
                        )}
                        <span>Run</span>
                      </button>
                    </div>
                  </div>

                  {/* Query Result Status Strip */}
                  {queryResult && (
                    <div className="mt-3 pt-2.5 border-t border-slate-100 space-y-2">
                      <div className="flex items-center justify-between text-[11px]">
                        <div className="flex items-center gap-1.5 font-bold">
                          {queryResult.status === 'SUCCESS' ? (
                            <>
                              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                              <span className="text-emerald-700">
                                {queryResult.totalHits} hit{queryResult.totalHits === 1 ? '' : 's'} ({queryResult.durationMs}ms)
                              </span>
                            </>
                          ) : (
                            <>
                              <AlertTriangle className="w-3.5 h-3.5 text-rose-600" />
                              <span className="text-rose-700">Execution Error</span>
                              <button
                                onClick={(e) => {
                                  e.stopPropagation();
                                  setExpandedErrorQueryId(expandedErrorQueryId === q.id ? null : q.id);
                                }}
                                className="ml-1 text-[10px] font-bold text-rose-600 hover:text-rose-800 underline cursor-pointer"
                              >
                                {expandedErrorQueryId === q.id ? 'Hide' : 'View Error Log'}
                              </button>
                            </>
                          )}
                        </div>
                        <div className="flex items-center gap-2">
                          {/* cURL command copy button */}
                          {(isCurlMode || (queryResult as any).curlCommand) && (
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                const cmd = (queryResult as any).curlCommand || buildCurlCommandForQuery(config, q);
                                navigator.clipboard.writeText(cmd);
                                setCopiedCurl(q.id);
                                setTimeout(() => setCopiedCurl(null), 2000);
                              }}
                              className={`flex items-center gap-1 text-[10px] font-bold px-1.5 py-0.5 rounded cursor-pointer transition-all ${
                                copiedCurl === q.id
                                  ? 'bg-emerald-100 text-emerald-700'
                                  : 'bg-slate-800 text-emerald-400 hover:bg-slate-700'
                              }`}
                              title="Copy curl command"
                            >
                              {copiedCurl === q.id ? <Check className="w-3 h-3" /> : <Terminal className="w-3 h-3" />}
                              <span>{copiedCurl === q.id ? 'Copied!' : 'cURL'}</span>
                            </button>
                          )}
                          <span className="text-[10px] text-slate-400 font-mono">
                            {queryResult.executedAt.slice(11)}
                          </span>
                        </div>
                      </div>

                      {/* Error Detail Expandable */}
                      {queryResult.status === 'ERROR' && expandedErrorQueryId === q.id && (
                        <div
                          className="space-y-2 p-3 bg-rose-50 border border-rose-200 rounded-xl text-[11px]"
                          onClick={(e) => e.stopPropagation()}
                        >
                          {queryResult.errorMessage && (
                            <p className="text-rose-800 font-medium break-all">{queryResult.errorMessage}</p>
                          )}
                          {(queryResult as any).curlCommand && (
                            <div>
                              <p className="text-[10px] font-bold text-slate-600 mb-1 flex items-center gap-1">
                                <Terminal className="w-3 h-3" /> cURL Command
                              </p>
                              <pre className="bg-slate-900 text-emerald-400 text-[10px] font-mono p-2 rounded-lg overflow-x-auto whitespace-pre-wrap">{(queryResult as any).curlCommand}</pre>
                            </div>
                          )}
                          {(queryResult as any).rawOutput && (
                            <div>
                              <p className="text-[10px] font-bold text-slate-600 mb-1">Raw Server Response</p>
                              <pre className="bg-white border border-rose-200 text-rose-900 text-[10px] font-mono p-2 rounded-lg max-h-36 overflow-y-auto whitespace-pre-wrap break-all">{(queryResult as any).rawOutput}</pre>
                            </div>
                          )}
                          {queryResult.rawResponse && (
                            <div>
                              <p className="text-[10px] font-bold text-slate-600 mb-1">Parsed Error Response</p>
                              <pre className="bg-white border border-rose-200 text-rose-900 text-[10px] font-mono p-2 rounded-lg max-h-36 overflow-y-auto">{JSON.stringify(queryResult.rawResponse, null, 2)}</pre>
                            </div>
                          )}
                        </div>
                      )}

                      {/* cURL Command Preview (expandable) */}
                      {expandedCurlQueryId === q.id && queryResult.status === 'SUCCESS' && (
                        <div
                          className="p-2.5 bg-slate-900 rounded-xl"
                          onClick={(e) => e.stopPropagation()}
                        >
                          <p className="text-[9px] font-bold text-slate-400 mb-1.5 uppercase tracking-wider">cURL Command</p>
                          <pre className="text-emerald-400 text-[10px] font-mono whitespace-pre-wrap overflow-x-auto">
                            {(queryResult as any).curlCommand || buildCurlCommandForQuery(config, q)}
                          </pre>
                        </div>
                      )}
                    </div>
                  )}

                </div>
              );
            })}
          </div>
        </div>

        {/* Right Column: Evidence Showcase & Multiple Queries Results (7 cols) */}
        <div className="lg:col-span-7 bg-white border border-slate-200 rounded-3xl p-6 shadow-xs space-y-5">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-100">
            <div>
              <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                <span>Elasticsearch Evidence Results Screen</span>
                {results.length > 0 && (
                  <span className="text-[10px] font-extrabold px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-700 border border-emerald-200">
                    {results.length} Executed
                  </span>
                )}
              </h3>
              <p className="text-[11px] text-slate-500">
                View captured audit records, document hits, and inspection details across all executed queries.
              </p>
            </div>

            {results.length > 0 && (
              <button
                onClick={handleExportAll}
                className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold rounded-xl transition-all flex items-center gap-1.5 cursor-pointer self-start sm:self-auto"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Export Evidence Bundle</span>
              </button>
            )}
          </div>

          {/* Results Navigation Tabs for Multiple Queries */}
          {results.length > 0 && (
            <div className="flex items-center gap-2 overflow-x-auto pb-1 border-b border-slate-100">
              {results.map((r, idx) => {
                const isActive = activeResult?.queryId === r.queryId;
                return (
                  <button
                    key={r.queryId}
                    onClick={() => setActiveResultQueryId(r.queryId)}
                    className={`px-3 py-2 rounded-xl text-xs font-bold transition-all whitespace-nowrap cursor-pointer flex items-center gap-2 ${
                      isActive
                        ? 'bg-slate-900 text-white shadow-xs'
                        : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
                    }`}
                  >
                    <span>{`Query ${idx + 1}`}</span>
                    <span
                      className={`text-[10px] font-extrabold px-1.5 py-0.2 rounded-md ${
                        isActive
                          ? 'bg-slate-800 text-amber-300'
                          : r.status === 'SUCCESS' && r.totalHits > 0
                          ? 'bg-emerald-100 text-emerald-800'
                          : 'bg-slate-200 text-slate-600'
                      }`}
                    >
                      {r.totalHits} Hits
                    </span>
                  </button>
                );
              })}
            </div>
          )}

          {/* Active Result Detail Pane */}
          {activeResult ? (
            <div className="space-y-4 animate-fadeIn">
              {/* Evidence Header & Stats */}
              <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200/80 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="font-mono text-xs font-bold text-slate-900">
                      {activeResult.queryTitle}
                    </span>
                    <span
                      className={`text-[10px] font-extrabold px-2 py-0.5 rounded-full ${
                        activeResult.status === 'SUCCESS' && activeResult.totalHits > 0
                          ? 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                          : activeResult.status === 'SUCCESS'
                          ? 'bg-amber-100 text-amber-800 border border-amber-300'
                          : 'bg-rose-100 text-rose-800 border border-rose-300'
                      }`}
                    >
                      {activeResult.status === 'SUCCESS' && activeResult.totalHits > 0
                        ? 'Evidence Verified'
                        : activeResult.status === 'SUCCESS'
                        ? 'Zero Hits (No Records)'
                        : 'Query Failed'}
                    </span>
                  </div>
                  <div className="text-[11px] font-mono text-slate-500">
                    Index: <strong>{activeResult.index}</strong> • Duration: <strong>{activeResult.durationMs}ms</strong> • Executed: <strong>{activeResult.executedAt}</strong>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() =>
                      exportToJsonFile(
                        `evidence_${activeResult.queryId}.json`,
                        activeResult
                      )
                    }
                    className="p-1.5 bg-white hover:bg-slate-100 border border-slate-200 rounded-lg text-slate-700 text-xs font-semibold flex items-center gap-1 cursor-pointer shadow-xs"
                    title="Export this query result"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>Export</span>
                  </button>
                </div>
              </div>

              {/* Error Box if query failed */}
              {activeResult.errorMessage && (
                <div className="p-4 bg-rose-50 border border-rose-200 rounded-2xl text-xs text-rose-800 space-y-1 font-mono">
                  <div className="font-bold flex items-center gap-1.5 text-rose-700">
                    <AlertTriangle className="w-4 h-4" />
                    <span>Elasticsearch Query Error</span>
                  </div>
                  <div>{activeResult.errorMessage}</div>
                </div>
              )}

              {/* Document Hits Breakdown */}
              {activeResult.hits && activeResult.hits.length > 0 ? (
                <div className="space-y-3">
                  <div className="flex items-center justify-between text-xs font-bold text-slate-700">
                    <span>Captured Documents ({activeResult.hits.length} shown)</span>
                    <span className="text-[11px] font-mono text-slate-400">Total in Cluster: {activeResult.totalHits}</span>
                  </div>

                  <div className="space-y-3">
                    {activeResult.hits.map((hit, hIdx) => {
                      const docJsonStr = JSON.stringify(hit._source || hit, null, 2);
                      const isCopied = copiedDocId === hit._id;

                      return (
                        <div
                          key={hit._id || hIdx}
                          className="border border-slate-200 rounded-2xl overflow-hidden bg-white shadow-xs"
                        >
                          <div className="px-4 py-2.5 bg-slate-50 border-b border-slate-200 flex items-center justify-between text-xs">
                            <div className="flex items-center gap-2 font-mono">
                              <span className="text-slate-400 text-[10px]">_id:</span>
                              <strong className="text-slate-900">{hit._id}</strong>
                              <span className="text-slate-300">|</span>
                              <span className="text-slate-500 text-[11px]">{hit._index}</span>
                            </div>

                            <button
                              onClick={() => copyToClipboard(docJsonStr, hit._id)}
                              className="px-2.5 py-1 text-[11px] font-bold bg-white hover:bg-slate-100 border border-slate-200 text-slate-700 rounded-lg flex items-center gap-1 cursor-pointer transition-colors shadow-2xs"
                            >
                              {isCopied ? (
                                <>
                                  <Check className="w-3 h-3 text-emerald-600" />
                                  <span className="text-emerald-700">Copied!</span>
                                </>
                              ) : (
                                <>
                                  <Copy className="w-3 h-3 text-slate-400" />
                                  <span>Copy JSON</span>
                                </>
                              )}
                            </button>
                          </div>

                          {/* Formatted Property Table */}
                          <div className="p-3 text-xs">
                            <table className="w-full text-left font-mono text-[11px]">
                              <tbody>
                                {Object.entries(hit._source || {}).map(([key, val]) => (
                                  <tr key={key} className="border-b border-slate-100 last:border-none">
                                    <td className="py-1.5 pr-3 font-bold text-indigo-700 w-1/3 align-top">
                                      {key}
                                    </td>
                                    <td className="py-1.5 text-slate-800 break-all">
                                      {typeof val === 'object' ? JSON.stringify(val) : String(val)}
                                    </td>
                                  </tr>
                                ))}
                              </tbody>
                            </table>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              ) : activeResult.status === 'SUCCESS' ? (
                <div className="p-8 text-center border border-dashed border-slate-200 rounded-2xl space-y-2">
                  <CheckCircle2 className="w-8 h-8 text-amber-500 mx-auto" />
                  <p className="text-xs font-bold text-slate-700">No Document Hits Returned</p>
                  <p className="text-[11px] text-slate-400 max-w-sm mx-auto">
                    The query ran successfully against Elasticsearch, but returned zero matching documents for index "{activeResult.index}".
                  </p>
                </div>
              ) : null}

              {/* Raw JSON Payload Viewer (Collapsible) */}
              {activeResult.rawResponse && (
                <details className="p-3 bg-slate-50 border border-slate-200 rounded-2xl text-xs">
                  <summary className="font-bold text-slate-700 cursor-pointer select-none">
                    View Raw Elasticsearch Response (JSON)
                  </summary>
                  <pre className="mt-3 p-3 bg-slate-900 text-emerald-400 font-mono text-[11px] rounded-xl overflow-x-auto max-h-60">
                    {JSON.stringify(activeResult.rawResponse, null, 2)}
                  </pre>
                </details>
              )}
            </div>
          ) : (
            <div className="p-12 text-center border border-dashed border-slate-200 rounded-3xl space-y-3">
              <Database className="w-10 h-10 text-slate-300 mx-auto" />
              <p className="text-sm font-bold text-slate-700">No Evidence Gathered Yet</p>
              <p className="text-xs text-slate-400 max-w-md mx-auto">
                Select a query from the left panel and click <strong>"Run"</strong> or click <strong>"Run All Queries"</strong> above to retrieve and display evidence from Elasticsearch.
              </p>
            </div>
          )}
        </div>
      </div>

      {/* Connection Settings Modal */}
      <EsConnectionModal
        isOpen={isConnModalOpen}
        onClose={() => setIsConnModalOpen(false)}
        config={config}
        onSaveConfig={handleSaveConfig}
        onConnectionTested={(info, isConn) => {
          setClusterInfo(info);
          setConnectionStatus(isConn ? 'CONNECTED' : 'ERROR');
        }}
      />

      {/* Query Editor Modal */}
      <EsQueryEditorModal
        isOpen={isQueryModalOpen}
        onClose={() => {
          setIsQueryModalOpen(false);
          setEditingQuery(null);
        }}
        editingQuery={editingQuery}
        onSaveQuery={handleSaveQuery}
        defaultIndex={config.defaultIndex || 'customers-*'}
      />

      {/* Saved Packages Drawer */}
      <EsSavedPackagesDrawer
        isOpen={isSavedDrawerOpen}
        onClose={() => setIsSavedDrawerOpen(false)}
        packages={savedPackages}
        onLoadPackage={(pkg) => {
          setResults(pkg.results);
          if (pkg.results.length > 0) setActiveResultQueryId(pkg.results[0].queryId);
        }}
        onDeletePackage={(id) => {
          const updated = deleteEvidencePackage(id);
          setSavedPackages(updated);
        }}
      />
    </div>
  );
};
