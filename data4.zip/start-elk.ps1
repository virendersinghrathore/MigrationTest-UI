# start-elk.ps1 - PowerShell script to start Elasticsearch & Kibana in Docker and seed sample data

Write-Host "==========================================================" -ForegroundColor Cyan
Write-Host "  Starting Local Elasticsearch & Kibana Docker Stack" -ForegroundColor Cyan
Write-Host "==========================================================" -ForegroundColor Cyan

# 1. Verify Docker is running
try {
    $dockerVersion = docker --version
    Write-Host "[OK] $dockerVersion detected." -ForegroundColor Green
} catch {
    Write-Host "[ERROR] Docker is not installed or Docker Desktop is not running." -ForegroundColor Red
    Write-Host "Please start Docker Desktop and run this script again." -ForegroundColor Yellow
    exit 1
}

# 2. Start containers via docker compose
Write-Host "`n[1/3] Spinning up Elasticsearch (9200) & Kibana (5601)..." -ForegroundColor Yellow
docker compose -f docker-compose.elk.yml up -d

Write-Host "`n[2/3] Waiting for Elasticsearch and Kibana to be ready..." -ForegroundColor Yellow
$maxAttempts = 30
$attempt = 0
$esReady = $false

while (-not $esReady -and $attempt -lt $maxAttempts) {
    Start-Sleep -Seconds 3
    $attempt++
    try {
        $response = Invoke-RestMethod -Uri "http://localhost:9200/" -Headers @{ Authorization = "Basic " + [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes("elastic:changeme")) } -TimeoutSec 3 -ErrorAction SilentlyContinue
        if ($response.version.number) {
            $esReady = $true
            Write-Host "[OK] Elasticsearch $($response.version.number) is ready!" -ForegroundColor Green
            # Ensure kibana_system internal user password is set for Kibana
            try {
                $kibanaPassJson = '{"password":"changeme"}'
                Invoke-RestMethod -Uri "http://localhost:9200/_security/user/kibana_system/_password" -Method Post -Headers @{ Authorization = "Basic " + [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes("elastic:changeme")); "Content-Type" = "application/json" } -Body $kibanaPassJson -TimeoutSec 5 -ErrorAction SilentlyContinue | Out-Null
            } catch {}
        }
    } catch {
        Write-Host "  ... waiting for Elasticsearch to initialize ($attempt/$maxAttempts)" -ForegroundColor Gray
    }
}

if (-not $esReady) {
    Write-Host "[WARN] Elasticsearch took longer than expected to start. Check 'docker logs es-local-test'." -ForegroundColor Yellow
}

# 3. Seed sample migration documents and audit logs
Write-Host "`n[3/3] Seeding sample migration customer and audit logs..." -ForegroundColor Yellow

$basicAuth = "Basic " + [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes("elastic:changeme"))
$headers = @{
    "Authorization" = $basicAuth
    "Content-Type" = "application/json"
}

# Seed customer document
$customerDoc = @{
    id = "cust_99281"
    customer_name = "Acme Global Logistics Inc."
    status = "ACTIVE"
    account_balance = 14850.50
    currency = "USD"
    migrated_from = "couchdb_customers_bucket"
    migrated_at = (Get-Date).ToString("yyyy-MM-ddTHH:mm:ssZ")
    sync_version = "v2.4.1"
    data_integrity_verified = $true
    tags = @("migrated", "verified", "tier_1")
} | ConvertTo-Json

try {
    Invoke-RestMethod -Uri "http://localhost:9200/customers-v2/_doc/cust_99281" -Method Put -Headers $headers -Body $customerDoc -ErrorAction SilentlyContinue | Out-Null
    Write-Host "[OK] Seeded document 'cust_99281' into index 'customers-v2'" -ForegroundColor Green
} catch {
    Write-Host "[WARN] Could not seed customer doc: $_" -ForegroundColor Yellow
}

# Seed audit event
$auditDoc = @{
    event_type = "MIGRATION_SYNC"
    document_id = "cust_99281"
    source_system = "COUCHDB"
    target_system = "MYSQL"
    status = "SUCCESS"
    records_migrated = 1
    timestamp = (Get-Date).ToString("yyyy-MM-ddTHH:mm:ssZ")
    worker_id = "cdc-worker-node-01"
    duration_ms = 38
} | ConvertTo-Json

try {
    Invoke-RestMethod -Uri "http://localhost:9200/migration-audit-2026/_doc/audit_001" -Method Put -Headers $headers -Body $auditDoc -ErrorAction SilentlyContinue | Out-Null
    Write-Host "[OK] Seeded audit record 'audit_001' into index 'migration-audit-2026'" -ForegroundColor Green
} catch {
    Write-Host "[WARN] Could not seed audit log: $_" -ForegroundColor Yellow
}

Write-Host "`n==========================================================" -ForegroundColor Cyan
Write-Host "  SETUP COMPLETE!" -ForegroundColor Green
Write-Host "==========================================================" -ForegroundColor Cyan
Write-Host "Kibana URL:     http://localhost:5601" -ForegroundColor White
Write-Host "Elasticsearch:  http://localhost:9200" -ForegroundColor White
Write-Host "Username:       elastic" -ForegroundColor White
Write-Host "Password:       changeme" -ForegroundColor White
Write-Host ""
Write-Host "How to Test in your Migration Tester App:" -ForegroundColor Yellow
Write-Host "1. Open http://localhost:5601 in your browser and log in with elastic / changeme" -ForegroundColor Gray
Write-Host "2. In the tester app (http://localhost:3000), go to ES Evidence -> Configure Connection" -ForegroundColor Gray
Write-Host "3. Set URL to: http://localhost:5601 (or http://localhost:9200)" -ForegroundColor Gray
Write-Host "4. Choose 'Cookie-Based Login' -> Enter username 'elastic' and password 'changeme'" -ForegroundColor Gray
Write-Host "5. Click 'Auto-Fetch Session Cookie' -> Save Settings" -ForegroundColor Gray
Write-Host "6. Click 'Run All Queries' to verify the seeded logs!" -ForegroundColor Gray
Write-Host "==========================================================" -ForegroundColor Cyan
