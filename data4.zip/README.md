# Couch To MySQL Migration Tester

## Run Locally

**Prerequisites:**  Node.js


1. Install dependencies:
   `npm install`
2. Run the app:
   `npm run dev`

## Documentation Guides

* [Elasticsearch Evidence Gathering Guide](file:///d:/Nes-POC/couchtomysql-migration-tester/ELASTICSEARCH_EVIDENCE_GUIDE.md) - Complete step-by-step instructions on connecting to Elasticsearch, configuring credentials, running evidence queries, and passing test cases.
* **Quick Direct Tester**: Use the toggle button on the top header to switch between the full Studio Workflow and the streamlined 2-Payload Direct Comparison Tester.
