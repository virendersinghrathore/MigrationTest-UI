@echo off
echo Stopping and removing local ELK Docker containers...
docker compose -f docker-compose.elk.yml down
echo Done.
pause
