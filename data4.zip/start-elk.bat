@echo off
echo ==========================================================
echo   Starting Local Elasticsearch ^& Kibana in Docker
echo ==========================================================

docker --version >nul 2>&1
if %errorlevel% neq 0 (
    echo [ERROR] Docker is not installed or Docker Desktop is not running.
    echo Please start Docker Desktop and run this script again.
    pause
    exit /b 1
)

echo.
echo [1/2] Starting containers via docker compose...
docker compose -f docker-compose.elk.yml up -d

echo.
echo [2/2] Running setup and data seeding via PowerShell...
powershell -ExecutionPolicy Bypass -File "%~dp0start-elk.ps1"

pause
