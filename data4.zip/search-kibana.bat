@echo off
setlocal

rem search-kibana.bat - Batch wrapper for search-kibana.ps1
rem Usage: search-kibana.bat [SearchTerm] [Index]
rem Example: search-kibana.bat cust_99281
rem Example: search-kibana.bat SUCCESS migration-audit-2026

set SEARCH_TERM=%~1
if "%SEARCH_TERM%"=="" set SEARCH_TERM=cust_99281

set SEARCH_INDEX=%~2
if "%SEARCH_INDEX%"=="" set SEARCH_INDEX=*

powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0search-kibana.ps1" -SearchTerm "%SEARCH_TERM%" -Index "%SEARCH_INDEX%"

endlocal
