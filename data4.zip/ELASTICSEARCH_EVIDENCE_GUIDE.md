# Elasticsearch Evidence Gathering & Test Pass Guide

This guide walks you step-by-step through retrieving the required data from **Elasticsearch**, configuring the tester app, running evidence queries, and capturing verifiable audit proof to pass your **CouchDB-to-MySQL Migration** test cases.

---

## Table of Contents
1. [Overview & Verification Objectives](#1-overview--verification-objectives)
2. [Step 1: Retrieve Elasticsearch Connection Info & Credentials](#step-1-retrieve-elasticsearch-connection-info--credentials)
3. [Step 2: Configure & Test Connection in the App](#step-2-configure--test-connection-in-the-app)
4. [Step 3: Step-by-Step Query Setup to Pass Test Cases](#step-3-step-by-step-query-setup-to-pass-test-cases)
   - [Query 1: Verify Migrated Document by ID](#query-1-verify-migrated-document-by-id)
   - [Query 2: Check Audit Trail & Sync Events](#query-2-check-audit-trail--sync-events)
   - [Query 3: Verify Zero Error Logs (Negative Proof)](#query-3-verify-zero-error-logs-negative-proof)
5. [Step 4: Execute Queries & Inspect Evidence](#step-4-execute-queries--inspect-evidence)
6. [Step 5: Save & Export Evidence Packages](#step-5-save--export-evidence-packages)
7. [Troubleshooting Common Elasticsearch Issues](#troubleshooting-common-elasticsearch-issues)

---

## 1. Overview & Verification Objectives

When migrating data from CouchDB to MySQL (or when Elasticsearch acts as the search index / CDC sink):
* **CouchDB**: Baseline source JSON document.
* **MySQL / Target API**: Transformed relational record or API response.
* **Elasticsearch**: Holds indexed search documents, sync events, and audit logs.

### Requirements to Pass a Test Case:
1. **Document Match**: The migrated document exists in Elasticsearch with identical values and fields (`hits.total >= 1`).
2. **Audit Event Confirmation**: An event record exists proving the pipeline processed the specific document ID with status `SUCCESS`.
3. **Clean Log Verification**: Zero error logs recorded for that document ID or transaction.

---

## Step 1: Retrieve Elasticsearch Connection Info & Credentials

Before opening the app, gather your Elasticsearch cluster details.

### A. Cluster URL
* **Local Development**: `http://localhost:9200`
* **Docker / Compose**: `http://localhost:9200` or `http://elasticsearch:9200`
* **Cloud / Staging / Production**: `https://your-es-cluster.corp.domain:9200`

### B. Authentication Credentials (Pick One)

#### Option 1: Basic Authentication (Username + Password)
* Default admin: `elastic`
* Password: set during cluster installation or in `.env`.
* Test via cURL in your terminal:
  ```bash
  curl -u "elastic:your_password" -X GET "http://localhost:9200/"
  ```

#### Option 2: Elasticsearch API Key (Recommended for Staging/Prod)
If your organization uses API Keys:
1. Generate an API Key via Kibana (**Stack Management** > **Security** > **API Keys** > **Create API Key**).
2. Or generate via Elasticsearch Dev Tools:
   ```json
   POST /_security/api_key
   {
     "name": "migration-tester-key",
     "role_descriptors": {
       "viewer": {
         "cluster": ["monitor"],
         "index": [{ "names": ["*"], "privileges": ["read"] }]
       }
     }
   }
   ```
3. Copy the base64 encoded API Key or `id:api_key`.

#### Option 3: Anonymous / No Auth (Dev environments)
* If your local instance has security disabled (`xpack.security.enabled: false`), choose **No Authentication**.

---

## Step 2: Configure & Test Connection in the App

1. In the application sidebar, click **"ES Evidence"**.
2. Click **"Configure Connection"** in the top action bar.
3. Fill in the connection form:
   * **Elasticsearch Cluster URL**: e.g., `http://localhost:9200`
   * **Authentication Type**: Select `Basic Auth`, `API Key`, `Bearer Token`, or `No Authentication`.
   * **Username / Password** or **API Key**: Input the credentials from Step 1.
   * **Default Index / Pattern**: e.g. `customers-*` or `migration-*`.
4. Click **"Test Connection"**:
   * If successful: A green banner displays the **Cluster Name**, **Version** (e.g. `8.11.0`), and **Health Status** (`green`/`yellow`).
   * If failed: An error message details the exact issue (e.g., 401 Unauthorized or host unreachable).
5. Click **"Save Settings Locally"**:
   * All connection settings are stored in local storage so you do not need to re-enter them on future visits.

> [!TIP]
> **No live Elasticsearch running right now?**
> Click the **"Simulate ES (Demo)"** button on the top strip. The tester will generate realistic cluster responses, audit trail hits, and logs for demoing and offline verification!

---

## Step 3: Step-by-Step Query Setup to Pass Test Cases

Under **Configured Evidence Queries** (left column), configure the following 3 standard queries. You can use the built-in templates by clicking **"Add Query"** or editing existing items.

---

### Query 1: Verify Migrated Document by ID

* **Purpose**: Confirm the CouchDB document was indexed in Elasticsearch with matching fields.
* **Query Name**: `1. Verify Customer Sync in ES (By ID)`
* **Target Index**: `customers-*` (or your application index)
* **Method**: `POST`
* **Endpoint Path**: `/_search`
* **Linked Test Doc ID**: `cust_99281`
* **JSON Query Body**:
  ```json
  {
    "query": {
      "term": {
        "_id": "cust_99281"
      }
    },
    "size": 5
  }
  ```

#### What to inspect in the results:
* `totalHits`: Must be `1` (or `>= 1`).
* `_source`: Check that `first_name`, `email`, `phone`, and `credit_limit` match the values in your CouchDB document.

---

### Query 2: Check Audit Trail & Sync Events

* **Purpose**: Prove that the migration pipeline emitted a completion event for this record.
* **Query Name**: `2. Check Migration Audit Trail Events`
* **Target Index**: `migration-audit-*`
* **Method**: `POST`
* **Endpoint Path**: `/_search`
* **JSON Query Body**:
  ```json
  {
    "query": {
      "bool": {
        "must": [
          { "term": { "doc_id.keyword": "cust_99281" } },
          { "term": { "status.keyword": "SUCCESS" } }
        ]
      }
    },
    "sort": [
      { "timestamp": { "order": "desc" } }
    ],
    "size": 10
  }
  ```

#### What to inspect in the results:
* `status`: `SUCCESS`.
* `action`: `MIGRATION_SYNC`.
* `migrated_fields`: Verify all expected fields were migrated without truncation.

---

### Query 3: Verify Zero Error Logs (Negative Proof)

* **Purpose**: Confirm no unhandled exceptions, transformation crashes, or SQL constraint violations were logged for this test ID.
* **Query Name**: `3. Query Migration Error & Failure Logs`
* **Target Index**: `migration-logs-*`
* **Method**: `POST`
* **Endpoint Path**: `/_search`
* **JSON Query Body**:
  ```json
  {
    "query": {
      "bool": {
        "must": [
          { "match": { "doc_id": "cust_99281" } },
          { "term": { "level.keyword": "ERROR" } }
        ]
      }
    },
    "size": 5
  }
  ```

#### What to inspect in the results:
* `totalHits`: **0** (Zero error hits confirms no error occurred during processing).

---

## Step 4: Execute Queries & Inspect Evidence

1. **Run All Queries**:
   * Click **"Run All Queries"** in the top action bar.
   * The app sends the queries sequentially via the backend proxy to Elasticsearch.
2. **Review Evidence Results**:
   * In the right panel, tabs appear for each executed query:
     * `Query 1 (1 Hit)`
     * `Query 2 (1 Hit)`
     * `Query 3 (0 Hits)`
   * Click any query tab to inspect:
     * **Duration**: Response time in milliseconds (e.g. `took: 6ms`).
     * **Total Hits**: Number of matching documents.
     * **Status**: `Evidence Verified` (green) or `Zero Hits` (amber).
3. **Inspect Document Fields**:
   * Review the **Property Table** showing extracted `_source` key-value pairs.
   * Click **"Copy JSON"** to copy individual document payloads.
   * Expand **"View Raw Elasticsearch Response (JSON)"** to view the raw Elasticsearch cluster response.

---

## Step 5: Save & Export Evidence Packages

Once your queries run and verify the test case:

1. **Save Evidence Package**:
   * Click **"Save Evidence Package"** in the top action bar.
   * Enter a descriptive name (e.g., `Customer Sync Test - cust_99281 Verified`).
   * The complete snapshot (cluster URL, metadata, queries run, document hits, timestamps) is saved.
2. **Export for QA / Audit Sign-Off**:
   * Click **"Export Evidence Bundle"** (or export from the **Saved Evidence** drawer).
   * A JSON file (e.g., `es_evidence_bundle_1730300000.json`) is downloaded containing the entire verifiable evidence trail.

---

## Troubleshooting Common Elasticsearch Issues

| Issue / Error | Cause | Solution |
| :--- | :--- | :--- |
| `Could not connect to Elasticsearch ... ECONNREFUSED` | Elasticsearch is not running or host/port is wrong. | Check that Elasticsearch is running: `curl http://localhost:9200/`. Verify port `9200`. Or enable **"Simulate ES (Demo)"** mode. |
| `HTTP 401 Unauthorized` | Missing or incorrect username, password, or API key. | Check credentials in **Configure Connection**. For API keys, verify the key has not expired. |
| `index_not_found_exception` | The index pattern does not exist in Elasticsearch. | Check existing indices using `GET /_cat/indices?v` in Kibana or cURL. Update **Target Index Pattern** to match your cluster's indices. |
| `Zero Document Hits (hits.total: 0)` | Field name or value mismatch (e.g. `doc_id` vs `_id`). | Check index mapping using `GET /<index>/_mapping`. In Elasticsearch, exact string matches on `text` fields require `.keyword` (e.g. `status.keyword`). |
| CORS or Network Error in browser console | Direct browser request blocked. | The app automatically uses the `/api/elasticsearch/*` backend proxy in `server.ts`, which bypasses browser CORS. Ensure `npm run dev` is running. |

---

## Summary Checklist to Pass a Test Case

- [ ] Cluster connection tested and showing green status (or Simulated Mode enabled).
- [ ] Document query returns matching `_source` data (`hits.total >= 1`).
- [ ] Audit trail query returns `status: SUCCESS` event.
- [ ] Error logs query returns `hits.total == 0`.
- [ ] Evidence package saved and exported for test case attachment.
