import { DbConnectionConfig, DbConnectResult, DbQueryResult } from '../types/dbTester';

const CONFIG_KEY = 'couch_db_tester_config';

export function loadDbConfig(): DbConnectionConfig {
  try {
    const raw = localStorage.getItem(CONFIG_KEY);
    return raw ? JSON.parse(raw) : { host: '', port: 3306, database: '' };
  } catch {
    return { host: '', port: 3306, database: '' };
  }
}

export function saveDbConfig(config: DbConnectionConfig): void {
  localStorage.setItem(CONFIG_KEY, JSON.stringify(config));
}

export async function testDbConnection(config: DbConnectionConfig): Promise<DbConnectResult> {
  const res = await fetch('/api/db/connect', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(config),
    signal: AbortSignal.timeout(20000),
  });
  return res.json();
}

export async function executeDbQuery(config: DbConnectionConfig, sql: string): Promise<DbQueryResult> {
  const res = await fetch('/api/db/query', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ ...config, sql }),
    signal: AbortSignal.timeout(35000),
  });
  return res.json();
}
