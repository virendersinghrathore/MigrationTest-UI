export type EsAuthType = 'none' | 'basic' | 'apiKey' | 'bearer' | 'cookie';

export interface EsConnectionConfig {
  url: string;
  authType: EsAuthType;
  username?: string;
  password?: string;
  apiKey?: string;
  bearerToken?: string;
  cookie?: string;
  cookieLoginUrl?: string;
  cookieLoginUsername?: string;
  cookieLoginPassword?: string;
  defaultIndex?: string;
  customHeaders?: string;
}

export interface EsClusterInfo {
  name?: string;
  cluster_name?: string;
  cluster_uuid?: string;
  version?: {
    number: string;
    build_flavor?: string;
    lucene_version?: string;
  };
  tagline?: string;
  health?: {
    status?: 'green' | 'yellow' | 'red';
    cluster_name?: string;
    number_of_nodes?: number;
    active_primary_shards?: number;
    unassigned_shards?: number;
  };
}

export interface EsQueryItem {
  id: string;
  title: string;
  index: string;
  method: 'GET' | 'POST';
  endpointPath?: string;
  queryBody: string;
  enabled: boolean;
  notes?: string;
  linkedTestCase?: string;
}

export interface EsQueryHit {
  _index: string;
  _id: string;
  _score?: number | null;
  _source: Record<string, any>;
}

export interface EsQueryResult {
  queryId: string;
  queryTitle: string;
  index: string;
  executedAt: string;
  durationMs: number;
  status: 'SUCCESS' | 'ERROR';
  statusCode?: number;
  totalHits: number;
  hits: EsQueryHit[];
  rawResponse?: any;
  errorMessage?: string;
}

export interface EsEvidencePackage {
  id: string;
  title: string;
  testCaseName?: string;
  createdAt: string;
  clusterUrl: string;
  clusterName?: string;
  results: EsQueryResult[];
}
