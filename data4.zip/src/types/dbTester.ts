export interface DbConnectionConfig {
  host: string;
  port: number;
  database: string;
  tenantId?: string;   // optional, narrows Azure AD tenant
}

export type DbConnectionStatus = 'UNTESTED' | 'CONNECTED' | 'ERROR';

export interface DbConnectResult {
  success: boolean;
  serverVersion?: string;
  error?: string;
}

export interface DbQueryResult {
  success: boolean;
  columns: string[];
  rows: Record<string, unknown>[];
  affectedRows?: number;
  insertId?: number;
  error?: string;
  errorCode?: string | number;
  durationMs: number;
}
