import React from 'react';
import {
  Database, UserPlus, LayoutDashboard, FileCode, Sliders, Terminal,
  FileSpreadsheet, GitCompare, ChevronRight, Upload, Download, Clock,
  Edit2, Sparkles, Search, DatabaseZap
} from 'lucide-react';
import { MigrationProfile, TabType, AppMode } from '../../types';

interface SidebarProps {
  activeTab: TabType;
  setActiveTab: (tab: TabType) => void;
  profiles: MigrationProfile[];
  activeProfileId: string;
  setActiveProfileId: (id: string) => void;
  onOpenProfileModal: () => void;
  onOpenEditProfileModal: (p: MigrationProfile) => void;
  onOpenImportModal: () => void;
  payloadCount: number;
  successRate: number;
  onExportConfig: () => void;
  userName?: string;
  storageMode?: 'localstorage' | 'file';
  appMode?: AppMode;
}

const STUDIO_NAV_ITEMS: { id: TabType; label: string; icon: React.ElementType; step?: string }[] = [
  { id: 'dashboard',   label: 'Dashboard',       icon: LayoutDashboard },
  { id: 'step1_store', label: 'Payloads',         icon: FileCode,        step: '1' },
  { id: 'step2_rules', label: 'Field Rules',      icon: Sliders,         step: '2' },
  { id: 'transforms',  label: 'Rules Library',    icon: Terminal },
  { id: 'step3_specs', label: 'Endpoint Specs',   icon: FileSpreadsheet, step: '3' },
  { id: 'step4_test',  label: 'Test & Compare',   icon: GitCompare,      step: '4' },
  { id: 'history',     label: 'Run History',      icon: Clock },
  { id: 'elasticsearch', label: 'ES Evidence',    icon: Database },
  { id: 'curl_tester', label: 'cURL Tester',      icon: Terminal },
  { id: 'db_tester',   label: 'DB Tester',        icon: DatabaseZap },
  { id: 'settings',   label: 'Settings',          icon: Sliders },
];

const QUICK_NAV_ITEMS: { id: TabType; label: string; icon: React.ElementType; badge?: string; color?: string }[] = [
  {
    id: 'step1_store',   // reuse step1_store tab but render QuickTesterView via appMode
    label: 'Payload Tester',
    icon: Sparkles,
    badge: 'QUICK',
    color: 'indigo',
  },
  {
    id: 'elasticsearch',
    label: 'ES Evidence',
    icon: Database,
    badge: 'AUDIT',
    color: 'amber',
  },
  {
    id: 'curl_tester',
    label: 'cURL Direct',
    icon: Terminal,
    badge: 'CLI',
    color: 'emerald',
  },
  {
    id: 'db_tester',
    label: 'DB Tester',
    icon: DatabaseZap,
    badge: 'SQL',
    color: 'cyan',
  },
];

export const Sidebar: React.FC<SidebarProps> = ({
  activeTab, setActiveTab, profiles, activeProfileId, setActiveProfileId,
  onOpenProfileModal, onOpenEditProfileModal, onOpenImportModal,
  payloadCount, successRate, onExportConfig,
  userName = 'Guest User', storageMode = 'localstorage',
  appMode = 'studio',
}) => {
  const activeProfile = profiles.find(p => p.id === activeProfileId);
  const isQuick = appMode === 'quick';

  return (
    <aside className="w-64 bg-white border-r border-slate-200 flex flex-col justify-between shrink-0 sticky top-0 h-screen shadow-xs">
      <div className="flex-1 overflow-y-auto">
        {/* Logo */}
        <div className="p-5 border-b border-slate-100 flex items-center space-x-3">
          <div className="h-9 w-9 rounded-xl bg-indigo-600 flex items-center justify-center shadow-md shadow-indigo-600/20 text-white">
            <Database className="h-5 w-5" />
          </div>
          <div>
            <h1 className="text-sm font-extrabold text-slate-900 tracking-tight">CouchToMySQL</h1>
            <p className="text-[11px] text-slate-500 font-medium">Migration & Testing</p>
          </div>
        </div>

        {/* Profile selector — only in studio mode */}
        {!isQuick && (
          <div className="p-4 border-b border-slate-100 bg-slate-50/50">
            <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1.5">
              Environment
            </label>
            <div className="flex flex-col gap-2">
              <div className="flex items-center space-x-2">
                <select
                  value={activeProfileId}
                  onChange={(e) => setActiveProfileId(e.target.value)}
                  className="flex-1 bg-white border border-slate-300 rounded-xl px-3 py-1.5 text-xs font-semibold text-slate-800 focus:outline-none focus:border-indigo-600 cursor-pointer shadow-xs"
                >
                  {profiles.map((prof) => (
                    <option key={prof.id} value={prof.id}>{prof.name}</option>
                  ))}
                </select>
                <button
                  onClick={onOpenProfileModal}
                  title="New Profile"
                  className="p-1.5 rounded-xl bg-white hover:bg-slate-100 text-indigo-600 border border-slate-300 transition-all cursor-pointer shadow-xs shrink-0"
                >
                  <UserPlus className="h-4 w-4" />
                </button>
              </div>
              {activeProfile && (
                <button
                  onClick={() => onOpenEditProfileModal(activeProfile)}
                  className="flex items-center justify-center gap-1.5 py-1 text-[10px] font-bold text-slate-500 hover:text-indigo-600 bg-white border border-slate-200 rounded-lg shadow-2xs cursor-pointer transition-all"
                >
                  <Edit2 className="w-3 h-3" /> Edit Profile Name
                </button>
              )}
            </div>
          </div>
        )}

        {/* Navigation */}
        <div className="p-3 space-y-1">
          {isQuick ? (
            <>
              {/* Quick mode — minimal two-item nav */}
              <div className="px-3 py-2 mb-1 text-[10px] font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
                <Sparkles className="w-3 h-3 text-indigo-500" />
                Quick Mode
              </div>

              {QUICK_NAV_ITEMS.map((item) => {
                const Icon = item.icon;
                const isActive = activeTab === item.id;
                const isIndigo = item.color === 'indigo';
                const isAmber = item.color === 'amber';
                const isEmerald = item.color === 'emerald';
                const isCyan = item.color === 'cyan';

                return (
                  <button
                    key={item.id}
                    onClick={() => setActiveTab(item.id)}
                    className={`w-full flex items-center justify-between px-3.5 py-3 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
                      isActive
                        ? isEmerald
                          ? 'bg-emerald-50 text-emerald-800 shadow-xs border border-emerald-200 font-bold'
                          : isAmber
                          ? 'bg-amber-50 text-amber-700 shadow-xs border border-amber-200 font-bold'
                          : isCyan
                          ? 'bg-cyan-50 text-cyan-800 shadow-xs border border-cyan-200 font-bold'
                          : 'bg-indigo-50 text-indigo-700 shadow-xs border border-indigo-100 font-bold'
                        : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
                    }`}
                  >
                    <div className="flex items-center space-x-2.5">
                      <Icon className={`h-4 w-4 ${
                        isActive
                          ? isEmerald ? 'text-emerald-600' : isAmber ? 'text-amber-600' : isCyan ? 'text-cyan-600' : 'text-indigo-600'
                          : 'text-slate-500'
                      }`} />
                      <span>{item.label}</span>
                    </div>
                    <div className="flex items-center gap-1.5">
                      {item.badge && (
                        <span className={`text-[9px] font-black uppercase px-1.5 py-0.5 rounded-md ${
                          isActive
                            ? isEmerald
                              ? 'bg-emerald-200 text-emerald-900'
                              : isAmber
                              ? 'bg-amber-200 text-amber-800'
                              : isCyan
                              ? 'bg-cyan-200 text-cyan-900'
                              : 'bg-indigo-200 text-indigo-800'
                            : isEmerald
                            ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                            : isAmber
                            ? 'bg-amber-50 text-amber-600 border border-amber-200'
                            : isCyan
                            ? 'bg-cyan-50 text-cyan-700 border border-cyan-200'
                            : 'bg-indigo-50 text-indigo-600 border border-indigo-100'
                        }`}>
                          {item.badge}
                        </span>
                      )}
                      {isActive && (
                        <ChevronRight className={`h-3.5 w-3.5 ${
                          isEmerald ? 'text-emerald-600' : isAmber ? 'text-amber-600' : isCyan ? 'text-cyan-600' : 'text-indigo-600'
                        }`} />
                      )}
                    </div>
                  </button>
                );
              })}

              {/* Subtle divider + hint */}
              <div className="pt-3 pb-1 px-3">
                <div className="h-px bg-slate-100"></div>
              </div>
              <div className="px-3 py-2 text-[10px] text-slate-400 leading-relaxed">
                Switch to <span className="font-bold text-slate-600">Studio Workflow</span> via the toggle above for the full multi-step testing pipeline.
              </div>
            </>
          ) : (
            <>
              {/* Studio mode — full nav */}
              <div className="px-3 py-1 text-[10px] font-bold uppercase tracking-wider text-slate-400">Steps</div>
              {STUDIO_NAV_ITEMS.map((item) => {
                const Icon = item.icon;
                const isActive = activeTab === item.id;
                return (
                  <button
                    key={item.id}
                    onClick={() => setActiveTab(item.id)}
                    className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
                      isActive
                        ? 'bg-indigo-50 text-indigo-700 shadow-xs border border-indigo-100 font-bold'
                        : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
                    }`}
                  >
                    <div className="flex items-center space-x-2.5">
                      <Icon className={`h-4 w-4 ${isActive ? 'text-indigo-600' : 'text-slate-500'}`} />
                      <span>
                        {item.step ? <><span className="text-slate-400 font-bold mr-0.5">{item.step}.</span> {item.label}</> : item.label}
                      </span>
                    </div>
                    {isActive && <ChevronRight className="h-3.5 w-3.5 text-indigo-600" />}
                  </button>
                );
              })}
            </>
          )}
        </div>
      </div>

      {/* Footer */}
      <div className="p-3 border-t border-slate-100 bg-slate-50/50 space-y-2 shrink-0">
        {!isQuick && (
          <>
            <div className="flex items-center justify-between text-xs text-slate-500 px-1">
              <span>Endpoints</span>
              <span className="font-bold text-slate-800">{payloadCount}</span>
            </div>
            <div className="flex items-center justify-between text-xs text-slate-500 px-1">
              <span>Passing</span>
              <span className="font-bold text-emerald-600">{successRate}%</span>
            </div>
            <div className="pt-1 flex items-center space-x-2">
              <button
                onClick={onOpenImportModal}
                className="flex-1 bg-white hover:bg-slate-100 text-slate-700 border border-slate-300 text-xs font-semibold py-1.5 px-3 rounded-xl flex items-center justify-center gap-1.5 cursor-pointer shadow-xs"
              >
                <Upload className="h-3.5 w-3.5 text-slate-500" />
                <span>Import</span>
              </button>
              <button
                onClick={onExportConfig}
                className="flex-1 bg-white hover:bg-slate-100 text-slate-700 border border-slate-300 text-xs font-semibold py-1.5 px-3 rounded-xl flex items-center justify-center gap-1.5 cursor-pointer shadow-xs"
              >
                <Download className="h-3.5 w-3.5 text-slate-500" />
                <span>Export</span>
              </button>
            </div>
          </>
        )}

        {/* Quick cURL Direct Button */}
        <button
          onClick={() => setActiveTab('curl_tester')}
          className={`w-full py-1.5 px-2.5 rounded-xl text-xs font-semibold transition-all flex items-center justify-between cursor-pointer border ${
            activeTab === 'curl_tester'
              ? 'bg-slate-900 text-emerald-400 border-slate-900 shadow-xs'
              : 'bg-white hover:bg-slate-100 text-slate-700 border-slate-200 shadow-2xs'
          }`}
          title="Direct cURL Terminal & Tester"
        >
          <div className="flex items-center gap-2">
            <Terminal className={`w-3.5 h-3.5 ${activeTab === 'curl_tester' ? 'text-emerald-400' : 'text-slate-500'}`} />
            <span>cURL Direct Tester</span>
          </div>
          <span className={`text-[9px] font-mono font-bold px-1.5 py-0.5 rounded ${
            activeTab === 'curl_tester' ? 'bg-emerald-950 text-emerald-300 border border-emerald-800' : 'bg-slate-100 text-slate-600'
          }`}>
            CLI
          </span>
        </button>

        {/* User Identity Footer */}
        <div
          onClick={() => setActiveTab('settings')}
          className="pt-2 mt-1 border-t border-slate-200/70 flex items-center justify-between gap-2 px-1 py-1 rounded-xl hover:bg-slate-200/50 transition-colors cursor-pointer group"
          title="Click to view/edit User Settings"
        >
          <div className="flex items-center gap-2.5 min-w-0">
            <div className="w-8 h-8 rounded-full bg-indigo-600 text-white flex items-center justify-center font-bold text-xs shrink-0 shadow-xs group-hover:scale-105 transition-transform">
              {(userName.trim() || 'U').charAt(0).toUpperCase()}
            </div>
            <div className="min-w-0 flex-1">
              <div className="text-xs font-bold text-slate-800 truncate group-hover:text-indigo-600 transition-colors">
                {userName.trim() || 'Guest User'}
              </div>
              <div className="text-[10px] text-slate-400 truncate flex items-center gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 inline-block"></span>
                <span>{storageMode === 'file' ? 'File Sync' : 'Local Storage'}</span>
              </div>
            </div>
          </div>
          <button
            type="button"
            className="p-1 text-slate-400 hover:text-indigo-600 rounded-lg transition-colors shrink-0"
            title="Settings"
          >
            <Sliders className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </aside>
  );
};
