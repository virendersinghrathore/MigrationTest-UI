import React, { useState, useEffect } from 'react';
import {
  DatabaseZap,
  Settings,
  Play,
  Clock,
  ChevronDown,
  ChevronRight,
  AlertTriangle,
  CheckCircle2,
  RefreshCw,
  XCircle,
  Loader2,
  Table2,
  ShieldCheck,
  ServerCrash,
} from 'lucide-react';
import { DbConnectionConfig, DbConnectionStatus, DbQueryResult } from '../../../types/dbTester';
import { loadDbConfig, saveDbConfig, testDbConnection, executeDbQuery } from '../../../utils/dbTesterStorage';

const DatabaseTesterView: React.FC = () => {
  // ── State ────────────────────────────────────────────────────────────────
  const [config, setConfig] = useState<DbConnectionConfig>(() => loadDbConfig());
  const [connectionStatus, setConnectionStatus] = useState<DbConnectionStatus>('UNTESTED');
  const [connectionError, setConnectionError] = useState<string | null>(null);
  const [serverVersion, setServerVersion] = useState<string | undefined>(undefined);
  const [isTesting, setIsTesting] = useState(false);
  const [isConfigOpen, setIsConfigOpen] = useState(false);

  const [sql, setSql] = useState('');
  const [isRunning, setIsRunning] = useState(false);
  const [queryResult, setQueryResult] = useState<DbQueryResult | null>(null);

  const [history, setHistory] = useState<string[]>([]);
  const [isHistoryOpen, setIsHistoryOpen] = useState(false);

  // Load config from localStorage on mount
  useEffect(() => {
    setConfig(loadDbConfig());
  }, []);

  // ── Handlers ─────────────────────────────────────────────────────────────
  const handleTestConnection = async () => {
    if (isTesting) return;
    setIsTesting(true);
    setConnectionError(null);
    try {
      const result = await testDbConnection(config);
      if (result.success) {
        setConnectionStatus('CONNECTED');
        setServerVersion(result.serverVersion);
        saveDbConfig(config);
      } else {
        setConnectionStatus('ERROR');
        setConnectionError(result.error ?? 'Connection failed');
      }
    } catch (err: unknown) {
      setConnectionStatus('ERROR');
      setConnectionError(err instanceof Error ? err.message : 'Unexpected error');
    } finally {
      setIsTesting(false);
    }
  };

  const handleRunQuery = async () => {
    if (connectionStatus !== 'CONNECTED' || sql.trim() === '' || isRunning) return;
    setIsRunning(true);
    setQueryResult(null);
    try {
      const result = await executeDbQuery(config, sql);
      setQueryResult(result);
      setHistory((prev) => [sql, ...prev.filter((s) => s !== sql)]);
    } catch (err: unknown) {
      setQueryResult({
        success: false,
        columns: [],
        rows: [],
        durationMs: 0,
        error: err instanceof Error ? err.message : 'Unexpected error',
      });
    } finally {
      setIsRunning(false);
    }
  };

  const handleHistoryClick = (item: string) => {
    setSql(item);
    setIsHistoryOpen(false);
  };

  const canRun = connectionStatus === 'CONNECTED' && sql.trim() !== '' && !isRunning;

  // ── Status dot colour helpers ─────────────────────────────────────────────
  const statusBadgeCls =
    connectionStatus === 'CONNECTED'
      ? 'bg-emerald-50 text-emerald-800 border-emerald-200'
      : connectionStatus === 'ERROR'
      ? 'bg-rose-50 text-rose-800 border-rose-200'
      : 'bg-slate-100 text-slate-700 border-slate-200';

  const statusDotCls =
    connectionStatus === 'CONNECTED'
      ? 'bg-emerald-500'
      : connectionStatus === 'ERROR'
      ? 'bg-rose-500'
      : 'bg-slate-400';

  const statusLabel =
    connectionStatus === 'CONNECTED'
      ? `Connected${serverVersion ? ` · MySQL ${serverVersion}` : ''}`
      : connectionStatus === 'ERROR'
      ? 'Connection Error'
      : 'Untested';

  // ── Render ────────────────────────────────────────────────────────────────
  return (
    <div className="space-y-5">
      {/* ── Top Banner ──────────────────────────────────────────────────── */}
      <div className="bg-white border border-slate-200 rounded-3xl p-6 shadow-xs">
        {/* Header row */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-5 border-b border-slate-100">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="p-1.5 bg-gradient-to-br from-indigo-500 to-indigo-700 text-white rounded-xl shadow-xs">
                <DatabaseZap className="h-4 w-4" />
              </span>
              <h1 className="text-lg font-extrabold text-slate-900 tracking-tight">
                Database Tester
              </h1>
              <span className="text-[10px] font-extrabold uppercase px-2 py-0.5 rounded-full bg-indigo-50 text-indigo-700 border border-indigo-200 flex items-center gap-1">
                <ShieldCheck className="w-2.5 h-2.5" />
                AZURE
              </span>
            </div>
            <p className="text-xs text-slate-500">
              Connect to an Azure MySQL Flexible Server using Azure Entra ID — no passwords required.
            </p>
          </div>

          <button
            onClick={() => setIsConfigOpen((v) => !v)}
            className={`px-4 py-2 text-xs font-bold rounded-xl border transition-all flex items-center gap-1.5 cursor-pointer ${
              isConfigOpen
                ? 'bg-indigo-600 text-white border-indigo-700 shadow-sm'
                : 'bg-slate-50 hover:bg-indigo-50 text-slate-700 hover:text-indigo-700 border-slate-200'
            }`}
          >
            <Settings className="w-3.5 h-3.5" />
            <span>Configure</span>
            {isConfigOpen ? (
              <ChevronDown className="w-3 h-3" />
            ) : (
              <ChevronRight className="w-3 h-3" />
            )}
          </button>
        </div>

        {/* ── Connection Status Strip ───────────────────────────────────── */}
        <div className="pt-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div
              className={`px-3 py-1.5 rounded-xl flex items-center gap-2 font-mono font-bold text-xs border ${statusBadgeCls}`}
            >
              <span className={`w-2 h-2 rounded-full ${statusDotCls}`} />
              <span>{statusLabel}</span>
            </div>
            {config.host && (
              <span className="font-mono text-slate-500 text-[11px] truncate max-w-[260px]">
                {config.host}:{config.port}/{config.database}
              </span>
            )}
          </div>

          <button
            onClick={handleTestConnection}
            disabled={isTesting}
            className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 disabled:opacity-40 text-slate-700 text-[11px] font-bold rounded-lg transition-all flex items-center gap-1.5 cursor-pointer"
          >
            {isTesting ? (
              <Loader2 className="w-3 h-3 animate-spin text-indigo-600" />
            ) : (
              <RefreshCw className="w-3 h-3 text-indigo-600" />
            )}
            <span>{isTesting ? 'Testing...' : 'Test Connection'}</span>
          </button>
        </div>

        {/* Connection error banner */}
        {connectionStatus === 'ERROR' && connectionError && (
          <div className="mt-3 p-3.5 bg-rose-50 border border-rose-200 rounded-2xl text-xs flex items-start gap-2">
            <AlertTriangle className="w-4 h-4 text-rose-500 mt-0.5 shrink-0" />
            <div>
              <p className="font-bold text-rose-800 mb-0.5">Connection Failed</p>
              <p className="text-rose-700 font-mono">{connectionError}</p>
            </div>
          </div>
        )}

        {/* ── Inline Collapsible Config Panel ──────────────────────────── */}
        {isConfigOpen && (
          <div className="mt-4 p-4 bg-slate-50 border border-slate-200 rounded-2xl space-y-3">
            <p className="text-[11px] font-extrabold uppercase text-slate-500 tracking-wider mb-2">
              Connection Configuration
            </p>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {/* Host */}
              <div>
                <label className="block text-[11px] font-bold text-slate-600 mb-1">
                  Host
                </label>
                <input
                  type="text"
                  value={config.host}
                  onChange={(e) => setConfig((c) => ({ ...c, host: e.target.value }))}
                  placeholder="myserver.mysql.database.azure.com"
                  className="w-full px-3 py-2 text-xs border border-slate-200 rounded-xl bg-white focus:outline-none focus:ring-2 focus:ring-indigo-400 font-mono"
                />
              </div>

              {/* Port */}
              <div>
                <label className="block text-[11px] font-bold text-slate-600 mb-1">
                  Port
                </label>
                <input
                  type="number"
                  value={config.port}
                  onChange={(e) =>
                    setConfig((c) => ({ ...c, port: parseInt(e.target.value, 10) || 3306 }))
                  }
                  placeholder="3306"
                  className="w-full px-3 py-2 text-xs border border-slate-200 rounded-xl bg-white focus:outline-none focus:ring-2 focus:ring-indigo-400 font-mono"
                />
              </div>

              {/* Database */}
              <div>
                <label className="block text-[11px] font-bold text-slate-600 mb-1">
                  Database
                </label>
                <input
                  type="text"
                  value={config.database}
                  onChange={(e) => setConfig((c) => ({ ...c, database: e.target.value }))}
                  placeholder="my_database"
                  className="w-full px-3 py-2 text-xs border border-slate-200 rounded-xl bg-white focus:outline-none focus:ring-2 focus:ring-indigo-400 font-mono"
                />
              </div>

              {/* Tenant ID */}
              <div>
                <label className="block text-[11px] font-bold text-slate-600 mb-1">
                  Azure Tenant ID{' '}
                  <span className="font-normal text-slate-400">(optional)</span>
                </label>
                <input
                  type="text"
                  value={config.tenantId ?? ''}
                  onChange={(e) =>
                    setConfig((c) => ({ ...c, tenantId: e.target.value || undefined }))
                  }
                  placeholder="xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx"
                  className="w-full px-3 py-2 text-xs border border-slate-200 rounded-xl bg-white focus:outline-none focus:ring-2 focus:ring-indigo-400 font-mono"
                />
              </div>
            </div>

            <div className="pt-1 flex justify-end">
              <button
                onClick={handleTestConnection}
                disabled={isTesting || !config.host || !config.database}
                className="px-5 py-2 bg-indigo-600 hover:bg-indigo-700 disabled:bg-slate-300 disabled:cursor-not-allowed text-white text-xs font-bold rounded-xl shadow-sm shadow-indigo-600/25 transition-all flex items-center gap-2 cursor-pointer"
              >
                {isTesting ? (
                  <>
                    <Loader2 className="w-3.5 h-3.5 animate-spin" />
                    <span>Testing...</span>
                  </>
                ) : (
                  <>
                    <ShieldCheck className="w-3.5 h-3.5" />
                    <span>Test Connection</span>
                  </>
                )}
              </button>
            </div>

            {/* No-password notice */}
            <p className="text-[10px] text-slate-400 flex items-center gap-1 pt-1">
              <ShieldCheck className="w-3 h-3 text-indigo-400" />
              Authentication is handled by Azure Entra ID — no password field required. Ensure{' '}
              <code className="font-mono">az login</code> is run locally.
            </p>
          </div>
        )}
      </div>

      {/* ── SQL Editor ──────────────────────────────────────────────────── */}
      <div className="bg-white border border-slate-200 rounded-3xl p-6 shadow-xs space-y-3">
        <div className="flex items-center justify-between mb-1">
          <div className="flex items-center gap-2">
            <Table2 className="w-4 h-4 text-indigo-600" />
            <h2 className="text-sm font-extrabold text-slate-800 tracking-tight">SQL Editor</h2>
          </div>
          {connectionStatus !== 'CONNECTED' && (
            <span className="text-[10px] font-bold text-amber-600 bg-amber-50 border border-amber-200 px-2 py-0.5 rounded-full">
              Connect first to enable execution
            </span>
          )}
        </div>

        <textarea
          value={sql}
          onChange={(e) => setSql(e.target.value)}
          placeholder="Enter SQL query…&#10;&#10;Example: SELECT * FROM customers LIMIT 10;"
          rows={7}
          spellCheck={false}
          className="w-full px-4 py-3 text-xs font-mono border border-slate-200 rounded-2xl bg-slate-50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-indigo-400 resize-y placeholder-slate-400 text-slate-800"
        />

        <div className="flex justify-end">
          <button
            onClick={handleRunQuery}
            disabled={!canRun}
            className="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-700 disabled:bg-slate-200 disabled:text-slate-400 disabled:cursor-not-allowed text-white text-xs font-bold rounded-xl shadow-md shadow-indigo-600/20 transition-all flex items-center gap-2 cursor-pointer"
          >
            {isRunning ? (
              <>
                <Loader2 className="w-3.5 h-3.5 animate-spin" />
                <span>Running...</span>
              </>
            ) : (
              <>
                <Play className="w-3.5 h-3.5 fill-current" />
                <span>▶ Run Query</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* ── Results Area ────────────────────────────────────────────────── */}
      {queryResult !== null && (
        <div className="bg-white border border-slate-200 rounded-3xl p-6 shadow-xs">
          {queryResult.success ? (
            <>
              {/* Success header */}
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-500" />
                  <h2 className="text-sm font-extrabold text-slate-800 tracking-tight">
                    {queryResult.rows.length > 0
                      ? `Results — ${queryResult.rows.length} row${queryResult.rows.length !== 1 ? 's' : ''}`
                      : 'Query Executed'}
                  </h2>
                  <span className="text-[10px] font-bold text-slate-500 bg-slate-100 border border-slate-200 px-2 py-0.5 rounded-full font-mono">
                    {queryResult.durationMs}ms
                  </span>
                  {queryResult.affectedRows !== undefined && (
                    <span className="text-[10px] font-bold text-indigo-700 bg-indigo-50 border border-indigo-200 px-2 py-0.5 rounded-full">
                      {queryResult.affectedRows} affected
                    </span>
                  )}
                </div>
              </div>

              {queryResult.rows.length === 0 ? (
                <div className="flex flex-col items-center justify-center py-10 text-slate-400">
                  <Table2 className="w-8 h-8 mb-2 opacity-40" />
                  <p className="text-sm font-bold">No results</p>
                  <p className="text-xs mt-1">The query returned an empty set.</p>
                </div>
              ) : (
                <div className="overflow-x-auto rounded-2xl border border-slate-200">
                  <table className="w-full text-xs text-left">
                    <thead className="bg-slate-50 border-b border-slate-200">
                      <tr>
                        {queryResult.columns.map((col) => (
                          <th
                            key={col}
                            className="px-4 py-2.5 font-extrabold text-slate-700 whitespace-nowrap"
                          >
                            {col}
                          </th>
                        ))}
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {queryResult.rows.map((row, rowIdx) => (
                        <tr
                          key={rowIdx}
                          className="hover:bg-slate-50 transition-colors"
                        >
                          {queryResult.columns.map((col) => (
                            <td
                              key={col}
                              className="px-4 py-2 text-slate-700 font-mono whitespace-nowrap max-w-[240px] truncate"
                              title={String(row[col] ?? '')}
                            >
                              {row[col] === null ? (
                                <span className="text-slate-400 italic">NULL</span>
                              ) : (
                                String(row[col])
                              )}
                            </td>
                          ))}
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </>
          ) : (
            /* Query error */
            <div className="flex items-start gap-3 p-4 bg-rose-50 border border-rose-200 rounded-2xl">
              <XCircle className="w-5 h-5 text-rose-500 shrink-0 mt-0.5" />
              <div className="min-w-0">
                <p className="text-xs font-extrabold text-rose-800 mb-1 flex items-center gap-2">
                  Query Failed
                  {queryResult.errorCode !== undefined && (
                    <span className="font-mono font-bold px-1.5 py-0.5 bg-rose-100 border border-rose-200 rounded text-[10px]">
                      Error {queryResult.errorCode}
                    </span>
                  )}
                </p>
                <p className="text-xs font-mono text-rose-700 break-all">{queryResult.error}</p>
              </div>
            </div>
          )}
        </div>
      )}

      {/* ── Query History ────────────────────────────────────────────────── */}
      {history.length > 0 && (
        <div className="bg-white border border-slate-200 rounded-3xl shadow-xs overflow-hidden">
          {/* Collapsible header */}
          <button
            onClick={() => setIsHistoryOpen((v) => !v)}
            className="w-full flex items-center justify-between px-6 py-4 text-left hover:bg-slate-50 transition-colors cursor-pointer"
          >
            <div className="flex items-center gap-2">
              <Clock className="w-4 h-4 text-indigo-500" />
              <span className="text-sm font-extrabold text-slate-800 tracking-tight">
                Query History
              </span>
              <span className="text-[10px] font-extrabold px-1.5 py-0.5 rounded-full bg-indigo-600 text-white">
                {history.length}
              </span>
            </div>
            {isHistoryOpen ? (
              <ChevronDown className="w-4 h-4 text-slate-400" />
            ) : (
              <ChevronRight className="w-4 h-4 text-slate-400" />
            )}
          </button>

          {isHistoryOpen && (
            <div className="border-t border-slate-100 divide-y divide-slate-100">
              {history.map((item, idx) => (
                <button
                  key={idx}
                  onClick={() => handleHistoryClick(item)}
                  className="w-full text-left px-6 py-3 hover:bg-indigo-50 transition-colors group cursor-pointer"
                >
                  <div className="flex items-start gap-2">
                    <span className="text-[10px] font-extrabold text-indigo-400 mt-0.5 shrink-0 w-4 text-right">
                      {idx + 1}
                    </span>
                    <pre className="text-xs text-slate-700 group-hover:text-indigo-700 font-mono whitespace-pre-wrap break-all line-clamp-2 transition-colors">
                      {item}
                    </pre>
                  </div>
                </button>
              ))}
            </div>
          )}
        </div>
      )}

      {/* ── Empty state when no query has been run yet ───────────────────── */}
      {queryResult === null && history.length === 0 && (
        <div className="bg-white border border-dashed border-slate-200 rounded-3xl p-8 text-center text-slate-400">
          <ServerCrash className="w-9 h-9 mx-auto mb-3 opacity-30" />
          <p className="text-sm font-bold mb-1">No results yet</p>
          <p className="text-xs">
            Configure the connection, connect, then write a SQL statement and click{' '}
            <span className="font-bold text-indigo-500">▶ Run Query</span>.
          </p>
        </div>
      )}
    </div>
  );
};

export default DatabaseTesterView;
