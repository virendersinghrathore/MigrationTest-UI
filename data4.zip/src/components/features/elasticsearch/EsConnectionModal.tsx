import React, { useState } from 'react';
import {
  X, Check, Activity, AlertCircle, Database, ShieldCheck, RefreshCw,
  Cookie, LogIn, Eye, EyeOff, Clipboard, ChevronDown, ChevronRight,
  Info
} from 'lucide-react';
import { EsConnectionConfig, EsClusterInfo } from '../../../types/elasticsearch';
import {
  testElasticsearchConnection,
  saveEsConnectionConfig,
  fetchLoginCookie,
} from '../../../utils/elasticsearchStorage';

interface EsConnectionModalProps {
  isOpen: boolean;
  onClose: () => void;
  config: EsConnectionConfig;
  onSaveConfig: (config: EsConnectionConfig) => void;
  onConnectionTested?: (info: EsClusterInfo | null, isConnected: boolean) => void;
}

export const EsConnectionModal: React.FC<EsConnectionModalProps> = ({
  isOpen,
  onClose,
  config,
  onSaveConfig,
  onConnectionTested,
}) => {
  const [formData, setFormData] = useState<EsConnectionConfig>(config);
  const [isTesting, setIsTesting] = useState(false);
  const [isFetchingCookie, setIsFetchingCookie] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [showCookieLoginPass, setShowCookieLoginPass] = useState(false);
  const [showCookieAdvanced, setShowCookieAdvanced] = useState(false);
  const [cookieFetchResult, setCookieFetchResult] = useState<{
    success: boolean;
    cookie?: string;
    error?: string;
  } | null>(null);
  const [testResult, setTestResult] = useState<{
    success: boolean;
    clusterInfo?: EsClusterInfo;
    error?: string;
  } | null>(null);

  if (!isOpen) return null;

  const handleTest = async () => {
    setIsTesting(true);
    setTestResult(null);
    try {
      const res = await testElasticsearchConnection(formData);
      if (res.success && res.clusterInfo) {
        setTestResult({
          success: true,
          clusterInfo: {
            ...res.clusterInfo,
            health: res.health,
          },
        });
        onConnectionTested?.(res.clusterInfo, true);
      } else {
        setTestResult({
          success: false,
          error: res.error || 'Connection failed',
        });
        onConnectionTested?.(null, false);
      }
    } catch (e: any) {
      setTestResult({
        success: false,
        error: e.message || 'Unknown network error',
      });
      onConnectionTested?.(null, false);
    } finally {
      setIsTesting(false);
    }
  };

  const handleFetchCookie = async () => {
    if (!formData.url) {
      setCookieFetchResult({ success: false, error: 'Cluster URL is required' });
      return;
    }
    setIsFetchingCookie(true);
    setCookieFetchResult(null);
    try {
      const res = await fetchLoginCookie({
        url: formData.url,
        loginPath: formData.cookieLoginUrl || '/api/v1/auth/login',
        username: formData.cookieLoginUsername,
        password: formData.cookieLoginPassword,
      });
      if (res.success && res.cookie) {
        setFormData((prev) => ({ ...prev, cookie: res.cookie! }));
        setCookieFetchResult({
          success: true,
          cookie: res.cookie,
        });
      } else {
        setCookieFetchResult({
          success: false,
          error: res.error || 'No cookie returned from login endpoint',
        });
      }
    } catch (e: any) {
      setCookieFetchResult({ success: false, error: e.message });
    } finally {
      setIsFetchingCookie(false);
    }
  };

  const handlePasteCookie = async () => {
    try {
      const text = await navigator.clipboard.readText();
      if (text) {
        setFormData((prev) => ({ ...prev, cookie: text.trim() }));
      }
    } catch {
      // clipboard read not available
    }
  };

  const handleSave = () => {
    saveEsConnectionConfig(formData);
    onSaveConfig(formData);
    onClose();
  };

  const AUTH_OPTIONS = [
    { value: 'none', label: 'No Authentication (Anonymous)' },
    { value: 'basic', label: 'Basic Auth (Username / Password)' },
    { value: 'apiKey', label: 'Elasticsearch API Key' },
    { value: 'bearer', label: 'Bearer Token (JWT)' },
    { value: 'cookie', label: 'Cookie-Based Login (Session Auth)' },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4 animate-fadeIn">
      <div className="bg-white border border-slate-200 rounded-3xl w-full max-w-xl shadow-2xl relative flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="flex items-center justify-between p-7 pb-4 border-b border-slate-100 shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="p-2.5 bg-amber-50 text-amber-600 rounded-2xl border border-amber-200/80">
              <Database className="h-5 w-5" />
            </div>
            <div>
              <h3 className="text-base font-extrabold text-slate-900">
                Elasticsearch Connection Settings
              </h3>
              <p className="text-[11px] text-slate-500">
                Configure cluster URL and credentials. Saved locally in browser.
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-slate-700 p-1.5 rounded-lg hover:bg-slate-100 transition-colors cursor-pointer"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Scrollable Body */}
        <div className="overflow-y-auto flex-1 p-7 pt-5 space-y-4">
          {/* Cluster URL */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1.5">
              Elasticsearch Cluster URL <span className="text-rose-500">*</span>
            </label>
            <input
              type="text"
              required
              value={formData.url}
              onChange={(e) => setFormData({ ...formData, url: e.target.value })}
              placeholder="e.g. http://localhost:9200 or https://es-prod.corp:9200"
              className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3.5 py-2.5 text-xs font-mono text-slate-900 focus:outline-none focus:border-indigo-600"
            />
          </div>

          {/* Auth Type + Default Index Row */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1.5">
                Authentication Type
              </label>
              <select
                value={formData.authType}
                onChange={(e) => {
                  setFormData({ ...formData, authType: e.target.value as any });
                  setTestResult(null);
                  setCookieFetchResult(null);
                }}
                className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3.5 py-2.5 text-xs text-slate-900 focus:outline-none focus:border-indigo-600 cursor-pointer"
              >
                {AUTH_OPTIONS.map((o) => (
                  <option key={o.value} value={o.value}>{o.label}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1.5">
                Default Index / Pattern
              </label>
              <input
                type="text"
                value={formData.defaultIndex || ''}
                onChange={(e) => setFormData({ ...formData, defaultIndex: e.target.value })}
                placeholder="e.g. customers-*, audit-*"
                className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3.5 py-2.5 text-xs font-mono text-slate-900 focus:outline-none focus:border-indigo-600"
              />
            </div>
          </div>

          {/* ────── Basic Auth ────── */}
          {formData.authType === 'basic' && (
            <div className="grid grid-cols-2 gap-3 p-3.5 bg-slate-50 border border-slate-200 rounded-2xl">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Username</label>
                <input
                  type="text"
                  value={formData.username || ''}
                  onChange={(e) => setFormData({ ...formData, username: e.target.value })}
                  placeholder="e.g. elastic"
                  className="w-full bg-white border border-slate-200 rounded-xl px-3 py-1.5 text-xs text-slate-900 focus:outline-none focus:border-indigo-600"
                />
              </div>
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Password</label>
                <div className="relative">
                  <input
                    type={showPassword ? 'text' : 'password'}
                    value={formData.password || ''}
                    onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                    placeholder="••••••••"
                    className="w-full bg-white border border-slate-200 rounded-xl px-3 py-1.5 text-xs text-slate-900 focus:outline-none focus:border-indigo-600 pr-8"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword((s) => !s)}
                    className="absolute right-2 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-700 cursor-pointer"
                  >
                    {showPassword ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* ────── API Key ────── */}
          {formData.authType === 'apiKey' && (
            <div className="p-3.5 bg-slate-50 border border-slate-200 rounded-2xl">
              <label className="block text-xs font-bold text-slate-700 mb-1">
                API Key (Base64 Encoded or Key:Value)
              </label>
              <input
                type="password"
                value={formData.apiKey || ''}
                onChange={(e) => setFormData({ ...formData, apiKey: e.target.value })}
                placeholder="e.g. VnVhQ2ZHY0JDZGJrUW..."
                className="w-full bg-white border border-slate-200 rounded-xl px-3 py-1.5 text-xs font-mono text-slate-900 focus:outline-none focus:border-indigo-600"
              />
            </div>
          )}

          {/* ────── Bearer Token ────── */}
          {formData.authType === 'bearer' && (
            <div className="p-3.5 bg-slate-50 border border-slate-200 rounded-2xl">
              <label className="block text-xs font-bold text-slate-700 mb-1">Bearer Token</label>
              <input
                type="password"
                value={formData.bearerToken || ''}
                onChange={(e) => setFormData({ ...formData, bearerToken: e.target.value })}
                placeholder="Bearer eyJhbGci..."
                className="w-full bg-white border border-slate-200 rounded-xl px-3 py-1.5 text-xs font-mono text-slate-900 focus:outline-none focus:border-indigo-600"
              />
            </div>
          )}

          {/* ────── Cookie-Based Login ────── */}
          {formData.authType === 'cookie' && (
            <div className="space-y-3 p-4 bg-violet-50/60 border border-violet-200 rounded-2xl">
              {/* Info banner */}
              <div className="flex items-start gap-2 text-[11px] text-violet-700 bg-violet-100/80 border border-violet-200 rounded-xl px-3 py-2">
                <Info className="w-3.5 h-3.5 shrink-0 mt-0.5" />
                <span>
                  Cookie auth works with applications that use session-based login (e.g. Kibana, custom APIs).
                  The proxy server will perform a login request and capture the session cookie for you.
                </span>
              </div>

              {/* Auto Login Section */}
              <div className="space-y-2.5">
                <p className="text-xs font-bold text-slate-700 flex items-center gap-1.5">
                  <LogIn className="w-3.5 h-3.5 text-violet-600" />
                  Auto-Fetch Cookie via Login Endpoint
                </p>

                <div>
                  <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                    Login Endpoint Path
                  </label>
                  <input
                    type="text"
                    value={formData.cookieLoginUrl || '/api/v1/auth/login'}
                    onChange={(e) => setFormData({ ...formData, cookieLoginUrl: e.target.value })}
                    placeholder="/api/v1/auth/login"
                    className="w-full bg-white border border-violet-200 rounded-xl px-3 py-1.5 text-xs font-mono text-slate-900 focus:outline-none focus:border-violet-500"
                  />
                  <p className="text-[10px] text-slate-500 mt-1">
                    Relative path appended to the cluster URL above.
                    e.g. <span className="font-mono">/api/security/login</span> for Kibana.
                  </p>
                </div>

                <div className="grid grid-cols-2 gap-2.5">
                  <div>
                    <label className="block text-[11px] font-semibold text-slate-600 mb-1">Username</label>
                    <input
                      type="text"
                      value={formData.cookieLoginUsername || ''}
                      onChange={(e) => setFormData({ ...formData, cookieLoginUsername: e.target.value })}
                      placeholder="admin"
                      className="w-full bg-white border border-violet-200 rounded-xl px-3 py-1.5 text-xs text-slate-900 focus:outline-none focus:border-violet-500"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] font-semibold text-slate-600 mb-1">Password</label>
                    <div className="relative">
                      <input
                        type={showCookieLoginPass ? 'text' : 'password'}
                        value={formData.cookieLoginPassword || ''}
                        onChange={(e) => setFormData({ ...formData, cookieLoginPassword: e.target.value })}
                        placeholder="••••••••"
                        className="w-full bg-white border border-violet-200 rounded-xl px-3 py-1.5 text-xs text-slate-900 focus:outline-none focus:border-violet-500 pr-7"
                      />
                      <button
                        type="button"
                        onClick={() => setShowCookieLoginPass((s) => !s)}
                        className="absolute right-2 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-700 cursor-pointer"
                      >
                        {showCookieLoginPass ? <EyeOff className="w-3 h-3" /> : <Eye className="w-3 h-3" />}
                      </button>
                    </div>
                  </div>
                </div>

                {/* Fetch Cookie Button */}
                <button
                  type="button"
                  onClick={handleFetchCookie}
                  disabled={isFetchingCookie || !formData.url}
                  className="w-full px-4 py-2 bg-violet-600 hover:bg-violet-700 disabled:bg-slate-300 text-white text-xs font-bold rounded-xl transition-all flex items-center justify-center gap-1.5 cursor-pointer shadow-sm shadow-violet-600/30"
                >
                  {isFetchingCookie ? (
                    <>
                      <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                      <span>Fetching Cookie from Login Endpoint...</span>
                    </>
                  ) : (
                    <>
                      <Cookie className="w-3.5 h-3.5" />
                      <span>Auto-Fetch Session Cookie</span>
                    </>
                  )}
                </button>

                {/* Fetch Result */}
                {cookieFetchResult && (
                  <div
                    className={`p-3 rounded-xl border text-xs ${
                      cookieFetchResult.success
                        ? 'bg-emerald-50 border-emerald-200 text-emerald-900'
                        : 'bg-rose-50 border-rose-200 text-rose-900'
                    }`}
                  >
                    {cookieFetchResult.success ? (
                      <div className="space-y-1.5">
                        <div className="flex items-center gap-1.5 font-bold text-emerald-700">
                          <Check className="w-3.5 h-3.5" />
                          <span>Cookie Captured Successfully!</span>
                        </div>
                        <div className="font-mono text-[10px] text-emerald-800 bg-emerald-100/80 rounded-lg px-2.5 py-1.5 break-all line-clamp-2">
                          {cookieFetchResult.cookie}
                        </div>
                        <p className="text-[10px] text-emerald-700">
                          Cookie auto-filled below. Click "Save Settings" to persist.
                        </p>
                      </div>
                    ) : (
                      <div className="flex items-start gap-1.5">
                        <AlertCircle className="w-3.5 h-3.5 text-rose-600 shrink-0 mt-0.5" />
                        <div>
                          <span className="font-bold block">Cookie Fetch Failed:</span>
                          <span className="text-[11px] text-rose-700 break-all">{cookieFetchResult.error}</span>
                        </div>
                      </div>
                    )}
                  </div>
                )}
              </div>

              {/* Divider */}
              <div className="relative flex items-center gap-3 my-1">
                <div className="flex-1 h-px bg-violet-200"></div>
                <span className="text-[10px] font-bold text-violet-500 uppercase">or paste manually</span>
                <div className="flex-1 h-px bg-violet-200"></div>
              </div>

              {/* Manual Cookie Input */}
              <div>
                <label className="block text-[11px] font-bold text-slate-700 mb-1 flex items-center gap-1.5">
                  <Cookie className="w-3 h-3 text-violet-600" />
                  Active Session Cookie String
                </label>
                <div className="flex gap-2">
                  <textarea
                    value={formData.cookie || ''}
                    onChange={(e) => setFormData({ ...formData, cookie: e.target.value })}
                    placeholder="Paste cookie string here, e.g.: sid=abc123; JSESSIONID=xyz; kibana_session=..."
                    rows={2}
                    className="flex-1 bg-white border border-violet-200 rounded-xl px-3 py-2 text-[11px] font-mono text-slate-900 focus:outline-none focus:border-violet-500 resize-none"
                  />
                  <button
                    type="button"
                    onClick={handlePasteCookie}
                    className="px-2.5 py-2 bg-violet-100 hover:bg-violet-200 text-violet-700 rounded-xl flex items-center gap-1 text-xs font-bold cursor-pointer transition-all shrink-0 self-start"
                    title="Paste from clipboard"
                  >
                    <Clipboard className="w-3.5 h-3.5" />
                  </button>
                </div>
                <p className="text-[10px] text-slate-500 mt-1">
                  Copy from browser DevTools → Network tab → Request Headers → Cookie.
                  The proxy will forward this with <span className="font-mono">kbn-xsrf: true</span>.
                </p>
              </div>

              {/* Advanced Toggle */}
              <button
                type="button"
                onClick={() => setShowCookieAdvanced((s) => !s)}
                className="flex items-center gap-1.5 text-[11px] font-bold text-violet-600 hover:text-violet-800 transition-colors cursor-pointer"
              >
                {showCookieAdvanced ? <ChevronDown className="w-3.5 h-3.5" /> : <ChevronRight className="w-3.5 h-3.5" />}
                Advanced Cookie Settings
              </button>

              {showCookieAdvanced && (
                <div className="space-y-2.5 pt-1 border-t border-violet-100">
                  <div>
                    <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                      Custom Headers (JSON)
                    </label>
                    <textarea
                      value={formData.customHeaders || ''}
                      onChange={(e) => setFormData({ ...formData, customHeaders: e.target.value })}
                      placeholder={'{"X-Custom-Header": "value", "X-Tenant-ID": "my-org"}'}
                      rows={2}
                      className="w-full bg-white border border-violet-200 rounded-xl px-3 py-2 text-[11px] font-mono text-slate-900 focus:outline-none focus:border-violet-500 resize-none"
                    />
                    <p className="text-[10px] text-slate-500 mt-1">
                      Additional headers merged with each query request (e.g. for multi-tenant apps).
                    </p>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* Custom Headers for non-cookie auth */}
          {formData.authType !== 'cookie' && formData.authType !== 'none' && (
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Custom Headers (JSON, optional)
              </label>
              <input
                type="text"
                value={formData.customHeaders || ''}
                onChange={(e) => setFormData({ ...formData, customHeaders: e.target.value })}
                placeholder={'{"X-Tenant": "my-org"}'}
                className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-1.5 text-xs font-mono text-slate-900 focus:outline-none focus:border-indigo-600"
              />
            </div>
          )}

          {/* Test Connection Feedback */}
          {testResult && (
            <div
              className={`p-3.5 rounded-2xl border text-xs ${
                testResult.success
                  ? 'bg-emerald-50 border-emerald-200 text-emerald-900'
                  : 'bg-rose-50 border-rose-200 text-rose-900'
              }`}
            >
              {testResult.success && testResult.clusterInfo ? (
                <div className="space-y-1">
                  <div className="flex items-center gap-1.5 font-bold text-emerald-700">
                    <ShieldCheck className="w-4 h-4 text-emerald-600" />
                    <span>Connection Successful!</span>
                  </div>
                  <div className="text-[11px] text-emerald-800 grid grid-cols-2 gap-2 mt-1 font-mono">
                    <div>Cluster: <strong>{testResult.clusterInfo.cluster_name}</strong></div>
                    <div>Version: <strong>{testResult.clusterInfo.version?.number || '8.x'}</strong></div>
                    {testResult.clusterInfo.health?.status && (
                      <div>Health: <strong className="uppercase">{testResult.clusterInfo.health.status}</strong></div>
                    )}
                    {testResult.clusterInfo.health?.number_of_nodes && (
                      <div>Nodes: <strong>{testResult.clusterInfo.health.number_of_nodes}</strong></div>
                    )}
                  </div>
                </div>
              ) : (
                <div className="flex items-start gap-2">
                  <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
                  <div>
                    <span className="font-bold block">Connection Failed:</span>
                    <span className="text-[11px] text-rose-700 break-all">{testResult.error}</span>
                  </div>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="flex items-center justify-between p-7 pt-4 border-t border-slate-100 shrink-0">
          <button
            type="button"
            onClick={handleTest}
            disabled={isTesting || !formData.url}
            className="px-4 py-2 bg-slate-100 hover:bg-slate-200 disabled:opacity-50 text-slate-800 text-xs font-bold rounded-xl transition-all flex items-center gap-1.5 cursor-pointer"
          >
            {isTesting ? (
              <>
                <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                <span>Testing Connection...</span>
              </>
            ) : (
              <>
                <Activity className="w-3.5 h-3.5 text-amber-600" />
                <span>Test Connection</span>
              </>
            )}
          </button>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-bold text-slate-600 hover:bg-slate-100 rounded-xl cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="button"
              onClick={handleSave}
              className="px-5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold rounded-xl shadow-md cursor-pointer transition-all flex items-center gap-1.5"
            >
              <Check className="w-4 h-4" />
              <span>Save Settings Locally</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
