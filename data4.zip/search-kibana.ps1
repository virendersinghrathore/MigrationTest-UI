param(
    [Parameter(Position = 0, Mandatory = $false, HelpMessage = "Search string to look for in logs")]
    [string]$SearchTerm = "cust_99281",

    [Parameter(Mandatory = $false)]
    [string]$Index = "*",

    [Parameter(Mandatory = $false)]
    [string]$KibanaUrl = "http://localhost:5601",

    # Cookie parameter: defaults to stored cookie below
    [Parameter(Mandatory = $false)]
    [string]$Cookie = "",

    [Parameter(Mandatory = $false)]
    [string]$Username = "elastic",

    [Parameter(Mandatory = $false)]
    [string]$Password = "changeme",

    [Parameter(Mandatory = $false)]
    [int]$Size = 10,

    [Parameter(Mandatory = $false)]
    [switch]$Raw
)

# ==============================================================================
# STORED KIBANA COOKIE
# You can paste your Kibana browser cookie here anytime.
# If expired, the script will automatically re-authenticate and use the fresh cookie.
# ==============================================================================
$DefaultStoredCookie = 'sid=Fe26.2**e85fbae574bf524810e2da2b5b7dc2ad978e4f2421d247037e4257b36dc96357*Alxh_G7iz9ZmMWMuwtU9Bw*0-LAwufht5yZcl7KH-nA1Zyplep_qhpdqi-rlPuX4uyna_aWwYSNCOws54zCm6LK_lXnKvLXrDaeWTouVpch8NHBXaXkcRCzOL0ZIcTsdvtLwzYiAkD8Nc_ZS6Tzk4URJpftZ66mv1W3key8ivHsD0WzbB2VrUFCU2ltN8I93ZQowp0iky17B7XosR7qPksBPcmyBlWIOitbrUhMyhhiSkoorkAbXVJpYQ9B-A1m-BX5u_2NlRlL1_yhzh4vHhT5**5366e889e4b56149d00cccfbc34c26b7ecbfe45fac56d1291f1669a4e8897f52*3S-WMcwTQAzP7cR3C-Mo6t3wk6wwXbqLkiQiENN4AxM'

if (-not $Cookie) {
    $Cookie = $DefaultStoredCookie
}

$KibanaUrl = $KibanaUrl.TrimEnd('/')
$CookieJarPath = Join-Path $PSScriptRoot ".kibana_cookie_cache.txt"

Write-Host "==========================================================" -ForegroundColor Cyan
Write-Host "  Kibana Direct Log Search (Windows)" -ForegroundColor Cyan
Write-Host "==========================================================" -ForegroundColor Cyan
Write-Host "Kibana URL:    $KibanaUrl" -ForegroundColor Gray
Write-Host "Index Pattern: $Index" -ForegroundColor Gray
Write-Host "Search Query:  $SearchTerm" -ForegroundColor Yellow
Write-Host "==========================================================`n" -ForegroundColor Cyan

# Function to execute curl request and return parsed JSON
function Run-KibanaProxySearch {
    param([string]$CookieValue, [string]$Term, [string]$TargetIndex, [int]$Limit)

    $proxyPath = if ($TargetIndex -and $TargetIndex -ne "*") {
        "/api/console/proxy?path=$TargetIndex/_search&method=POST"
    } else {
        "/api/console/proxy?path=_search&method=POST"
    }
    $targetUrl = "$KibanaUrl$proxyPath"

    $escapedTerm = $Term.Replace('"', '\"')
    $queryDsl = @{
        size = $Limit
        query = @{
            query_string = @{
                query = "*$escapedTerm*"
                analyze_wildcard = $true
                default_operator = "AND"
            }
        }
    } | ConvertTo-Json -Compress

    $cookieHeader = if ($CookieValue -like "sid=*") { $CookieValue } else { "sid=$CookieValue" }

    $utf8NoBom = New-Object System.Text.UTF8Encoding($false)
    $tempQueryFile = Join-Path $env:TEMP "kbn_query_$([Guid]::NewGuid().ToString('N')).json"
    [System.IO.File]::WriteAllText($tempQueryFile, $queryDsl, $utf8NoBom)

    try {
        $rawOutput = & curl.exe -s -4 `
            -X POST "$targetUrl" `
            -H "Content-Type: application/json" `
            -H "kbn-xsrf: true" `
            -H "Cookie: $cookieHeader" `
            --data-binary "@$tempQueryFile"

        return $rawOutput
    } finally {
        if (Test-Path $tempQueryFile) { Remove-Item -Force $tempQueryFile }
    }
}

# Function to login to Kibana and extract fresh cookie
function Get-FreshKibanaCookie {
    param([string]$User, [string]$Pass)

    $loginUrl = "$KibanaUrl/internal/security/login"
    $loginPayload = @{
        providerType = "basic"
        providerName = "basic"
        currentURL   = "$KibanaUrl/login"
        params       = @{
            username = $User
            password = $Pass
        }
    } | ConvertTo-Json -Compress

    $utf8NoBom = New-Object System.Text.UTF8Encoding($false)
    $tempLoginFile = Join-Path $env:TEMP "kbn_login_$([Guid]::NewGuid().ToString('N')).json"
    [System.IO.File]::WriteAllText($tempLoginFile, $loginPayload, $utf8NoBom)

    try {
        $headersAndBody = & curl.exe -s -i -4 `
            -X POST "$loginUrl" `
            -H "Content-Type: application/json" `
            -H "kbn-xsrf: true" `
            --data-binary "@$tempLoginFile"

        foreach ($line in $headersAndBody) {
            if ($line -match "(?i)set-cookie:\s*(sid=[^;]+)") {
                return $matches[1].Trim()
            }
        }
        return $null
    } finally {
        if (Test-Path $tempLoginFile) { Remove-Item -Force $tempLoginFile }
    }
}

# 1. Execute Search with stored cookie
Write-Host "[1/2] Querying Kibana via DevTools proxy with stored cookie..." -ForegroundColor Gray
$rawResult = Run-KibanaProxySearch -CookieValue $Cookie -Term $SearchTerm -TargetIndex $Index -Limit $Size
$jsonResult = $null

try {
    $jsonResult = $rawResult | ConvertFrom-Json
} catch {}

# If 401 or invalid response, auto-authenticate and retry
if (-not $jsonResult -or $jsonResult.statusCode -eq 401 -or $jsonResult.error -eq "Unauthorized") {
    Write-Host "[WARN] Stored cookie expired or invalid. Auto-authenticating with Kibana ($Username)..." -ForegroundColor Yellow
    $freshCookie = Get-FreshKibanaCookie -User $Username -Pass $Password
    if ($freshCookie) {
        Write-Host "[OK] Successfully retrieved fresh Kibana cookie!" -ForegroundColor Green
        $Cookie = $freshCookie
        $rawResult = Run-KibanaProxySearch -CookieValue $Cookie -Term $SearchTerm -TargetIndex $Index -Limit $Size
        try {
            $jsonResult = $rawResult | ConvertFrom-Json
        } catch {
            Write-Host "[ERROR] Could not parse search response: $rawResult" -ForegroundColor Red
            exit 1
        }
    } else {
        Write-Host "[ERROR] Failed to authenticate to Kibana. Verify container is running on $KibanaUrl" -ForegroundColor Red
        exit 1
    }
}

if ($Raw) {
    Write-Output $rawResult
    exit 0
}

# 2. Display formatted results
$totalHits = 0
if ($jsonResult.hits -and $jsonResult.hits.total) {
    if ($jsonResult.hits.total.value -ne $null) {
        $totalHits = $jsonResult.hits.total.value
    } else {
        $totalHits = $jsonResult.hits.total
    }
} elseif ($jsonResult.hits.hits) {
    $totalHits = $jsonResult.hits.hits.Count
}

$took = if ($jsonResult.took -ne $null) { $jsonResult.took } else { 0 }

Write-Host "`n[2/2] Search completed in ${took}ms!" -ForegroundColor Green
Write-Host "Total Hits Found: $totalHits" -ForegroundColor $(if ($totalHits -gt 0) { "Green" } else { "Yellow" })
Write-Host "----------------------------------------------------------" -ForegroundColor Gray

if ($totalHits -eq 0) {
    Write-Host "No logs found matching '$SearchTerm' in index pattern '$Index'." -ForegroundColor Yellow
    Write-Host "Tip: Try searching for 'cust_99281', 'SUCCESS', or 'MIGRATION_SYNC'." -ForegroundColor Gray
    exit 0
}

$counter = 1
foreach ($hit in $jsonResult.hits.hits) {
    Write-Host "`n[$counter] Index: $($hit._index) | ID: $($hit._id) | Score: $($hit._score)" -ForegroundColor Cyan
    $src = $hit._source
    if ($src) {
        $props = $src.PSObject.Properties.Name
        foreach ($p in $props) {
            $val = $src.$p
            $valText = if ($val -is [System.Collections.IEnumerable] -and $val -isnot [string]) {
                ($val | ConvertTo-Json -Compress)
            } else {
                [string]$val
            }

            # Highlight status & key attributes
            if ($p -eq "status" -and $valText -eq "SUCCESS") {
                Write-Host "   $($p.PadRight(24)): " -NoNewline -ForegroundColor White
                Write-Host $valText -ForegroundColor Green
            } elseif ($p -eq "status" -and $valText -in @("ERROR", "FAILED")) {
                Write-Host "   $($p.PadRight(24)): " -NoNewline -ForegroundColor White
                Write-Host $valText -ForegroundColor Red
            } elseif ($p -in @("customer_name", "id", "document_id", "event_type", "timestamp", "migrated_at")) {
                Write-Host "   $($p.PadRight(24)): " -NoNewline -ForegroundColor White
                Write-Host $valText -ForegroundColor White
            } else {
                Write-Host "   $($p.PadRight(24)): $valText" -ForegroundColor Gray
            }
        }
    }
    $counter++
}

Write-Host "`n==========================================================" -ForegroundColor Cyan
Write-Host "Active Stored Cookie:" -ForegroundColor Gray
Write-Host "$Cookie" -ForegroundColor DarkGray
Write-Host "==========================================================" -ForegroundColor Cyan
