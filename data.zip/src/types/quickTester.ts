import { HttpMethod, ValidationRuleItem } from '../types';
import { DiffToken } from '../utils/wordDiff';

export interface FieldRegexMapping {
  id: string;
  couchField: string;
  targetField: string;
  regexRuleKey?: string; // key of ValidationRuleItem or empty
  customRegexPattern?: string;
  customRegexName?: string;
  enabled: boolean;
}

export type QuickFieldStatus =
  | 'EXACT_MATCH'
  | 'VALUE_MISMATCH'
  | 'REGEX_FAILED'
  | 'MISSING_IN_TARGET'
  | 'EXTRA_IN_TARGET'
  | 'TYPE_MISMATCH';

export interface QuickFieldEvaluationResult {
  id: string;
  couchField: string;
  targetField: string;
  couchVal: any;
  targetVal: any;
  couchType: string;
  targetType: string;
  isWordMatch: boolean;
  wordDiffTokens?: DiffToken[];
  matchPercentage: number;
  regexRuleKey?: string;
  regexRuleDesc?: string;
  regexPattern?: string;
  isRegexMatch: boolean;
  regexErrorMessage?: string;
  status: QuickFieldStatus;
  statusMessage: string;
}

export interface QuickTestRunReport {
  timestamp: string;
  testName: string;
  endpoint: string;
  method: HttpMethod;
  totalFields: number;
  exactMatchesCount: number;
  regexPassedCount: number;
  mismatchedCount: number;
  missingCount: number;
  extraCount: number;
  overallMatchScore: number;
  results: QuickFieldEvaluationResult[];
}

export interface SavedQuickTest {
  id: string;
  testName: string;
  endpoint: string;
  method: HttpMethod;
  description?: string;
  couchPayloadStr: string;
  apiPayloadStr: string;
  mappings: FieldRegexMapping[];
  lastReport?: QuickTestRunReport;
  createdAt: string;
  updatedAt: string;
}
