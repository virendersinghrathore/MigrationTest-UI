import { ValidationRuleItem } from '../types';
import { INITIAL_VALIDATION_RULES } from '../mockValidationRules';
import { safeJsonParse } from './jsonHelper';
import { saveToFileSystem, loadFromFileSystem } from './storage';

const SHARED_REGEX_STORAGE_KEY = 'couch_shared_validation_rules_v1';

// Enhanced built-in rules with phone, uuid, iso date, numeric
export const DEFAULT_SHARED_RULES: ValidationRuleItem[] = [
  ...INITIAL_VALIDATION_RULES,
  {
    id: 'vr-9',
    key: 'uuid',
    desc: 'Validates standard UUID v4 string format.',
    regexPattern: '^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$',
    isBuiltIn: true,
  },
  {
    id: 'vr-10',
    key: 'phone',
    desc: 'Validates international phone format with optional leading plus.',
    regexPattern: '^\\+?[1-9]\\d{1,14}$',
    isBuiltIn: true,
  },
  {
    id: 'vr-11',
    key: 'iso_date',
    desc: 'Validates standard ISO 8601 date string (YYYY-MM-DD or full timestamp).',
    regexPattern: '^\\d{4}-\\d{2}-\\d{2}(T\\d{2}:\\d{2}:\\d{2}(\\.\\d+)?(Z|[+-]\\d{2}:?\\d{2})?)?$',
    isBuiltIn: true,
  },
  {
    id: 'vr-12',
    key: 'integer',
    desc: 'Validates integer number format (positive or negative).',
    regexPattern: '^-?\\d+$',
    isBuiltIn: true,
  },
];

/**
 * Loads shared regex rules from localStorage and fallback, migrating any profile rules.
 */
export function getSharedRegexRules(): ValidationRuleItem[] {
  const stored = localStorage.getItem(SHARED_REGEX_STORAGE_KEY);
  if (stored) {
    const parsed = safeJsonParse<ValidationRuleItem[]>(stored, []);
    if (parsed.length > 0) return parsed;
  }

  // First time initialization: collect from default profiles if any custom rules exist
  const mergedRules = [...DEFAULT_SHARED_RULES];
  try {
    for (let i = 0; i < localStorage.length; i++) {
      const key = localStorage.key(i);
      if (key && key.startsWith('couch_validation_rules_light_')) {
        const profileRules = safeJsonParse<ValidationRuleItem[]>(localStorage.getItem(key) || '', []);
        profileRules.forEach((pr) => {
          if (!mergedRules.some((r) => r.key === pr.key || r.id === pr.id)) {
            mergedRules.push(pr);
          }
        });
      }
    }
  } catch (e) {
    console.warn('Could not inspect legacy profile validation rules', e);
  }

  localStorage.setItem(SHARED_REGEX_STORAGE_KEY, JSON.stringify(mergedRules));
  return mergedRules;
}

/**
 * Saves or updates a regex rule in the shared library (accessible across all profiles).
 */
export async function saveSharedRegexRule(
  rule: ValidationRuleItem,
  isFileMode = false
): Promise<ValidationRuleItem[]> {
  const current = getSharedRegexRules();
  const index = current.findIndex((r) => r.id === rule.id || r.key === rule.key);

  let updated: ValidationRuleItem[];
  if (index >= 0) {
    updated = current.map((r, i) => (i === index ? { ...r, ...rule } : r));
  } else {
    updated = [...current, rule];
  }

  localStorage.setItem(SHARED_REGEX_STORAGE_KEY, JSON.stringify(updated));

  if (isFileMode) {
    await saveToFileSystem('shared_validation_rules', updated);
  }

  return updated;
}

/**
 * Deletes a regex rule from the shared library.
 */
export async function deleteSharedRegexRule(
  id: string,
  isFileMode = false
): Promise<ValidationRuleItem[]> {
  const current = getSharedRegexRules();
  const updated = current.filter((r) => r.id !== id);

  localStorage.setItem(SHARED_REGEX_STORAGE_KEY, JSON.stringify(updated));

  if (isFileMode) {
    await saveToFileSystem('shared_validation_rules', updated);
  }

  return updated;
}

/**
 * Synchronizes shared rules with file system if file storage is active.
 */
export async function syncSharedRulesWithFileSystem(): Promise<ValidationRuleItem[]> {
  const local = getSharedRegexRules();
  const { data: fileData, exists } = await loadFromFileSystem<ValidationRuleItem[]>(
    'shared_validation_rules',
    local
  );

  if (exists && Array.isArray(fileData) && fileData.length > 0) {
    localStorage.setItem(SHARED_REGEX_STORAGE_KEY, JSON.stringify(fileData));
    return fileData;
  } else if (!exists) {
    await saveToFileSystem('shared_validation_rules', local);
  }
  return local;
}

/**
 * Validates a value against a regex pattern.
 */
export function testValueAgainstRegex(
  pattern: string | undefined,
  value: any
): { valid: boolean; error?: string } {
  if (!pattern || pattern.trim() === '') {
    return { valid: true };
  }

  if (value === null || value === undefined) {
    return { valid: false, error: 'Value is null or undefined' };
  }

  const strVal = typeof value === 'object' ? JSON.stringify(value) : String(value);

  try {
    const reg = new RegExp(pattern);
    const valid = reg.test(strVal);
    return {
      valid,
      error: valid ? undefined : `Value "${strVal}" does not match pattern: /${pattern}/`,
    };
  } catch (err: any) {
    return { valid: false, error: `Invalid regex syntax: ${err.message}` };
  }
}
