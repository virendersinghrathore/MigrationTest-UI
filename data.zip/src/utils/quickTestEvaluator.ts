import { HttpMethod, ValidationRuleItem } from '../types';
import {
  FieldRegexMapping,
  QuickFieldEvaluationResult,
  QuickFieldStatus,
  QuickTestRunReport,
} from '../types/quickTester';
import { flattenPayloadKeys, getNestedValue } from './jsonHelper';
import { compareValuesWordByWord } from './wordDiff';
import { testValueAgainstRegex } from './sharedRegexStorage';

export function evaluateQuickPayloads(
  testName: string,
  endpoint: string,
  method: HttpMethod,
  couchObj: Record<string, any>,
  targetObj: Record<string, any>,
  mappings: FieldRegexMapping[],
  sharedRules: ValidationRuleItem[]
): QuickTestRunReport {
  const couchFields = flattenPayloadKeys(couchObj);
  const targetFields = flattenPayloadKeys(targetObj);

  const targetPathMap = new Map<string, any>();
  targetFields.forEach((tf) => {
    targetPathMap.set(tf.path, tf.val);
  });

  const mappingByCouchField = new Map<string, FieldRegexMapping>();
  mappings.forEach((m) => {
    mappingByCouchField.set(m.couchField, m);
  });

  const ruleByKey = new Map<string, ValidationRuleItem>();
  sharedRules.forEach((r) => {
    ruleByKey.set(r.key, r);
    ruleByKey.set(r.id, r);
  });

  const results: QuickFieldEvaluationResult[] = [];
  let exactMatchesCount = 0;
  let regexPassedCount = 0;
  let mismatchedCount = 0;
  let missingCount = 0;
  let extraCount = 0;

  // Process all CouchDB fields
  couchFields.forEach((cf, idx) => {
    const mapping = mappingByCouchField.get(cf.path);
    const targetPath = mapping?.targetField || cf.path;
    const isTargetPresent = targetPathMap.has(targetPath) || getNestedValue(targetObj, targetPath) !== undefined;
    const targetVal = isTargetPresent
      ? (targetPathMap.has(targetPath) ? targetPathMap.get(targetPath) : getNestedValue(targetObj, targetPath))
      : undefined;

    // Check regex rule
    let regexPattern: string | undefined;
    let regexRuleDesc: string | undefined;

    if (mapping?.customRegexPattern) {
      regexPattern = mapping.customRegexPattern;
      regexRuleDesc = mapping.customRegexName || 'Custom Regex';
    } else if (mapping?.regexRuleKey) {
      const foundRule = ruleByKey.get(mapping.regexRuleKey);
      if (foundRule) {
        regexPattern = foundRule.regexPattern;
        regexRuleDesc = foundRule.desc;
      }
    }

    let isRegexMatch = true;
    let regexErrorMessage: string | undefined;

    if (regexPattern) {
      // Validate both CouchDB and Target values if present
      const couchRegexRes = testValueAgainstRegex(regexPattern, cf.val);
      const targetRegexRes = isTargetPresent
        ? testValueAgainstRegex(regexPattern, targetVal)
        : { valid: true };

      if (!couchRegexRes.valid) {
        isRegexMatch = false;
        regexErrorMessage = `CouchDB value fails regex: ${couchRegexRes.error}`;
      } else if (!targetRegexRes.valid) {
        isRegexMatch = false;
        regexErrorMessage = `Target API value fails regex: ${targetRegexRes.error}`;
      }
    }

    if (isRegexMatch && regexPattern) {
      regexPassedCount++;
    }

    // Compare values word-by-word
    let status: QuickFieldStatus = 'EXACT_MATCH';
    let statusMessage = 'Exact word-by-word match';
    let wordDiffTokens: any[] | undefined;
    let matchPercentage = 100;
    let isWordMatch = false;
    let targetType = 'UNDEFINED';

    if (!isTargetPresent) {
      status = 'MISSING_IN_TARGET';
      statusMessage = `Field "${targetPath}" is missing in target API response`;
      missingCount++;
      matchPercentage = 0;
    } else {
      targetType = targetVal === null ? 'NULL' : Array.isArray(targetVal) ? 'ARRAY' : typeof targetVal;
      const cmp = compareValuesWordByWord(cf.val, targetVal);
      isWordMatch = cmp.isMatch;
      wordDiffTokens = cmp.wordDiff?.tokens;
      matchPercentage = cmp.wordDiff?.matchPercentage ?? (cmp.isMatch ? 100 : 0);

      if (!cmp.typeMatch) {
        status = 'TYPE_MISMATCH';
        statusMessage = `Type mismatch: CouchDB has ${cf.type}, API response has ${cmp.targetType.toUpperCase()}`;
        mismatchedCount++;
      } else if (!isRegexMatch) {
        status = 'REGEX_FAILED';
        statusMessage = regexErrorMessage || 'Field value violated regex rule';
        mismatchedCount++;
      } else if (!isWordMatch) {
        status = 'VALUE_MISMATCH';
        statusMessage = `Values differ (${matchPercentage}% word similarity)`;
        mismatchedCount++;
      } else {
        status = 'EXACT_MATCH';
        statusMessage = regexPattern
          ? 'Word-by-word match & regex verified'
          : 'Exact word-by-word match';
        exactMatchesCount++;
      }
    }

    results.push({
      id: `qfr-${idx}-${cf.path}`,
      couchField: cf.path,
      targetField: targetPath,
      couchVal: cf.val,
      targetVal,
      couchType: cf.type,
      targetType: targetType.toUpperCase(),
      isWordMatch,
      wordDiffTokens,
      matchPercentage,
      regexRuleKey: mapping?.regexRuleKey,
      regexRuleDesc,
      regexPattern,
      isRegexMatch,
      regexErrorMessage,
      status,
      statusMessage,
    });
  });

  // Check for extra fields in target that are not in CouchDB
  const mappedTargetPaths = new Set(results.map((r) => r.targetField));
  targetFields.forEach((tf, idx) => {
    if (!mappedTargetPaths.has(tf.path)) {
      extraCount++;
      results.push({
        id: `qfr-extra-${idx}-${tf.path}`,
        couchField: '(None)',
        targetField: tf.path,
        couchVal: undefined,
        targetVal: tf.val,
        couchType: 'UNDEFINED',
        targetType: tf.type,
        isWordMatch: false,
        matchPercentage: 0,
        isRegexMatch: true,
        status: 'EXTRA_IN_TARGET',
        statusMessage: `Field present in API response but unmapped in CouchDB`,
      });
    }
  });

  const totalFields = results.length;
  const overallMatchScore = totalFields > 0
    ? Math.max(0, Math.round((exactMatchesCount / (totalFields - extraCount || 1)) * 100))
    : 100;

  return {
    timestamp: new Date().toISOString().replace('T', ' ').substring(0, 19),
    testName: testName.trim() || 'Untitled Quick Test',
    endpoint: endpoint.trim() || '/api/resource',
    method,
    totalFields,
    exactMatchesCount,
    regexPassedCount,
    mismatchedCount,
    missingCount,
    extraCount,
    overallMatchScore,
    results,
  };
}
