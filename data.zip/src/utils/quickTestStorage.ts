import { SavedQuickTest } from '../types/quickTester';
import { safeJsonParse } from './jsonHelper';
import { saveToFileSystem, loadFromFileSystem } from './storage';

const QUICK_TESTS_STORAGE_KEY = 'couch_quick_saved_tests_v1';

export const SAMPLE_COUCHDB_PAYLOAD = JSON.stringify(
  {
    _id: "cust_10928",
    name: "Acme Global Solutions",
    contact: {
      email: "billing@acmeglobal.com",
      phone: "+1-800-555-0199"
    },
    tier: "ENTERPRISE",
    creditLimit: 50000,
    isActive: true,
    countryCode: "US"
  },
  null,
  2
);

export const SAMPLE_TARGET_API_PAYLOAD = JSON.stringify(
  {
    id: "cust_10928",
    name: "Acme Global Solutions",
    contact: {
      email: "billing@acmeglobal.com",
      phone: "+1-800-555-0199"
    },
    tier: "ENTERPRISE",
    creditLimit: 75000,
    isActive: true,
    countryCode: "USA"
  },
  null,
  2
);

export function loadSavedQuickTests(): SavedQuickTest[] {
  const raw = localStorage.getItem(QUICK_TESTS_STORAGE_KEY);
  return safeJsonParse<SavedQuickTest[]>(raw || '', []);
}

export async function saveQuickTest(
  test: SavedQuickTest,
  isFileMode = false
): Promise<SavedQuickTest[]> {
  const current = loadSavedQuickTests();
  const index = current.findIndex((t) => t.id === test.id);

  let updated: SavedQuickTest[];
  if (index >= 0) {
    updated = current.map((t, i) => (i === index ? test : t));
  } else {
    updated = [test, ...current];
  }

  localStorage.setItem(QUICK_TESTS_STORAGE_KEY, JSON.stringify(updated));

  if (isFileMode) {
    await saveToFileSystem('quick_tests', updated);
  }

  return updated;
}

export async function deleteQuickTest(
  id: string,
  isFileMode = false
): Promise<SavedQuickTest[]> {
  const current = loadSavedQuickTests();
  const updated = current.filter((t) => t.id !== id);

  localStorage.setItem(QUICK_TESTS_STORAGE_KEY, JSON.stringify(updated));

  if (isFileMode) {
    await saveToFileSystem('quick_tests', updated);
  }

  return updated;
}

export async function syncQuickTestsWithFileSystem(): Promise<SavedQuickTest[]> {
  const local = loadSavedQuickTests();
  const { data: fileData, exists } = await loadFromFileSystem<SavedQuickTest[]>(
    'quick_tests',
    local
  );

  if (exists && Array.isArray(fileData)) {
    localStorage.setItem(QUICK_TESTS_STORAGE_KEY, JSON.stringify(fileData));
    return fileData;
  } else if (!exists) {
    await saveToFileSystem('quick_tests', local);
  }
  return local;
}
