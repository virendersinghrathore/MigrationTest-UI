export interface DiffToken {
  text: string;
  type: 'equal' | 'removed' | 'added';
}

export interface WordDiffResult {
  isMatch: boolean;
  tokens: DiffToken[];
  matchPercentage: number;
}

/**
 * Tokenizes text into words, whitespace, and punctuation so diffs preserve formatting.
 */
function tokenizeWords(str: string): string[] {
  if (!str) return [];
  // Matches consecutive alphanumeric words, or consecutive whitespace, or individual symbols
  const matches = str.match(/[\w\d]+|[^\w\d\s]+|\s+/g);
  return matches || [str];
}

/**
 * Computes an LCS-based word-by-word diff between two strings.
 */
export function computeWordDiff(sourceStr: string, targetStr: string): WordDiffResult {
  if (sourceStr === targetStr) {
    return {
      isMatch: true,
      tokens: [{ text: sourceStr, type: 'equal' }],
      matchPercentage: 100,
    };
  }

  const sTokens = tokenizeWords(sourceStr);
  const tTokens = tokenizeWords(targetStr);

  const n = sTokens.length;
  const m = tTokens.length;

  if (n === 0 && m === 0) {
    return { isMatch: true, tokens: [], matchPercentage: 100 };
  }
  if (n === 0) {
    return {
      isMatch: false,
      tokens: tTokens.map((t) => ({ text: t, type: 'added' })),
      matchPercentage: 0,
    };
  }
  if (m === 0) {
    return {
      isMatch: false,
      tokens: sTokens.map((s) => ({ text: s, type: 'removed' })),
      matchPercentage: 0,
    };
  }

  // Build standard LCS matrix (capped size for performance)
  const maxLen = 300;
  const sSlice = sTokens.slice(0, maxLen);
  const tSlice = tTokens.slice(0, maxLen);
  const dp: number[][] = Array.from({ length: sSlice.length + 1 }, () =>
    new Array(tSlice.length + 1).fill(0)
  );

  for (let i = 0; i < sSlice.length; i++) {
    for (let j = 0; j < tSlice.length; j++) {
      if (sSlice[i] === tSlice[j]) {
        dp[i + 1][j + 1] = dp[i][j] + 1;
      } else {
        dp[i + 1][j + 1] = Math.max(dp[i + 1][j], dp[i][j + 1]);
      }
    }
  }

  // Backtrack to reconstruct tokens
  const diffTokens: DiffToken[] = [];
  let i = sSlice.length;
  let j = tSlice.length;

  while (i > 0 || j > 0) {
    if (i > 0 && j > 0 && sSlice[i - 1] === tSlice[j - 1]) {
      diffTokens.unshift({ text: sSlice[i - 1], type: 'equal' });
      i--;
      j--;
    } else if (j > 0 && (i === 0 || dp[i][j - 1] >= dp[i - 1][j])) {
      diffTokens.unshift({ text: tSlice[j - 1], type: 'added' });
      j--;
    } else if (i > 0) {
      diffTokens.unshift({ text: sSlice[i - 1], type: 'removed' });
      i--;
    }
  }

  // Append remaining tokens if truncated by maxLen
  if (sTokens.length > maxLen) {
    sTokens.slice(maxLen).forEach((t) => diffTokens.push({ text: t, type: 'removed' }));
  }
  if (tTokens.length > maxLen) {
    tTokens.slice(maxLen).forEach((t) => diffTokens.push({ text: t, type: 'added' }));
  }

  const commonCount = dp[sSlice.length][tSlice.length];
  const totalTokens = Math.max(sTokens.length, tTokens.length);
  const matchPercentage = totalTokens > 0 ? Math.round((commonCount / totalTokens) * 100) : 0;

  return {
    isMatch: false,
    tokens: diffTokens,
    matchPercentage,
  };
}

/**
 * Universal value comparison helper for primitive & object values.
 */
export function compareValuesWordByWord(
  sourceVal: any,
  targetVal: any
): {
  isMatch: boolean;
  wordDiff?: WordDiffResult;
  typeMatch: boolean;
  sourceType: string;
  targetType: string;
} {
  const sourceType = sourceVal === null ? 'NULL' : Array.isArray(sourceVal) ? 'ARRAY' : typeof sourceVal;
  const targetType = targetVal === null ? 'NULL' : Array.isArray(targetVal) ? 'ARRAY' : typeof targetVal;

  const typeMatch = sourceType === targetType;

  // Exact equality
  if (sourceVal === targetVal) {
    return {
      isMatch: true,
      typeMatch: true,
      sourceType,
      targetType,
      wordDiff: {
        isMatch: true,
        tokens: [{ text: String(sourceVal ?? ''), type: 'equal' }],
        matchPercentage: 100,
      },
    };
  }

  // Both are strings
  if (typeof sourceVal === 'string' && typeof targetVal === 'string') {
    const diff = computeWordDiff(sourceVal, targetVal);
    return {
      isMatch: diff.isMatch,
      wordDiff: diff,
      typeMatch: true,
      sourceType,
      targetType,
    };
  }

  // If numbers or booleans, check numeric / boolean equivalence
  if (typeof sourceVal === 'number' && typeof targetVal === 'number') {
    const isMatch = sourceVal === targetVal;
    return {
      isMatch,
      typeMatch: true,
      sourceType,
      targetType,
      wordDiff: computeWordDiff(String(sourceVal), String(targetVal)),
    };
  }

  // JSON representation comparison for objects/arrays
  const sStr = JSON.stringify(sourceVal);
  const tStr = JSON.stringify(targetVal);
  const isMatch = sStr === tStr;

  return {
    isMatch,
    typeMatch,
    sourceType,
    targetType,
    wordDiff: computeWordDiff(sStr || '', tStr || ''),
  };
}
