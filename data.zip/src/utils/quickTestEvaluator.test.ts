import { test } from 'node:test';
import assert from 'node:assert/strict';
import { computeWordDiff, compareValuesWordByWord } from './wordDiff';
import { evaluateQuickPayloads } from './quickTestEvaluator';
import { DEFAULT_SHARED_RULES } from './sharedRegexStorage';

test('computeWordDiff returns 100% match for identical strings', () => {
  const result = computeWordDiff('hello world', 'hello world');
  assert.equal(result.isMatch, true);
  assert.equal(result.matchPercentage, 100);
  assert.equal(result.tokens.length, 1);
  assert.equal(result.tokens[0].type, 'equal');
});

test('computeWordDiff identifies removed and added words', () => {
  const result = computeWordDiff('user@enterprise.io', 'user@newcorp.io');
  assert.equal(result.isMatch, false);
  const removed = result.tokens.find((t) => t.type === 'removed');
  const added = result.tokens.find((t) => t.type === 'added');
  assert.ok(removed, 'Should have removed token');
  assert.ok(added, 'Should have added token');
});

test('compareValuesWordByWord compares primitives and objects', () => {
  const matchNum = compareValuesWordByWord(50000, 50000);
  assert.equal(matchNum.isMatch, true);

  const diffNum = compareValuesWordByWord(50000, 75000);
  assert.equal(diffNum.isMatch, false);
  assert.equal(diffNum.typeMatch, true);

  const typeMismatch = compareValuesWordByWord(50000, '50000');
  assert.equal(typeMismatch.isMatch, false);
  assert.equal(typeMismatch.typeMatch, false);
});

test('evaluateQuickPayloads evaluates regex and word-by-word match', () => {
  const couch = {
    _id: 'cust_101',
    email: 'test@example.com',
    amount: 100,
  };
  const api = {
    _id: 'cust_101',
    email: 'test@example.com',
    amount: 200, // mismatch
  };

  const mappings = [
    {
      id: 'm1',
      couchField: '_id',
      targetField: '_id',
      enabled: true,
    },
    {
      id: 'm2',
      couchField: 'email',
      targetField: 'email',
      regexRuleKey: 'email',
      enabled: true,
    },
    {
      id: 'm3',
      couchField: 'amount',
      targetField: 'amount',
      enabled: true,
    },
  ];

  const report = evaluateQuickPayloads(
    'Sample Test',
    '/api/v1/customers/101',
    'GET',
    couch,
    api,
    mappings,
    DEFAULT_SHARED_RULES
  );

  assert.equal(report.totalFields, 3);
  assert.equal(report.exactMatchesCount, 2); // _id and email
  assert.equal(report.mismatchedCount, 1);    // amount differs
  assert.equal(report.regexPassedCount, 1);   // email regex verified

  const emailRes = report.results.find((r) => r.couchField === 'email');
  assert.equal(emailRes?.status, 'EXACT_MATCH');
  assert.equal(emailRes?.isRegexMatch, true);
  assert.equal(emailRes?.isWordMatch, true);

  const amountRes = report.results.find((r) => r.couchField === 'amount');
  assert.equal(amountRes?.status, 'VALUE_MISMATCH');
});

test('evaluateQuickPayloads detects missing fields in API response', () => {
  const couch = {
    _id: 'cust_101',
    secretToken: 'xyz123',
  };
  const api = {
    _id: 'cust_101',
  };

  const mappings = [
    { id: 'm1', couchField: '_id', targetField: '_id', enabled: true },
    { id: 'm2', couchField: 'secretToken', targetField: 'secretToken', enabled: true },
  ];

  const report = evaluateQuickPayloads(
    'Missing Field Test',
    '/api/v1/test',
    'POST',
    couch,
    api,
    mappings,
    DEFAULT_SHARED_RULES
  );

  assert.equal(report.missingCount, 1);
  const secretRes = report.results.find((r) => r.couchField === 'secretToken');
  assert.equal(secretRes?.status, 'MISSING_IN_TARGET');
});
