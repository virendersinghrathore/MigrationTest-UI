import React from 'react';
import { Zap, Layers, Sparkles } from 'lucide-react';
import { TabType, AppMode } from '../../types';

interface HeaderProps {
  activeTab: TabType;
  appMode: AppMode;
  onToggleMode: (mode: AppMode) => void;
  onRunAllTests: () => void;
}

const TAB_TITLES: Record<TabType, string> = {
  dashboard: 'Dashboard Overview',
  step1_store: 'Step 1: Stored Payloads',
  step2_rules: 'Step 2: Field Rules & Types',
  transforms: 'Validation Rules Library',
  step3_specs: 'Step 3: Endpoint Specs',
  step4_test: 'Step 4: Test & Compare',
  history: 'Run History & Results',
  elasticsearch: 'Elasticsearch Evidence Gathering',
  settings: 'Application Settings'
};

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  appMode,
  onToggleMode,
  onRunAllTests,
}) => {
  return (
    <header className="bg-white border-b border-slate-200/90 px-6 py-3.5 sticky top-0 z-30 flex flex-wrap items-center justify-between gap-3 shadow-xs backdrop-blur-md bg-white/95">
      {/* Left: View Title & Indicator */}
      <div className="flex items-center space-x-3">
        <h2 className="text-sm font-extrabold text-slate-900 tracking-tight">
          {appMode === 'quick' ? 'Quick 2-Payload Direct Migration Tester' : TAB_TITLES[activeTab]}
        </h2>
        {appMode === 'quick' && (
          <span className="hidden sm:inline-flex items-center gap-1 text-[10px] font-extrabold uppercase px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-700 border border-emerald-200">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
            Simple Mode
          </span>
        )}
      </div>

      {/* Center: The Prominent Top Toggle Button */}
      <div className="flex items-center p-1 bg-slate-100/90 border border-slate-200 rounded-2xl shadow-inner">
        <button
          type="button"
          onClick={() => onToggleMode('studio')}
          className={`flex items-center gap-2 px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
            appMode === 'studio'
              ? 'bg-white text-indigo-600 shadow-sm shadow-slate-900/5 ring-1 ring-slate-200'
              : 'text-slate-600 hover:text-slate-900 hover:bg-white/60'
          }`}
          title="Switch to full multi-step studio workflow (Steps 1 to 4)"
        >
          <Layers className="h-3.5 w-3.5 text-indigo-600" />
          <span>Studio Workflow</span>
        </button>

        <button
          type="button"
          onClick={() => onToggleMode('quick')}
          className={`flex items-center gap-2 px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer relative ${
            appMode === 'quick'
              ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30'
              : 'text-slate-600 hover:text-slate-900 hover:bg-white/60'
          }`}
          title="Switch to streamlined 2-payload direct tester with regex & word-by-word match"
        >
          <Sparkles className={`h-3.5 w-3.5 ${appMode === 'quick' ? 'text-amber-300' : 'text-indigo-600'}`} />
          <span>Quick Direct Tester</span>
          <span className={`text-[9px] font-black uppercase px-1.5 py-0.2 rounded-md ${
            appMode === 'quick' ? 'bg-indigo-700 text-indigo-100' : 'bg-emerald-100 text-emerald-800'
          }`}>
            NEW
          </span>
        </button>
      </div>

      {/* Right Action: Run All Tests (in Studio mode) or Quick Info */}
      <div className="flex items-center space-x-3">
        {appMode === 'studio' ? (
          <button
            onClick={onRunAllTests}
            className="bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold px-3.5 py-2 rounded-xl shadow-md shadow-emerald-600/20 transition-all flex items-center gap-1.5 cursor-pointer"
          >
            <Zap className="h-3.5 w-3.5 fill-current" />
            <span>Run All Tests</span>
          </button>
        ) : (
          <div className="text-[11px] text-slate-500 font-medium hidden md:block">
            Word-by-word diff &amp; shared regex validation
          </div>
        )}
      </div>
    </header>
  );
};
