import React from 'react';
import { HttpMethod } from '../../types';

export const METHOD_CONFIG: Record<
  HttpMethod,
  { label: string; badgeClass: string; activeClass: string; dotColor: string }
> = {
  GET: {
    label: 'GET',
    badgeClass: 'bg-emerald-50 text-emerald-700 border-emerald-200/80 ring-emerald-500/10',
    activeClass: 'bg-emerald-600 text-white border-emerald-600 shadow-sm shadow-emerald-600/30 ring-2 ring-emerald-600/20',
    dotColor: 'bg-emerald-500',
  },
  POST: {
    label: 'POST',
    badgeClass: 'bg-blue-50 text-blue-700 border-blue-200/80 ring-blue-500/10',
    activeClass: 'bg-blue-600 text-white border-blue-600 shadow-sm shadow-blue-600/30 ring-2 ring-blue-600/20',
    dotColor: 'bg-blue-500',
  },
  PUT: {
    label: 'PUT',
    badgeClass: 'bg-amber-50 text-amber-700 border-amber-200/80 ring-amber-500/10',
    activeClass: 'bg-amber-600 text-white border-amber-600 shadow-sm shadow-amber-600/30 ring-2 ring-amber-600/20',
    dotColor: 'bg-amber-500',
  },
  DELETE: {
    label: 'DELETE',
    badgeClass: 'bg-rose-50 text-rose-700 border-rose-200/80 ring-rose-500/10',
    activeClass: 'bg-rose-600 text-white border-rose-600 shadow-sm shadow-rose-600/30 ring-2 ring-rose-600/20',
    dotColor: 'bg-rose-500',
  },
  PATCH: {
    label: 'PATCH',
    badgeClass: 'bg-purple-50 text-purple-700 border-purple-200/80 ring-purple-500/10',
    activeClass: 'bg-purple-600 text-white border-purple-600 shadow-sm shadow-purple-600/30 ring-2 ring-purple-600/20',
    dotColor: 'bg-purple-500',
  },
};

export const ALL_HTTP_METHODS: HttpMethod[] = ['GET', 'POST', 'PUT', 'DELETE', 'PATCH'];

interface MethodBadgeProps {
  method?: string;
  size?: 'xs' | 'sm' | 'md';
  showDot?: boolean;
}

export const MethodBadge: React.FC<MethodBadgeProps> = ({
  method = 'POST',
  size = 'xs',
  showDot = false,
}) => {
  const normMethod = (method.toUpperCase() as HttpMethod) in METHOD_CONFIG
    ? (method.toUpperCase() as HttpMethod)
    : 'POST';
  const config = METHOD_CONFIG[normMethod];

  const sizeClasses = {
    xs: 'text-[10px] px-2 py-0.5 rounded-md font-bold',
    sm: 'text-xs px-2.5 py-1 rounded-lg font-bold',
    md: 'text-xs px-3 py-1.5 rounded-xl font-extrabold',
  }[size];

  return (
    <span
      className={`inline-flex items-center gap-1.5 font-mono border ${config.badgeClass} ${sizeClasses} shadow-xs tracking-wide`}
    >
      {showDot && <span className={`w-1.5 h-1.5 rounded-full ${config.dotColor}`} />}
      <span>{config.label}</span>
    </span>
  );
};

interface MethodSelectorProps {
  value: HttpMethod;
  onChange: (method: HttpMethod) => void;
  size?: 'sm' | 'md';
}

export const MethodSelector: React.FC<MethodSelectorProps> = ({
  value,
  onChange,
  size = 'sm',
}) => {
  return (
    <div className="inline-flex items-center p-1 bg-slate-100 border border-slate-200/80 rounded-xl gap-1">
      {ALL_HTTP_METHODS.map((m) => {
        const isSelected = value === m;
        const config = METHOD_CONFIG[m];
        return (
          <button
            key={m}
            type="button"
            onClick={() => onChange(m)}
            className={`font-mono font-bold transition-all cursor-pointer rounded-lg ${
              size === 'sm' ? 'text-[11px] px-2.5 py-1' : 'text-xs px-3 py-1.5'
            } ${
              isSelected
                ? config.activeClass
                : 'text-slate-600 hover:text-slate-900 hover:bg-white/80'
            }`}
          >
            {m}
          </button>
        );
      })}
    </div>
  );
};
