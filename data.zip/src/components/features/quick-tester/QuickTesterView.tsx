import React, { useState, useEffect, useMemo } from 'react';
import {
  Zap,
  Save,
  FolderOpen,
  RotateCcw,
  Sparkles,
  FileCode,
  CheckCircle2,
  AlertTriangle,
  XCircle,
  HelpCircle,
  Search,
  Filter,
  Plus,
  Play,
  Check,
  Layers,
  ArrowRight
} from 'lucide-react';
import { HttpMethod, ValidationRuleItem } from '../../../types';
import {
  FieldRegexMapping,
  QuickTestRunReport,
  SavedQuickTest,
  QuickFieldStatus
} from '../../../types/quickTester';
import { MethodSelector, MethodBadge } from '../../common/MethodBadge';
import { CreateRegexModal } from './CreateRegexModal';
import { SaveTestModal } from './SaveTestModal';
import { SavedTestsDrawer } from './SavedTestsDrawer';
import { WordDiffViewer } from './WordDiffViewer';
import {
  loadSavedQuickTests,
  saveQuickTest,
  deleteQuickTest,
  SAMPLE_COUCHDB_PAYLOAD,
  SAMPLE_TARGET_API_PAYLOAD
} from '../../../utils/quickTestStorage';
import { evaluateQuickPayloads } from '../../../utils/quickTestEvaluator';
import { flattenPayloadKeys, safeJsonParse } from '../../../utils/jsonHelper';

interface QuickTesterViewProps {
  sharedValidationRules: ValidationRuleItem[];
  onSaveSharedRegex: (rule: ValidationRuleItem) => void;
  isFileMode?: boolean;
}

export const QuickTesterView: React.FC<QuickTesterViewProps> = ({
  sharedValidationRules,
  onSaveSharedRegex,
  isFileMode = false,
}) => {
  // Test Case Metadata
  const [testName, setTestName] = useState('Customer Profile Migration Test');
  const [endpoint, setEndpoint] = useState('/api/v1/customers/10928');
  const [method, setMethod] = useState<HttpMethod>('GET');
  const [description, setDescription] = useState('');

  // 2 Payloads (starts empty as requested)
  const [couchPayloadText, setCouchPayloadText] = useState('');
  const [apiPayloadText, setApiPayloadText] = useState('');

  // Mappings & Regex Rules per field
  const [mappings, setMappings] = useState<FieldRegexMapping[]>([]);

  // Modals and Drawers
  const [isRegexModalOpen, setIsRegexModalOpen] = useState(false);
  const [activeMappingForRegex, setActiveMappingForRegex] = useState<string | null>(null);
  const [isSaveModalOpen, setIsSaveModalOpen] = useState(false);
  const [isSavedDrawerOpen, setIsSavedDrawerOpen] = useState(false);

  // Saved tests state
  const [savedTests, setSavedTests] = useState<SavedQuickTest[]>(() => loadSavedQuickTests());

  // Evaluation Report State
  const [report, setReport] = useState<QuickTestRunReport | null>(null);
  const [activeFilter, setActiveFilter] = useState<'ALL' | QuickFieldStatus>('ALL');
  const [searchQuery, setSearchQuery] = useState('');

  // JSON Syntax validation
  const couchParsed = useMemo(() => {
    if (!couchPayloadText.trim()) return null;
    try {
      const obj = JSON.parse(couchPayloadText);
      return typeof obj === 'object' && obj !== null ? obj : null;
    } catch {
      return null;
    }
  }, [couchPayloadText]);

  const apiParsed = useMemo(() => {
    if (!apiPayloadText.trim()) return null;
    try {
      const obj = JSON.parse(apiPayloadText);
      return typeof obj === 'object' && obj !== null ? obj : null;
    } catch {
      return null;
    }
  }, [apiPayloadText]);

  // Detected keys
  const couchFields = useMemo(() => {
    return couchParsed ? flattenPayloadKeys(couchParsed) : [];
  }, [couchParsed]);

  const apiFields = useMemo(() => {
    return apiParsed ? flattenPayloadKeys(apiParsed) : [];
  }, [apiParsed]);

  // Sync field mappings whenever couchFields changes
  useEffect(() => {
    if (couchFields.length === 0) {
      setMappings([]);
      return;
    }

    setMappings((prev) => {
      return couchFields.map((cf) => {
        const existing = prev.find((m) => m.couchField === cf.path);
        if (existing) return existing;

        // Auto-match target field if exact path or last segment matches
        const exactMatch = apiFields.find((af) => af.path === cf.path);
        const segmentMatch = apiFields.find((af) => {
          const cLast = cf.path.split('.').pop();
          const aLast = af.path.split('.').pop();
          return cLast === aLast;
        });

        const targetField = exactMatch?.path || segmentMatch?.path || cf.path;

        // Auto-assign regex if field name looks like email, phone, uuid, id
        let autoRegexKey: string | undefined;
        const lowerPath = cf.path.toLowerCase();
        if (lowerPath.includes('email')) autoRegexKey = 'email';
        else if (lowerPath.includes('phone')) autoRegexKey = 'phone';
        else if (lowerPath.includes('uuid')) autoRegexKey = 'uuid';
        else if (lowerPath.includes('date') || lowerPath.includes('at')) autoRegexKey = 'iso_date';

        return {
          id: `map-${cf.path}`,
          couchField: cf.path,
          targetField,
          regexRuleKey: autoRegexKey,
          enabled: true,
        };
      });
    });
  }, [couchFields, apiFields]);

  // Actions
  const handleLoadSample = () => {
    setCouchPayloadText(SAMPLE_COUCHDB_PAYLOAD);
    setApiPayloadText(SAMPLE_TARGET_API_PAYLOAD);
    setTestName('Customer Profile Sync Verification');
    setEndpoint('/api/v1/customers/10928');
    setMethod('GET');
  };

  const handleClearAll = () => {
    if (couchPayloadText || apiPayloadText) {
      if (!window.confirm('Clear both payload editors and current results?')) return;
    }
    setCouchPayloadText('');
    setApiPayloadText('');
    setMappings([]);
    setReport(null);
  };

  const handleFormatJson = (type: 'couch' | 'api') => {
    try {
      if (type === 'couch' && couchPayloadText.trim()) {
        const parsed = JSON.parse(couchPayloadText);
        setCouchPayloadText(JSON.stringify(parsed, null, 2));
      } else if (type === 'api' && apiPayloadText.trim()) {
        const parsed = JSON.parse(apiPayloadText);
        setApiPayloadText(JSON.stringify(parsed, null, 2));
      }
    } catch {
      alert(`Invalid JSON format in ${type === 'couch' ? 'CouchDB' : 'Target API'} editor.`);
    }
  };

  // Evaluate Button Handler
  const handleEvaluate = () => {
    if (!couchParsed) {
      alert('Please provide a valid CouchDB JSON payload on the left side.');
      return;
    }
    if (!apiParsed) {
      alert('Please provide a valid Target API JSON response on the right side.');
      return;
    }

    const evaluationReport = evaluateQuickPayloads(
      testName,
      endpoint,
      method,
      couchParsed,
      apiParsed,
      mappings,
      sharedValidationRules
    );

    setReport(evaluationReport);
  };

  // Custom regex created
  const handleSaveCustomRegex = (newRule: ValidationRuleItem) => {
    onSaveSharedRegex(newRule);
    if (activeMappingForRegex) {
      setMappings((prev) =>
        prev.map((m) =>
          m.id === activeMappingForRegex
            ? { ...m, regexRuleKey: newRule.key, customRegexPattern: newRule.regexPattern, customRegexName: newRule.desc }
            : m
        )
      );
      setActiveMappingForRegex(null);
    }
  };

  // Save Test Case Handler
  const handleSaveTestCase = async (meta: {
    testName: string;
    endpoint: string;
    method: HttpMethod;
    description: string;
  }) => {
    const newTest: SavedQuickTest = {
      id: `qt-${Date.now()}`,
      testName: meta.testName,
      endpoint: meta.endpoint,
      method: meta.method,
      description: meta.description,
      couchPayloadStr: couchPayloadText,
      apiPayloadStr: apiPayloadText,
      mappings,
      lastReport: report || undefined,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    const updated = await saveQuickTest(newTest, isFileMode);
    setSavedTests(updated);
    setTestName(meta.testName);
    setEndpoint(meta.endpoint);
    setMethod(meta.method);
    setDescription(meta.description);
    alert(`Quick test "${meta.testName}" saved successfully!`);
  };

  const handleLoadSavedTest = (test: SavedQuickTest) => {
    setTestName(test.testName);
    setEndpoint(test.endpoint);
    setMethod(test.method);
    setDescription(test.description || '');
    setCouchPayloadText(test.couchPayloadStr);
    setApiPayloadText(test.apiPayloadStr);
    if (test.mappings && test.mappings.length > 0) {
      setMappings(test.mappings);
    }
    if (test.lastReport) {
      setReport(test.lastReport);
    } else {
      setReport(null);
    }
  };

  const handleDeleteSavedTest = async (id: string) => {
    const updated = await deleteQuickTest(id, isFileMode);
    setSavedTests(updated);
  };

  // Filtered comparison results
  const filteredResults = useMemo(() => {
    if (!report) return [];
    return report.results.filter((r) => {
      if (activeFilter !== 'ALL' && r.status !== activeFilter) return false;
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        return (
          r.couchField.toLowerCase().includes(q) ||
          r.targetField.toLowerCase().includes(q) ||
          String(r.couchVal).toLowerCase().includes(q) ||
          String(r.targetVal).toLowerCase().includes(q)
        );
      }
      return true;
    });
  }, [report, activeFilter, searchQuery]);

  return (
    <div className="space-y-6">
      {/* Top Banner & Quick Controls */}
      <div className="bg-white border border-slate-200/90 rounded-3xl p-6 shadow-xs">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 pb-5 border-b border-slate-100">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="p-1.5 bg-gradient-to-br from-indigo-500 to-indigo-700 text-white rounded-xl shadow-xs">
                <Zap className="h-4 w-4" />
              </span>
              <h1 className="text-lg font-extrabold text-slate-900 tracking-tight">
                Quick 2-Payload Direct Migration Tester
              </h1>
              <span className="text-[10px] font-extrabold uppercase px-2 py-0.5 rounded-full bg-indigo-50 text-indigo-700 border border-indigo-200">
                Direct Field-by-Field Mode
              </span>
            </div>
            <p className="text-xs text-slate-500">
              Paste your CouchDB document and Target API response side-by-side, map fields with regex, and verify word-by-word matches instantly.
            </p>
          </div>

          <div className="flex items-center flex-wrap gap-2">
            <button
              onClick={handleLoadSample}
              className="px-3.5 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold rounded-xl transition-all flex items-center gap-1.5 cursor-pointer"
            >
              <Sparkles className="w-3.5 h-3.5 text-indigo-600" />
              <span>Load Sample Payloads</span>
            </button>

            <button
              onClick={handleClearAll}
              className="px-3 py-2 bg-slate-50 hover:bg-slate-100 text-slate-500 hover:text-slate-800 text-xs font-bold rounded-xl border border-slate-200 transition-all flex items-center gap-1.5 cursor-pointer"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Clear</span>
            </button>

            <button
              onClick={() => setIsSavedDrawerOpen(true)}
              className="px-3.5 py-2 bg-slate-100 hover:bg-indigo-50 text-slate-700 hover:text-indigo-700 text-xs font-bold rounded-xl border border-slate-200 transition-all flex items-center gap-1.5 cursor-pointer relative"
            >
              <FolderOpen className="w-3.5 h-3.5 text-indigo-600" />
              <span>Saved Tests</span>
              {savedTests.length > 0 && (
                <span className="px-1.5 py-0.2 rounded-full text-[10px] font-extrabold bg-indigo-600 text-white">
                  {savedTests.length}
                </span>
              )}
            </button>

            <button
              onClick={() => setIsSaveModalOpen(true)}
              disabled={!couchParsed && !apiParsed}
              className="px-4 py-2 bg-white hover:bg-slate-50 border border-indigo-300 text-indigo-700 disabled:opacity-50 text-xs font-bold rounded-xl shadow-xs transition-all flex items-center gap-1.5 cursor-pointer"
            >
              <Save className="w-3.5 h-3.5" />
              <span>Save Test Case</span>
            </button>

            <button
              onClick={handleEvaluate}
              disabled={!couchParsed || !apiParsed}
              className="px-5 py-2 bg-indigo-600 hover:bg-indigo-700 disabled:bg-slate-300 text-white text-xs font-bold rounded-xl shadow-md shadow-indigo-600/25 transition-all flex items-center gap-2 cursor-pointer"
            >
              <Play className="w-3.5 h-3.5 fill-current" />
              <span>Evaluate & Compare</span>
            </button>
          </div>
        </div>

        {/* Test Metadata & Method Selector */}
        <div className="grid grid-cols-1 md:grid-cols-12 gap-3 pt-4 items-center">
          <div className="md:col-span-4">
            <label className="block text-[11px] font-bold text-slate-600 mb-1">
              Test Case Name
            </label>
            <input
              type="text"
              value={testName}
              onChange={(e) => setTestName(e.target.value)}
              placeholder="e.g. Customer Migration Verification"
              className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-1.5 text-xs font-semibold text-slate-900 focus:outline-none focus:border-indigo-600"
            />
          </div>

          <div className="md:col-span-3">
            <label className="block text-[11px] font-bold text-slate-600 mb-1">
              HTTP Method
            </label>
            <MethodSelector value={method} onChange={setMethod} size="sm" />
          </div>

          <div className="md:col-span-5">
            <label className="block text-[11px] font-bold text-slate-600 mb-1">
              Target API Endpoint
            </label>
            <input
              type="text"
              value={endpoint}
              onChange={(e) => setEndpoint(e.target.value)}
              placeholder="e.g. /api/v1/customers/10928"
              className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-1.5 text-xs font-mono text-slate-900 focus:outline-none focus:border-indigo-600"
            />
          </div>
        </div>
      </div>

      {/* The 2 Payload Editors Side-by-Side (Visible Empty) */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Left Side: CouchDB Payload */}
        <div className="bg-white border border-slate-200 rounded-3xl p-5 shadow-xs flex flex-col">
          <div className="flex items-center justify-between pb-3 mb-3 border-b border-slate-100">
            <div className="flex items-center gap-2">
              <span className="p-1.5 bg-amber-50 text-amber-700 border border-amber-200 rounded-xl">
                <FileCode className="h-4 w-4" />
              </span>
              <div>
                <h3 className="text-xs font-bold text-slate-900">
                  1. CouchDB Payload (Source)
                </h3>
                <span className="text-[10px] text-slate-400">
                  {couchParsed ? `${couchFields.length} fields detected` : 'Empty — paste CouchDB JSON'}
                </span>
              </div>
            </div>

            <div className="flex items-center gap-1.5">
              {couchPayloadText.trim() && (
                <span
                  className={`text-[10px] font-bold px-2 py-0.5 rounded-md flex items-center gap-1 ${
                    couchParsed
                      ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                      : 'bg-rose-50 text-rose-700 border border-rose-200'
                  }`}
                >
                  {couchParsed ? (
                    <>
                      <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                      <span>Valid JSON</span>
                    </>
                  ) : (
                    <>
                      <AlertTriangle className="w-3 h-3 text-rose-600" />
                      <span>Invalid JSON</span>
                    </>
                  )}
                </span>
              )}

              <button
                onClick={() => handleFormatJson('couch')}
                disabled={!couchParsed}
                className="px-2.5 py-1 text-[11px] font-semibold bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg cursor-pointer transition-colors disabled:opacity-40"
              >
                Format
              </button>
              <button
                onClick={() => setCouchPayloadText('')}
                disabled={!couchPayloadText}
                className="px-2 py-1 text-[11px] font-semibold text-slate-400 hover:text-slate-700 rounded-lg cursor-pointer transition-colors"
              >
                Clear
              </button>
            </div>
          </div>

          <textarea
            rows={14}
            value={couchPayloadText}
            onChange={(e) => setCouchPayloadText(e.target.value)}
            placeholder={`// Paste your CouchDB JSON document here...\n// Example:\n{\n  "_id": "cust_10928",\n  "name": "Acme Global Solutions",\n  "contact": {\n    "email": "billing@acmeglobal.com",\n    "phone": "+1-800-555-0199"\n  },\n  "creditLimit": 50000,\n  "isActive": true\n}`}
            className="w-full flex-1 bg-slate-900 border border-slate-800 text-amber-300 font-mono text-xs p-4 rounded-2xl focus:outline-none focus:ring-2 focus:ring-amber-500/20 resize-y leading-relaxed"
          />
        </div>

        {/* Right Side: Target API JSON Response */}
        <div className="bg-white border border-slate-200 rounded-3xl p-5 shadow-xs flex flex-col">
          <div className="flex items-center justify-between pb-3 mb-3 border-b border-slate-100">
            <div className="flex items-center gap-2">
              <span className="p-1.5 bg-blue-50 text-blue-700 border border-blue-200 rounded-xl">
                <FileCode className="h-4 w-4" />
              </span>
              <div>
                <h3 className="text-xs font-bold text-slate-900">
                  2. Target API Response (JSON)
                </h3>
                <span className="text-[10px] text-slate-400">
                  {apiParsed ? `${apiFields.length} fields detected` : 'Empty — paste API JSON response'}
                </span>
              </div>
            </div>

            <div className="flex items-center gap-1.5">
              {apiPayloadText.trim() && (
                <span
                  className={`text-[10px] font-bold px-2 py-0.5 rounded-md flex items-center gap-1 ${
                    apiParsed
                      ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                      : 'bg-rose-50 text-rose-700 border border-rose-200'
                  }`}
                >
                  {apiParsed ? (
                    <>
                      <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                      <span>Valid JSON</span>
                    </>
                  ) : (
                    <>
                      <AlertTriangle className="w-3 h-3 text-rose-600" />
                      <span>Invalid JSON</span>
                    </>
                  )}
                </span>
              )}

              <button
                onClick={() => handleFormatJson('api')}
                disabled={!apiParsed}
                className="px-2.5 py-1 text-[11px] font-semibold bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg cursor-pointer transition-colors disabled:opacity-40"
              >
                Format
              </button>
              <button
                onClick={() => setApiPayloadText('')}
                disabled={!apiPayloadText}
                className="px-2 py-1 text-[11px] font-semibold text-slate-400 hover:text-slate-700 rounded-lg cursor-pointer transition-colors"
              >
                Clear
              </button>
            </div>
          </div>

          <textarea
            rows={14}
            value={apiPayloadText}
            onChange={(e) => setApiPayloadText(e.target.value)}
            placeholder={`// Paste your Target API JSON response here...\n// Example:\n{\n  "id": "cust_10928",\n  "name": "Acme Global Solutions",\n  "contact": {\n    "email": "billing@acmeglobal.com",\n    "phone": "+1-800-555-0199"\n  },\n  "creditLimit": 75000,\n  "isActive": true\n}`}
            className="w-full flex-1 bg-slate-900 border border-slate-800 text-blue-300 font-mono text-xs p-4 rounded-2xl focus:outline-none focus:ring-2 focus:ring-blue-500/20 resize-y leading-relaxed"
          />
        </div>
      </div>

      {/* Field-by-Field Regex & Target Mapping Options */}
      {couchFields.length > 0 && (
        <div className="bg-white border border-slate-200 rounded-3xl p-6 shadow-xs space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-100">
            <div>
              <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                <span>Field-by-Field Regex Mapping & Validation</span>
                <span className="text-[10px] font-extrabold px-2 py-0.5 rounded-full bg-indigo-50 text-indigo-700">
                  {mappings.length} Fields
                </span>
              </h3>
              <p className="text-[11px] text-slate-500">
                Assign shared regex patterns to any CouchDB field or create custom regexes on the fly.
              </p>
            </div>

            <button
              onClick={() => {
                setActiveMappingForRegex(null);
                setIsRegexModalOpen(true);
              }}
              className="px-3 py-1.5 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer self-start sm:self-auto"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Create Custom Regex</span>
            </button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="border-b border-slate-200 text-slate-500 font-bold text-[11px] bg-slate-50/70">
                  <th className="py-2.5 px-3">CouchDB Field</th>
                  <th className="py-2.5 px-3">Source Sample Value</th>
                  <th className="py-2.5 px-3">Target Field (API)</th>
                  <th className="py-2.5 px-3">Regex Validation Rule</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {mappings.map((m) => {
                  const couchVal = couchFields.find((f) => f.path === m.couchField)?.val;
                  const currentRule = sharedValidationRules.find((r) => r.key === m.regexRuleKey);

                  return (
                    <tr key={m.id} className="hover:bg-slate-50/50 transition-colors">
                      <td className="py-2.5 px-3 font-mono font-bold text-slate-900">
                        {m.couchField}
                      </td>

                      <td className="py-2.5 px-3 font-mono text-slate-600 max-w-[180px] truncate">
                        {couchVal === null
                          ? 'null'
                          : typeof couchVal === 'object'
                          ? JSON.stringify(couchVal)
                          : String(couchVal)}
                      </td>

                      <td className="py-2.5 px-3">
                        <div className="flex items-center gap-1">
                          <input
                            type="text"
                            value={m.targetField}
                            onChange={(e) => {
                              const val = e.target.value;
                              setMappings((prev) =>
                                prev.map((x) => (x.id === m.id ? { ...x, targetField: val } : x))
                              );
                            }}
                            placeholder="Target field path..."
                            className="bg-slate-50 border border-slate-200 rounded-lg px-2.5 py-1 text-xs font-mono text-slate-800 w-44 focus:outline-none focus:border-indigo-500"
                          />
                        </div>
                      </td>

                      <td className="py-2.5 px-3">
                        <div className="flex items-center gap-1.5">
                          <select
                            value={m.regexRuleKey || ''}
                            onChange={(e) => {
                              const val = e.target.value;
                              if (val === '__CREATE_NEW__') {
                                setActiveMappingForRegex(m.id);
                                setIsRegexModalOpen(true);
                              } else {
                                const found = sharedValidationRules.find((r) => r.key === val);
                                setMappings((prev) =>
                                  prev.map((x) =>
                                    x.id === m.id
                                      ? {
                                          ...x,
                                          regexRuleKey: val || undefined,
                                          customRegexPattern: found?.regexPattern,
                                          customRegexName: found?.desc,
                                        }
                                      : x
                                  )
                                );
                              }
                            }}
                            className="bg-slate-50 border border-slate-200 rounded-lg px-2.5 py-1 text-xs text-slate-800 focus:outline-none focus:border-indigo-500 cursor-pointer max-w-[200px]"
                          >
                            <option value="">None (Direct Value Check)</option>
                            <optgroup label="Shared Regex Rules">
                              {sharedValidationRules.map((r) => (
                                <option key={r.id} value={r.key}>
                                  {r.desc || r.key} {r.regexPattern ? `(/${r.regexPattern}/)` : ''}
                                </option>
                              ))}
                            </optgroup>
                            <option value="__CREATE_NEW__">+ Create New Regex...</option>
                          </select>

                          {m.regexRuleKey && currentRule?.regexPattern && (
                            <span
                              className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-emerald-50 text-emerald-700 border border-emerald-200 truncate max-w-[150px]"
                              title={`Pattern: ${currentRule.regexPattern}`}
                            >
                              /{currentRule.regexPattern}/
                            </span>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Evaluation Results Banner & Detailed Word-by-Word Breakdown */}
      {report && (
        <div className="bg-white border border-slate-200 rounded-3xl p-6 shadow-xs space-y-6 animate-fadeIn">
          {/* Executive Scoreboard */}
          <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6 pb-6 border-b border-slate-100">
            <div>
              <div className="flex items-center gap-2 mb-1">
                <MethodBadge method={report.method} size="sm" />
                <h3 className="text-base font-extrabold text-slate-900">{report.testName}</h3>
              </div>
              <p className="text-xs font-mono text-slate-500">{report.endpoint}</p>
            </div>

            <div className="flex items-center flex-wrap gap-3">
              <div className="px-4 py-2.5 rounded-2xl bg-slate-50 border border-slate-200/80 text-center">
                <span className="text-[10px] font-bold text-slate-400 block uppercase">Match Score</span>
                <span
                  className={`text-xl font-black ${
                    report.overallMatchScore >= 90
                      ? 'text-emerald-600'
                      : report.overallMatchScore >= 70
                      ? 'text-amber-600'
                      : 'text-rose-600'
                  }`}
                >
                  {report.overallMatchScore}%
                </span>
              </div>

              <div className="px-3.5 py-2.5 rounded-2xl bg-emerald-50 border border-emerald-200 text-center">
                <span className="text-[10px] font-bold text-emerald-600 block uppercase">Exact Matches</span>
                <span className="text-lg font-black text-emerald-700">{report.exactMatchesCount}</span>
              </div>

              {report.regexPassedCount > 0 && (
                <div className="px-3.5 py-2.5 rounded-2xl bg-indigo-50 border border-indigo-200 text-center">
                  <span className="text-[10px] font-bold text-indigo-600 block uppercase">Regex Passes</span>
                  <span className="text-lg font-black text-indigo-700">{report.regexPassedCount}</span>
                </div>
              )}

              <div className="px-3.5 py-2.5 rounded-2xl bg-rose-50 border border-rose-200 text-center">
                <span className="text-[10px] font-bold text-rose-600 block uppercase">Mismatches</span>
                <span className="text-lg font-black text-rose-700">{report.mismatchedCount}</span>
              </div>

              {report.missingCount > 0 && (
                <div className="px-3.5 py-2.5 rounded-2xl bg-amber-50 border border-amber-200 text-center">
                  <span className="text-[10px] font-bold text-amber-600 block uppercase">Missing in API</span>
                  <span className="text-lg font-black text-amber-700">{report.missingCount}</span>
                </div>
              )}
            </div>
          </div>

          {/* Filter Bar & Search */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div className="flex items-center flex-wrap gap-1.5">
              {[
                { id: 'ALL', label: `All Fields (${report.totalFields})` },
                { id: 'EXACT_MATCH', label: `Matches (${report.exactMatchesCount})` },
                { id: 'VALUE_MISMATCH', label: `Mismatches (${report.mismatchedCount})` },
                { id: 'REGEX_FAILED', label: `Regex Fails` },
                { id: 'MISSING_IN_TARGET', label: `Missing (${report.missingCount})` },
              ].map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setActiveFilter(tab.id as any)}
                  className={`text-xs font-bold px-3 py-1.5 rounded-xl transition-all cursor-pointer ${
                    activeFilter === tab.id
                      ? 'bg-slate-900 text-white shadow-xs'
                      : 'bg-slate-100 hover:bg-slate-200 text-slate-600'
                  }`}
                >
                  {tab.label}
                </button>
              ))}
            </div>

            <div className="relative w-full sm:w-60">
              <Search className="w-3.5 h-3.5 absolute left-3 top-2.5 text-slate-400" />
              <input
                type="text"
                placeholder="Filter by field name..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full text-xs pl-8 pr-3 py-1.5 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:border-indigo-500"
              />
            </div>
          </div>

          {/* Field Comparison Cards */}
          <div className="space-y-3">
            {filteredResults.length === 0 ? (
              <div className="p-8 text-center border border-dashed border-slate-200 rounded-2xl text-slate-400 text-xs">
                No fields match the selected filter.
              </div>
            ) : (
              filteredResults.map((item) => {
                const isExact = item.status === 'EXACT_MATCH';
                const isMismatch = item.status === 'VALUE_MISMATCH';
                const isRegexFail = item.status === 'REGEX_FAILED';
                const isMissing = item.status === 'MISSING_IN_TARGET';

                return (
                  <div
                    key={item.id}
                    className={`p-4 rounded-2xl border transition-all ${
                      isExact
                        ? 'border-emerald-200/80 bg-emerald-50/20'
                        : isMismatch
                        ? 'border-rose-200 bg-rose-50/20'
                        : isRegexFail
                        ? 'border-rose-300 bg-rose-50/30'
                        : isMissing
                        ? 'border-amber-200 bg-amber-50/20'
                        : 'border-slate-200 bg-white'
                    }`}
                  >
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 mb-3 border-b border-slate-100">
                      <div className="flex items-center gap-2">
                        <span className="font-mono text-xs font-extrabold text-slate-900">
                          {item.couchField}
                        </span>
                        {item.targetField !== item.couchField && (
                          <span className="flex items-center gap-1 text-[11px] font-mono text-indigo-600 bg-indigo-50 px-2 py-0.5 rounded-md">
                            <span>➔</span>
                            <span>{item.targetField}</span>
                          </span>
                        )}
                      </div>

                      <div className="flex items-center gap-2">
                        {item.regexPattern && (
                          <span
                            className={`text-[10px] font-mono font-bold px-2 py-0.5 rounded-md border ${
                              item.isRegexMatch
                                ? 'bg-emerald-50 text-emerald-700 border-emerald-200'
                                : 'bg-rose-50 text-rose-700 border-rose-200'
                            }`}
                          >
                            Regex: {item.isRegexMatch ? 'PASSED' : 'FAILED'} (/{item.regexPattern}/)
                          </span>
                        )}

                        <span
                          className={`text-xs font-extrabold px-2.5 py-0.5 rounded-lg border flex items-center gap-1 ${
                            isExact
                              ? 'bg-emerald-100 text-emerald-800 border-emerald-300'
                              : isMismatch
                              ? 'bg-rose-100 text-rose-800 border-rose-300'
                              : isRegexFail
                              ? 'bg-rose-100 text-rose-800 border-rose-300'
                              : isMissing
                              ? 'bg-amber-100 text-amber-800 border-amber-300'
                              : 'bg-slate-100 text-slate-800 border-slate-300'
                          }`}
                        >
                          {isExact ? (
                            <>
                              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                              <span>Word-by-Word Match</span>
                            </>
                          ) : (
                            <>
                              <AlertTriangle className="w-3.5 h-3.5 text-rose-600" />
                              <span>{item.statusMessage}</span>
                            </>
                          )}
                        </span>
                      </div>
                    </div>

                    {/* Word-by-Word Diff View */}
                    <WordDiffViewer
                      tokens={item.wordDiffTokens}
                      sourceVal={item.couchVal}
                      targetVal={item.targetVal}
                      sourceType={item.couchType}
                      targetType={item.targetType}
                    />
                  </div>
                );
              })
            )}
          </div>
        </div>
      )}

      {/* Modals & Drawers */}
      <CreateRegexModal
        isOpen={isRegexModalOpen}
        onClose={() => {
          setIsRegexModalOpen(false);
          setActiveMappingForRegex(null);
        }}
        onSave={handleSaveCustomRegex}
      />

      <SaveTestModal
        isOpen={isSaveModalOpen}
        onClose={() => setIsSaveModalOpen(false)}
        onSave={handleSaveTestCase}
        initialName={testName}
        initialEndpoint={endpoint}
        initialMethod={method}
        initialDesc={description}
      />

      <SavedTestsDrawer
        isOpen={isSavedDrawerOpen}
        onClose={() => setIsSavedDrawerOpen(false)}
        savedTests={savedTests}
        onLoadTest={handleLoadSavedTest}
        onDeleteTest={handleDeleteSavedTest}
      />
    </div>
  );
};
