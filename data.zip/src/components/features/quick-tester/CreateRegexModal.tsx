import React, { useState } from 'react';
import { X, Check, AlertCircle, Sparkles } from 'lucide-react';
import { ValidationRuleItem } from '../../../types';
import { testValueAgainstRegex } from '../../../utils/sharedRegexStorage';

interface CreateRegexModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (rule: ValidationRuleItem) => void;
  initialPattern?: string;
}

export const CreateRegexModal: React.FC<CreateRegexModalProps> = ({
  isOpen,
  onClose,
  onSave,
  initialPattern = '',
}) => {
  const [key, setKey] = useState('');
  const [desc, setDesc] = useState('');
  const [pattern, setPattern] = useState(initialPattern);
  const [testSample, setTestSample] = useState('');

  if (!isOpen) return null;

  const testResult = testValueAgainstRegex(pattern, testSample);
  const isPatternValid = (() => {
    try {
      new RegExp(pattern);
      return true;
    } catch {
      return false;
    }
  })();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!key.trim() || !pattern.trim() || !isPatternValid) return;

    const newRule: ValidationRuleItem = {
      id: `vr-custom-${Date.now()}`,
      key: key.trim().toLowerCase().replace(/[^a-z0-9_-]/g, '_'),
      desc: desc.trim() || `Regex validation rule for ${key}`,
      regexPattern: pattern.trim(),
      isBuiltIn: false,
    };

    onSave(newRule);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4 animate-fadeIn">
      <div className="bg-white border border-slate-200 rounded-3xl w-full max-w-lg p-6 shadow-2xl relative">
        <div className="flex items-center justify-between pb-4 border-b border-slate-100">
          <div className="flex items-center gap-2">
            <div className="p-2 bg-indigo-50 text-indigo-600 rounded-xl">
              <Sparkles className="h-5 w-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900">Create Custom Regex Rule</h3>
              <p className="text-[11px] text-slate-500">
                Saved rules are automatically shared across all profiles.
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-slate-700 p-1 rounded-lg hover:bg-slate-100 transition-colors cursor-pointer"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4 pt-4">
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1.5">
              Rule Name / Key <span className="text-rose-500">*</span>
            </label>
            <input
              type="text"
              required
              value={key}
              onChange={(e) => setKey(e.target.value)}
              placeholder="e.g. phone_number or tax_id"
              className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3.5 py-2 text-xs font-mono text-slate-900 focus:outline-none focus:border-indigo-600 focus:ring-2 focus:ring-indigo-600/10"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1.5">
              Description
            </label>
            <input
              type="text"
              value={desc}
              onChange={(e) => setDesc(e.target.value)}
              placeholder="e.g. Validates 10-digit US phone numbers"
              className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3.5 py-2 text-xs text-slate-900 focus:outline-none focus:border-indigo-600 focus:ring-2 focus:ring-indigo-600/10"
            />
          </div>

          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label className="text-xs font-bold text-slate-700">
                Regex Pattern <span className="text-rose-500">*</span>
              </label>
              {!isPatternValid && pattern && (
                <span className="text-[11px] text-rose-600 flex items-center gap-1">
                  <AlertCircle className="w-3 h-3" /> Invalid Regex
                </span>
              )}
            </div>
            <div className="relative">
              <span className="absolute left-3 top-2.5 text-slate-400 font-mono text-xs">/</span>
              <input
                type="text"
                required
                value={pattern}
                onChange={(e) => setPattern(e.target.value)}
                placeholder="^[a-zA-Z0-9_-]+$"
                className="w-full bg-slate-900 border border-slate-800 text-emerald-400 font-mono text-xs pl-6 pr-6 py-2.5 rounded-xl focus:outline-none focus:border-indigo-500"
              />
              <span className="absolute right-3 top-2.5 text-slate-400 font-mono text-xs">/</span>
            </div>
          </div>

          {/* Live Regex Tester */}
          <div className="p-3 bg-slate-50 border border-slate-200 rounded-2xl space-y-2">
            <span className="text-[11px] font-bold text-slate-600 uppercase tracking-wider block">
              Live Pattern Tester
            </span>
            <input
              type="text"
              value={testSample}
              onChange={(e) => setTestSample(e.target.value)}
              placeholder="Type test sample value here to verify..."
              className="w-full bg-white border border-slate-200 rounded-lg px-3 py-1.5 text-xs text-slate-800 focus:outline-none focus:border-indigo-500"
            />
            {testSample && (
              <div
                className={`text-xs px-2.5 py-1 rounded-lg flex items-center gap-1.5 font-mono ${
                  testResult.valid
                    ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                    : 'bg-rose-50 text-rose-700 border border-rose-200'
                }`}
              >
                {testResult.valid ? (
                  <>
                    <Check className="w-3.5 h-3.5 text-emerald-600" />
                    <span>Matches regex pattern!</span>
                  </>
                ) : (
                  <>
                    <AlertCircle className="w-3.5 h-3.5 text-rose-600" />
                    <span>{testResult.error || 'Pattern did not match sample'}</span>
                  </>
                )}
              </div>
            )}
          </div>

          <div className="flex justify-end gap-2 pt-3 border-t border-slate-100">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-bold text-slate-600 hover:bg-slate-100 rounded-xl cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={!key.trim() || !pattern.trim() || !isPatternValid}
              className="px-5 py-2 bg-indigo-600 hover:bg-indigo-700 disabled:bg-slate-300 text-white text-xs font-bold rounded-xl shadow-md cursor-pointer transition-all flex items-center gap-1.5"
            >
              <Check className="w-4 h-4" />
              <span>Save & Use Regex</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
