import React from 'react';
import { X, Trash2, ArrowRight, Download, Clock, FolderOpen } from 'lucide-react';
import { SavedQuickTest } from '../../../types/quickTester';
import { MethodBadge } from '../../common/MethodBadge';
import { exportToJsonFile } from '../../../utils/jsonHelper';

interface SavedTestsDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  savedTests: SavedQuickTest[];
  onLoadTest: (test: SavedQuickTest) => void;
  onDeleteTest: (id: string) => void;
}

export const SavedTestsDrawer: React.FC<SavedTestsDrawerProps> = ({
  isOpen,
  onClose,
  savedTests,
  onLoadTest,
  onDeleteTest,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex justify-end bg-slate-900/40 backdrop-blur-xs animate-fadeIn">
      <div className="w-full max-w-md bg-white h-full shadow-2xl flex flex-col border-l border-slate-200">
        <div className="p-5 border-b border-slate-200 flex items-center justify-between bg-slate-50">
          <div className="flex items-center gap-2">
            <FolderOpen className="w-5 h-5 text-indigo-600" />
            <div>
              <h3 className="text-sm font-bold text-slate-900">Saved Quick Tests</h3>
              <p className="text-[11px] text-slate-500">
                {savedTests.length} comparison{savedTests.length === 1 ? '' : 's'} stored
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-700 rounded-lg hover:bg-slate-200/60 cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto p-4 space-y-3">
          {savedTests.length === 0 ? (
            <div className="p-8 text-center border border-dashed border-slate-200 rounded-2xl">
              <FolderOpen className="w-8 h-8 text-slate-300 mx-auto mb-2" />
              <p className="text-xs font-bold text-slate-600">No Saved Quick Tests Yet</p>
              <p className="text-[11px] text-slate-400 mt-1">
                Paste your CouchDB and API payloads, run an evaluation, and click "Save Test Case".
              </p>
            </div>
          ) : (
            savedTests.map((t) => {
              const score = t.lastReport?.overallMatchScore ?? 100;
              const isHigh = score >= 90;
              const isMed = score >= 70 && score < 90;

              return (
                <div
                  key={t.id}
                  className="p-4 bg-white border border-slate-200 hover:border-indigo-300 rounded-2xl shadow-xs hover:shadow-sm transition-all group"
                >
                  <div className="flex items-start justify-between gap-2">
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <MethodBadge method={t.method} size="xs" />
                        <h4 className="text-xs font-bold text-slate-900 truncate max-w-[200px]">
                          {t.testName}
                        </h4>
                      </div>
                      <p className="text-[11px] font-mono text-slate-500 truncate max-w-[260px]">
                        {t.endpoint}
                      </p>
                    </div>

                    <div
                      className={`text-xs font-extrabold px-2 py-0.5 rounded-lg border ${
                        isHigh
                          ? 'bg-emerald-50 text-emerald-700 border-emerald-200'
                          : isMed
                          ? 'bg-amber-50 text-amber-700 border-amber-200'
                          : 'bg-rose-50 text-rose-700 border-rose-200'
                      }`}
                    >
                      {score}%
                    </div>
                  </div>

                  {t.description && (
                    <p className="text-[11px] text-slate-500 mt-2 line-clamp-2">
                      {t.description}
                    </p>
                  )}

                  <div className="mt-3 pt-3 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-400">
                    <span className="flex items-center gap-1">
                      <Clock className="w-3 h-3" />
                      {t.createdAt?.slice(0, 10)}
                    </span>

                    <div className="flex items-center gap-1.5">
                      <button
                        onClick={() => exportToJsonFile(`quick_test_${t.id}.json`, t)}
                        className="p-1 text-slate-400 hover:text-slate-700 rounded hover:bg-slate-100 cursor-pointer"
                        title="Export Test as JSON"
                      >
                        <Download className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => {
                          if (window.confirm(`Delete saved test "${t.testName}"?`)) {
                            onDeleteTest(t.id);
                          }
                        }}
                        className="p-1 text-slate-400 hover:text-rose-600 rounded hover:bg-rose-50 cursor-pointer"
                        title="Delete Saved Test"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => {
                          onLoadTest(t);
                          onClose();
                        }}
                        className="px-2.5 py-1 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 rounded-lg font-bold flex items-center gap-1 cursor-pointer transition-colors"
                      >
                        <span>Load</span>
                        <ArrowRight className="w-3 h-3" />
                      </button>
                    </div>
                  </div>
                </div>
              );
            })
          )}
        </div>
      </div>
    </div>
  );
};
