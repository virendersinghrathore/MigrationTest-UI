import React from 'react';
import { DiffToken } from '../../../utils/wordDiff';

interface WordDiffViewerProps {
  tokens?: DiffToken[];
  sourceVal: any;
  targetVal: any;
  sourceType: string;
  targetType: string;
}

export const WordDiffViewer: React.FC<WordDiffViewerProps> = ({
  tokens,
  sourceVal,
  targetVal,
  sourceType,
  targetType,
}) => {
  const formatValue = (v: any): string => {
    if (v === undefined) return '(undefined)';
    if (v === null) return 'null';
    if (typeof v === 'object') return JSON.stringify(v);
    return String(v);
  };

  const isStringComparison = typeof sourceVal === 'string' && typeof targetVal === 'string';

  return (
    <div className="space-y-2 text-xs">
      {/* Side-by-Side values comparison */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-2 text-[11px] font-mono">
        <div className="bg-slate-50 border border-slate-200 rounded-lg p-2.5">
          <div className="flex items-center justify-between text-slate-400 text-[10px] uppercase font-bold mb-1">
            <span>CouchDB (Source)</span>
            <span className="px-1.5 py-0.2 rounded bg-slate-200/80 text-slate-700">{sourceType}</span>
          </div>
          <div className="text-slate-900 break-all select-all font-mono">
            {formatValue(sourceVal)}
          </div>
        </div>

        <div className="bg-slate-50 border border-slate-200 rounded-lg p-2.5">
          <div className="flex items-center justify-between text-slate-400 text-[10px] uppercase font-bold mb-1">
            <span>Target API Response</span>
            <span className="px-1.5 py-0.2 rounded bg-slate-200/80 text-slate-700">{targetType}</span>
          </div>
          <div className="text-slate-900 break-all select-all font-mono">
            {formatValue(targetVal)}
          </div>
        </div>
      </div>

      {/* Word-by-word diff line (if tokens exist and strings differ) */}
      {tokens && tokens.length > 0 && isStringComparison && (
        <div className="p-2.5 bg-slate-900 rounded-lg border border-slate-800 text-[11px] font-mono leading-relaxed">
          <span className="text-slate-400 text-[10px] block mb-1 font-sans font-bold">
            Word-by-Word Diff:
          </span>
          <div className="flex flex-wrap gap-x-0.5 gap-y-1">
            {tokens.map((token, idx) => {
              if (token.type === 'equal') {
                return (
                  <span key={idx} className="text-slate-200">
                    {token.text}
                  </span>
                );
              }
              if (token.type === 'removed') {
                return (
                  <span
                    key={idx}
                    className="bg-rose-950/80 text-rose-300 border border-rose-800/80 px-1 py-0.2 rounded line-through mx-0.5"
                    title="Removed from source"
                  >
                    {token.text}
                  </span>
                );
              }
              if (token.type === 'added') {
                return (
                  <span
                    key={idx}
                    className="bg-emerald-950/80 text-emerald-300 border border-emerald-800/80 px-1 py-0.2 rounded font-bold mx-0.5"
                    title="Added in API response"
                  >
                    {token.text}
                  </span>
                );
              }
              return null;
            })}
          </div>
        </div>
      )}
    </div>
  );
};
