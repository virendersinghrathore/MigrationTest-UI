import React, { useState, useEffect } from 'react';
import { X, Save, Check } from 'lucide-react';
import { HttpMethod } from '../../../types';
import { MethodSelector } from '../../common/MethodBadge';

interface SaveTestModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (data: { testName: string; endpoint: string; method: HttpMethod; description: string }) => void;
  initialName: string;
  initialEndpoint: string;
  initialMethod: HttpMethod;
  initialDesc?: string;
}

export const SaveTestModal: React.FC<SaveTestModalProps> = ({
  isOpen,
  onClose,
  onSave,
  initialName,
  initialEndpoint,
  initialMethod,
  initialDesc = '',
}) => {
  const [name, setName] = useState(initialName);
  const [endpoint, setEndpoint] = useState(initialEndpoint);
  const [method, setMethod] = useState<HttpMethod>(initialMethod);
  const [desc, setDesc] = useState(initialDesc);

  useEffect(() => {
    if (isOpen) {
      setName(initialName || 'Quick Migration Comparison');
      setEndpoint(initialEndpoint || '/api/v1/resource');
      setMethod(initialMethod || 'GET');
      setDesc(initialDesc || '');
    }
  }, [isOpen, initialName, initialEndpoint, initialMethod, initialDesc]);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;
    onSave({
      testName: name.trim(),
      endpoint: endpoint.trim() || '/api/v1/resource',
      method,
      description: desc.trim(),
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4 animate-fadeIn">
      <div className="bg-white border border-slate-200 rounded-3xl w-full max-w-md p-6 shadow-2xl">
        <div className="flex items-center justify-between pb-4 border-b border-slate-100">
          <div className="flex items-center gap-2">
            <div className="p-2 bg-indigo-50 text-indigo-600 rounded-xl">
              <Save className="h-5 w-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900">Save Quick Test Case</h3>
              <p className="text-[11px] text-slate-500">
                Stores payloads, mappings, regex rules, and evaluation results.
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-slate-700 p-1 rounded-lg hover:bg-slate-100 cursor-pointer"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4 pt-4">
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1.5">
              Test Case Name <span className="text-rose-500">*</span>
            </label>
            <input
              type="text"
              required
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g. Customer Profile API Sync"
              className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3.5 py-2 text-xs text-slate-900 focus:outline-none focus:border-indigo-600"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1.5">
              HTTP Method
            </label>
            <MethodSelector value={method} onChange={setMethod} size="sm" />
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1.5">
              Target API Endpoint
            </label>
            <input
              type="text"
              value={endpoint}
              onChange={(e) => setEndpoint(e.target.value)}
              placeholder="e.g. /api/v1/customers/10928"
              className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3.5 py-2 text-xs font-mono text-slate-900 focus:outline-none focus:border-indigo-600"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1.5">
              Description / Notes (Optional)
            </label>
            <textarea
              rows={2}
              value={desc}
              onChange={(e) => setDesc(e.target.value)}
              placeholder="e.g. Verified customer credit limit migration logic"
              className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3.5 py-2 text-xs text-slate-900 focus:outline-none focus:border-indigo-600"
            />
          </div>

          <div className="flex justify-end gap-2 pt-3 border-t border-slate-100">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-bold text-slate-600 hover:bg-slate-100 rounded-xl cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={!name.trim()}
              className="px-5 py-2 bg-indigo-600 hover:bg-indigo-700 disabled:bg-slate-300 text-white text-xs font-bold rounded-xl shadow-md cursor-pointer transition-all flex items-center gap-1.5"
            >
              <Check className="w-4 h-4" />
              <span>Save Comparison</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
