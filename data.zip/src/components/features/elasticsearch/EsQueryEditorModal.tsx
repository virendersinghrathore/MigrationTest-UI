import React, { useState, useEffect } from 'react';
import { X, Check, FileCode, AlertCircle, Sparkles } from 'lucide-react';
import { EsQueryItem } from '../../../types/elasticsearch';

interface EsQueryEditorModalProps {
  isOpen: boolean;
  onClose: () => void;
  editingQuery: EsQueryItem | null;
  onSaveQuery: (query: EsQueryItem) => void;
  defaultIndex?: string;
}

export const EsQueryEditorModal: React.FC<EsQueryEditorModalProps> = ({
  isOpen,
  onClose,
  editingQuery,
  onSaveQuery,
  defaultIndex = 'customers-*',
}) => {
  const [title, setTitle] = useState('');
  const [index, setIndex] = useState(defaultIndex);
  const [method, setMethod] = useState<'GET' | 'POST'>('POST');
  const [endpointPath, setEndpointPath] = useState('/_search');
  const [queryBody, setQueryBody] = useState('{\n  "query": {\n    "match_all": {}\n  },\n  "size": 10\n}');
  const [notes, setNotes] = useState('');
  const [linkedTestCase, setLinkedTestCase] = useState('');

  useEffect(() => {
    if (editingQuery) {
      setTitle(editingQuery.title);
      setIndex(editingQuery.index);
      setMethod(editingQuery.method || 'POST');
      setEndpointPath(editingQuery.endpointPath || `/${editingQuery.index}/_search`);
      setQueryBody(editingQuery.queryBody);
      setNotes(editingQuery.notes || '');
      setLinkedTestCase(editingQuery.linkedTestCase || '');
    } else {
      setTitle('Verify Migrated Document in ES');
      setIndex(defaultIndex || 'customers-*');
      setMethod('POST');
      setEndpointPath('/_search');
      setQueryBody(
        JSON.stringify(
          {
            query: {
              term: {
                "_id": "cust_99281"
              }
            },
            size: 5
          },
          null,
          2
        )
      );
      setNotes('Check document fields migrated from CouchDB');
      setLinkedTestCase('cust_99281');
    }
  }, [editingQuery, defaultIndex, isOpen]);

  if (!isOpen) return null;

  const isJsonValid = (() => {
    try {
      JSON.parse(queryBody);
      return true;
    } catch {
      return false;
    }
  })();

  const handleApplyTemplate = (type: 'byId' | 'audit' | 'errors' | 'matchAll') => {
    if (type === 'byId') {
      setTitle('Verify Document by ID in Elasticsearch');
      setQueryBody(
        JSON.stringify(
          {
            query: {
              term: {
                "_id": linkedTestCase || "cust_99281"
              }
            },
            size: 5
          },
          null,
          2
        )
      );
    } else if (type === 'audit') {
      setTitle('Query Migration Audit Events');
      setIndex('migration-audit-*');
      setQueryBody(
        JSON.stringify(
          {
            query: {
              bool: {
                must: [
                  { term: { "action.keyword": "MIGRATION_SYNC" } },
                  { term: { "status.keyword": "SUCCESS" } }
                ]
              }
            },
            sort: [{ "timestamp": "desc" }],
            size: 10
          },
          null,
          2
        )
      );
    } else if (type === 'errors') {
      setTitle('Query Migration Error Logs');
      setIndex('migration-logs-*');
      setQueryBody(
        JSON.stringify(
          {
            query: {
              bool: {
                filter: [{ term: { "level.keyword": "ERROR" } }]
              }
            },
            sort: [{ "timestamp": "desc" }],
            size: 10
          },
          null,
          2
        )
      );
    } else if (type === 'matchAll') {
      setTitle('Sample Document Records (Match All)');
      setQueryBody(
        JSON.stringify(
          {
            query: { match_all: {} },
            size: 10
          },
          null,
          2
        )
      );
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !isJsonValid) return;

    const queryItem: EsQueryItem = {
      id: editingQuery?.id || `es-q-${Date.now()}`,
      title: title.trim(),
      index: index.trim() || defaultIndex,
      method,
      endpointPath: endpointPath.trim() || `/${index.trim()}/_search`,
      queryBody,
      enabled: editingQuery ? editingQuery.enabled : true,
      notes: notes.trim(),
      linkedTestCase: linkedTestCase.trim(),
    };

    onSaveQuery(queryItem);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4 animate-fadeIn">
      <div className="bg-white border border-slate-200 rounded-3xl w-full max-w-2xl p-7 shadow-2xl relative">
        <div className="flex items-center justify-between pb-4 border-b border-slate-100">
          <div className="flex items-center gap-2.5">
            <div className="p-2.5 bg-indigo-50 text-indigo-600 rounded-2xl">
              <FileCode className="h-5 w-5" />
            </div>
            <div>
              <h3 className="text-base font-extrabold text-slate-900">
                {editingQuery ? 'Edit Elasticsearch Query' : 'Configure Elasticsearch Query'}
              </h3>
              <p className="text-[11px] text-slate-500">
                Define the index, endpoint, and JSON query DSL to capture test case evidence.
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-slate-700 p-1.5 rounded-lg hover:bg-slate-100 transition-colors cursor-pointer"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4 pt-4">
          <div className="grid grid-cols-1 md:grid-cols-12 gap-3">
            <div className="md:col-span-8">
              <label className="block text-xs font-bold text-slate-700 mb-1.5">
                Query Name / Evidence Purpose <span className="text-rose-500">*</span>
              </label>
              <input
                type="text"
                required
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="e.g. Verify Customer Document Created in ES"
                className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3.5 py-2 text-xs text-slate-900 focus:outline-none focus:border-indigo-600"
              />
            </div>

            <div className="md:col-span-4">
              <label className="block text-xs font-bold text-slate-700 mb-1.5">
                Target Index Pattern <span className="text-rose-500">*</span>
              </label>
              <input
                type="text"
                required
                value={index}
                onChange={(e) => setIndex(e.target.value)}
                placeholder="e.g. customers-*, audit-*"
                className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3.5 py-2 text-xs font-mono text-slate-900 focus:outline-none focus:border-indigo-600"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-12 gap-3">
            <div className="md:col-span-3">
              <label className="block text-xs font-bold text-slate-700 mb-1.5">HTTP Method</label>
              <select
                value={method}
                onChange={(e) => setMethod(e.target.value as any)}
                className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs font-mono font-bold text-slate-900 focus:outline-none focus:border-indigo-600 cursor-pointer"
              >
                <option value="POST">POST</option>
                <option value="GET">GET</option>
              </select>
            </div>

            <div className="md:col-span-5">
              <label className="block text-xs font-bold text-slate-700 mb-1.5">Endpoint Path</label>
              <input
                type="text"
                value={endpointPath}
                onChange={(e) => setEndpointPath(e.target.value)}
                placeholder="/_search or /_count"
                className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3.5 py-2 text-xs font-mono text-slate-900 focus:outline-none focus:border-indigo-600"
              />
            </div>

            <div className="md:col-span-4">
              <label className="block text-xs font-bold text-slate-700 mb-1.5">Linked Test Doc ID</label>
              <input
                type="text"
                value={linkedTestCase}
                onChange={(e) => setLinkedTestCase(e.target.value)}
                placeholder="e.g. cust_99281"
                className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3.5 py-2 text-xs font-mono text-slate-900 focus:outline-none focus:border-indigo-600"
              />
            </div>
          </div>

          {/* Quick Query Templates */}
          <div className="flex items-center gap-1.5 flex-wrap text-xs">
            <span className="text-[11px] font-bold text-slate-500 mr-1 flex items-center gap-1">
              <Sparkles className="w-3.5 h-3.5 text-indigo-600" />
              Templates:
            </span>
            <button
              type="button"
              onClick={() => handleApplyTemplate('byId')}
              className="px-2.5 py-1 bg-slate-100 hover:bg-indigo-50 hover:text-indigo-700 rounded-lg text-[11px] font-semibold text-slate-700 transition-colors cursor-pointer"
            >
              Match by Document ID
            </button>
            <button
              type="button"
              onClick={() => handleApplyTemplate('audit')}
              className="px-2.5 py-1 bg-slate-100 hover:bg-indigo-50 hover:text-indigo-700 rounded-lg text-[11px] font-semibold text-slate-700 transition-colors cursor-pointer"
            >
              Audit Sync Events
            </button>
            <button
              type="button"
              onClick={() => handleApplyTemplate('errors')}
              className="px-2.5 py-1 bg-slate-100 hover:bg-indigo-50 hover:text-indigo-700 rounded-lg text-[11px] font-semibold text-slate-700 transition-colors cursor-pointer"
            >
              Error Logs Filter
            </button>
            <button
              type="button"
              onClick={() => handleApplyTemplate('matchAll')}
              className="px-2.5 py-1 bg-slate-100 hover:bg-indigo-50 hover:text-indigo-700 rounded-lg text-[11px] font-semibold text-slate-700 transition-colors cursor-pointer"
            >
              Match All
            </button>
          </div>

          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label className="text-xs font-bold text-slate-700">
                Elasticsearch Query Body (JSON DSL) <span className="text-rose-500">*</span>
              </label>
              {!isJsonValid && (
                <span className="text-[11px] text-rose-600 flex items-center gap-1">
                  <AlertCircle className="w-3 h-3" /> Invalid JSON Syntax
                </span>
              )}
            </div>
            <textarea
              rows={9}
              required
              value={queryBody}
              onChange={(e) => setQueryBody(e.target.value)}
              className="w-full bg-slate-900 border border-slate-800 text-amber-300 font-mono text-xs p-4 rounded-2xl focus:outline-none focus:ring-2 focus:ring-indigo-500/20 leading-relaxed resize-y"
            />
          </div>

          <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-bold text-slate-600 hover:bg-slate-100 rounded-xl cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={!title.trim() || !isJsonValid}
              className="px-5 py-2 bg-indigo-600 hover:bg-indigo-700 disabled:bg-slate-300 text-white text-xs font-bold rounded-xl shadow-md cursor-pointer transition-all flex items-center gap-1.5"
            >
              <Check className="w-4 h-4" />
              <span>Save Query</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
