import React, { useState } from 'react';
import { X, Check, Activity, AlertCircle, Database, ShieldCheck, Key, RefreshCw } from 'lucide-react';
import { EsConnectionConfig, EsClusterInfo } from '../../../types/elasticsearch';
import { testElasticsearchConnection, saveEsConnectionConfig } from '../../../utils/elasticsearchStorage';

interface EsConnectionModalProps {
  isOpen: boolean;
  onClose: () => void;
  config: EsConnectionConfig;
  onSaveConfig: (config: EsConnectionConfig) => void;
  onConnectionTested?: (info: EsClusterInfo | null, isConnected: boolean) => void;
}

export const EsConnectionModal: React.FC<EsConnectionModalProps> = ({
  isOpen,
  onClose,
  config,
  onSaveConfig,
  onConnectionTested,
}) => {
  const [formData, setFormData] = useState<EsConnectionConfig>(config);
  const [isTesting, setIsTesting] = useState(false);
  const [testResult, setTestResult] = useState<{
    success: boolean;
    clusterInfo?: EsClusterInfo;
    error?: string;
  } | null>(null);

  if (!isOpen) return null;

  const handleTest = async () => {
    setIsTesting(true);
    setTestResult(null);
    try {
      const res = await testElasticsearchConnection(formData);
      if (res.success && res.clusterInfo) {
        setTestResult({
          success: true,
          clusterInfo: {
            ...res.clusterInfo,
            health: res.health,
          },
        });
        onConnectionTested?.(res.clusterInfo, true);
      } else {
        setTestResult({
          success: false,
          error: res.error || 'Connection failed',
        });
        onConnectionTested?.(null, false);
      }
    } catch (e: any) {
      setTestResult({
        success: false,
        error: e.message || 'Unknown network error',
      });
      onConnectionTested?.(null, false);
    } finally {
      setIsTesting(false);
    }
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    saveEsConnectionConfig(formData);
    onSaveConfig(formData);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4 animate-fadeIn">
      <div className="bg-white border border-slate-200 rounded-3xl w-full max-w-xl p-7 shadow-2xl relative">
        <div className="flex items-center justify-between pb-4 border-b border-slate-100">
          <div className="flex items-center gap-2.5">
            <div className="p-2.5 bg-amber-50 text-amber-600 rounded-2xl border border-amber-200/80">
              <Database className="h-5 w-5" />
            </div>
            <div>
              <h3 className="text-base font-extrabold text-slate-900">
                Elasticsearch Connection Settings
              </h3>
              <p className="text-[11px] text-slate-500">
                Configure cluster URL and credentials. Settings are stored locally.
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-slate-700 p-1.5 rounded-lg hover:bg-slate-100 transition-colors cursor-pointer"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        <form onSubmit={handleSave} className="space-y-4 pt-4">
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1.5">
              Elasticsearch Cluster URL <span className="text-rose-500">*</span>
            </label>
            <input
              type="text"
              required
              value={formData.url}
              onChange={(e) => setFormData({ ...formData, url: e.target.value })}
              placeholder="e.g. http://localhost:9200 or https://es-prod.corp:9200"
              className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3.5 py-2.5 text-xs font-mono text-slate-900 focus:outline-none focus:border-indigo-600"
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1.5">
                Authentication Type
              </label>
              <select
                value={formData.authType}
                onChange={(e) => setFormData({ ...formData, authType: e.target.value as any })}
                className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3.5 py-2.5 text-xs text-slate-900 focus:outline-none focus:border-indigo-600 cursor-pointer"
              >
                <option value="none">No Authentication (Anonymous)</option>
                <option value="basic">Basic Auth (Username / Password)</option>
                <option value="apiKey">Elasticsearch API Key</option>
                <option value="bearer">Bearer Token (JWT)</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1.5">
                Default Index / Pattern
              </label>
              <input
                type="text"
                value={formData.defaultIndex || ''}
                onChange={(e) => setFormData({ ...formData, defaultIndex: e.target.value })}
                placeholder="e.g. customers-*, audit-*"
                className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3.5 py-2.5 text-xs font-mono text-slate-900 focus:outline-none focus:border-indigo-600"
              />
            </div>
          </div>

          {/* Conditional Credential Inputs */}
          {formData.authType === 'basic' && (
            <div className="grid grid-cols-2 gap-3 p-3.5 bg-slate-50 border border-slate-200 rounded-2xl">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Username</label>
                <input
                  type="text"
                  value={formData.username || ''}
                  onChange={(e) => setFormData({ ...formData, username: e.target.value })}
                  placeholder="e.g. elastic"
                  className="w-full bg-white border border-slate-200 rounded-xl px-3 py-1.5 text-xs text-slate-900 focus:outline-none focus:border-indigo-600"
                />
              </div>
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Password</label>
                <input
                  type="password"
                  value={formData.password || ''}
                  onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                  placeholder="••••••••"
                  className="w-full bg-white border border-slate-200 rounded-xl px-3 py-1.5 text-xs text-slate-900 focus:outline-none focus:border-indigo-600"
                />
              </div>
            </div>
          )}

          {formData.authType === 'apiKey' && (
            <div className="p-3.5 bg-slate-50 border border-slate-200 rounded-2xl">
              <label className="block text-xs font-bold text-slate-700 mb-1">
                API Key (Base64 Encoded or Key:Value)
              </label>
              <input
                type="password"
                value={formData.apiKey || ''}
                onChange={(e) => setFormData({ ...formData, apiKey: e.target.value })}
                placeholder="e.g. VnVhQ2ZHY0JDZGJrUW..."
                className="w-full bg-white border border-slate-200 rounded-xl px-3 py-1.5 text-xs font-mono text-slate-900 focus:outline-none focus:border-indigo-600"
              />
            </div>
          )}

          {formData.authType === 'bearer' && (
            <div className="p-3.5 bg-slate-50 border border-slate-200 rounded-2xl">
              <label className="block text-xs font-bold text-slate-700 mb-1">Bearer Token</label>
              <input
                type="password"
                value={formData.bearerToken || ''}
                onChange={(e) => setFormData({ ...formData, bearerToken: e.target.value })}
                placeholder="Bearer eyJhbGci..."
                className="w-full bg-white border border-slate-200 rounded-xl px-3 py-1.5 text-xs font-mono text-slate-900 focus:outline-none focus:border-indigo-600"
              />
            </div>
          )}

          {/* Test Connection Feedback */}
          {testResult && (
            <div
              className={`p-3.5 rounded-2xl border text-xs ${
                testResult.success
                  ? 'bg-emerald-50 border-emerald-200 text-emerald-900'
                  : 'bg-rose-50 border-rose-200 text-rose-900'
              }`}
            >
              {testResult.success && testResult.clusterInfo ? (
                <div className="space-y-1">
                  <div className="flex items-center gap-1.5 font-bold text-emerald-700">
                    <ShieldCheck className="w-4 h-4 text-emerald-600" />
                    <span>Connection Successful!</span>
                  </div>
                  <div className="text-[11px] text-emerald-800 grid grid-cols-2 gap-2 mt-1 font-mono">
                    <div>Cluster: <strong>{testResult.clusterInfo.cluster_name}</strong></div>
                    <div>Version: <strong>{testResult.clusterInfo.version?.number || '8.x'}</strong></div>
                    {testResult.clusterInfo.health?.status && (
                      <div>Health: <strong className="uppercase">{testResult.clusterInfo.health.status}</strong></div>
                    )}
                    {testResult.clusterInfo.health?.number_of_nodes && (
                      <div>Nodes: <strong>{testResult.clusterInfo.health.number_of_nodes}</strong></div>
                    )}
                  </div>
                </div>
              ) : (
                <div className="flex items-start gap-2">
                  <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
                  <div>
                    <span className="font-bold block">Connection Failed:</span>
                    <span className="text-[11px] text-rose-700 break-all">{testResult.error}</span>
                  </div>
                </div>
              )}
            </div>
          )}

          <div className="flex items-center justify-between pt-3 border-t border-slate-100">
            <button
              type="button"
              onClick={handleTest}
              disabled={isTesting || !formData.url}
              className="px-4 py-2 bg-slate-100 hover:bg-slate-200 disabled:opacity-50 text-slate-800 text-xs font-bold rounded-xl transition-all flex items-center gap-1.5 cursor-pointer"
            >
              {isTesting ? (
                <>
                  <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                  <span>Testing Connection...</span>
                </>
              ) : (
                <>
                  <Activity className="w-3.5 h-3.5 text-amber-600" />
                  <span>Test Connection</span>
                </>
              )}
            </button>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 text-xs font-bold text-slate-600 hover:bg-slate-100 rounded-xl cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold rounded-xl shadow-md cursor-pointer transition-all flex items-center gap-1.5"
              >
                <Check className="w-4 h-4" />
                <span>Save Settings Locally</span>
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};
