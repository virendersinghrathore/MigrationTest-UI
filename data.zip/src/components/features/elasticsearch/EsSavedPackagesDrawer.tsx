import React from 'react';
import { X, Trash2, Download, Clock, FolderArchive, ArrowRight } from 'lucide-react';
import { EsEvidencePackage } from '../../../types/elasticsearch';
import { exportToJsonFile } from '../../../utils/jsonHelper';

interface EsSavedPackagesDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  packages: EsEvidencePackage[];
  onLoadPackage: (pkg: EsEvidencePackage) => void;
  onDeletePackage: (id: string) => void;
}

export const EsSavedPackagesDrawer: React.FC<EsSavedPackagesDrawerProps> = ({
  isOpen,
  onClose,
  packages,
  onLoadPackage,
  onDeletePackage,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex justify-end bg-slate-900/40 backdrop-blur-xs animate-fadeIn">
      <div className="w-full max-w-md bg-white h-full shadow-2xl flex flex-col border-l border-slate-200">
        <div className="p-5 border-b border-slate-200 flex items-center justify-between bg-slate-50">
          <div className="flex items-center gap-2">
            <FolderArchive className="w-5 h-5 text-indigo-600" />
            <div>
              <h3 className="text-sm font-bold text-slate-900">Saved Evidence Packages</h3>
              <p className="text-[11px] text-slate-500">
                {packages.length} audit package{packages.length === 1 ? '' : 's'} recorded
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-700 rounded-lg hover:bg-slate-200/60 cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto p-4 space-y-3">
          {packages.length === 0 ? (
            <div className="p-8 text-center border border-dashed border-slate-200 rounded-2xl">
              <FolderArchive className="w-8 h-8 text-slate-300 mx-auto mb-2" />
              <p className="text-xs font-bold text-slate-600">No Evidence Packages Saved</p>
              <p className="text-[11px] text-slate-400 mt-1">
                Run your Elasticsearch queries and click "Save Evidence Package" to persist them.
              </p>
            </div>
          ) : (
            packages.map((pkg) => {
              const totalHits = pkg.results.reduce((acc, r) => acc + (r.totalHits || 0), 0);
              const successCount = pkg.results.filter((r) => r.status === 'SUCCESS').length;

              return (
                <div
                  key={pkg.id}
                  className="p-4 bg-white border border-slate-200 hover:border-indigo-300 rounded-2xl shadow-xs hover:shadow-sm transition-all"
                >
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <h4 className="text-xs font-bold text-slate-900">{pkg.title}</h4>
                      <p className="text-[11px] font-mono text-slate-500 truncate max-w-[240px]">
                        {pkg.clusterUrl}
                      </p>
                    </div>

                    <span className="text-[10px] font-extrabold px-2 py-0.5 rounded-md bg-emerald-50 text-emerald-700 border border-emerald-200">
                      {totalHits} Hits
                    </span>
                  </div>

                  <div className="mt-2.5 flex items-center gap-2 text-[11px] text-slate-500 font-medium">
                    <span>{pkg.results.length} Queries Run</span>
                    <span>•</span>
                    <span className="text-emerald-600 font-bold">{successCount} Succeeded</span>
                  </div>

                  <div className="mt-3 pt-3 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-400">
                    <span className="flex items-center gap-1 font-mono">
                      <Clock className="w-3 h-3" />
                      {pkg.createdAt}
                    </span>

                    <div className="flex items-center gap-1.5">
                      <button
                        onClick={() => exportToJsonFile(`es_evidence_${pkg.id}.json`, pkg)}
                        className="p-1 text-slate-400 hover:text-slate-700 rounded hover:bg-slate-100 cursor-pointer"
                        title="Export Package as JSON"
                      >
                        <Download className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => {
                          if (window.confirm(`Delete evidence package "${pkg.title}"?`)) {
                            onDeletePackage(pkg.id);
                          }
                        }}
                        className="p-1 text-slate-400 hover:text-rose-600 rounded hover:bg-rose-50 cursor-pointer"
                        title="Delete Evidence Package"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => {
                          onLoadPackage(pkg);
                          onClose();
                        }}
                        className="px-2.5 py-1 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 rounded-lg font-bold flex items-center gap-1 cursor-pointer transition-colors"
                      >
                        <span>View</span>
                        <ArrowRight className="w-3 h-3" />
                      </button>
                    </div>
                  </div>
                </div>
              );
            })
          )}
        </div>
      </div>
    </div>
  );
};
